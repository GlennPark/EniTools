﻿// Recon_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Recon_FormView.h"

#include "Warnning_Dialog.h"
// CRecon_FormView

IMPLEMENT_DYNCREATE(CRecon_FormView, CFormView)

CRecon_FormView::CRecon_FormView()
	: CFormView(IDD_RECON_DIALOG)
{

}

CRecon_FormView::~CRecon_FormView()
{
}

void CRecon_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CRecon_FormView, CFormView)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CRecon_FormView 진단

#ifdef _DEBUG
void CRecon_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CRecon_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CRecon_FormView 메시지 처리기


void CRecon_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
}
