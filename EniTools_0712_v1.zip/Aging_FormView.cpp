﻿// Aging_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Aging_FormView.h"

#include "Warnning_Dialog.h"

// CAging_FormView

IMPLEMENT_DYNCREATE(CAging_FormView, CFormView)

CAging_FormView::CAging_FormView()
	: CFormView(IDD_AGING_DIALOG)
{

}

CAging_FormView::~CAging_FormView()
{
}

void CAging_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAging_FormView, CFormView)
	ON_WM_NCLBUTTONDOWN()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CAging_FormView 진단

#ifdef _DEBUG
void CAging_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CAging_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CAging_FormView 메시지 처리기




void CAging_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();

}
