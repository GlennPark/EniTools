﻿#pragma once



// CSetting_FormView 폼 보기

#include <dxgi.h>


class CSetting_FormView : public CFormView
{
	DECLARE_DYNCREATE(CSetting_FormView)

protected:
	CSetting_FormView();           // 동적 만들기에 사용되는 protected 생성자입니다.
	virtual ~CSetting_FormView();

public:
	
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SETTING_DIALOG };
	
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()

public:
	CString GetGPUInfo();
	CString GetLocalIPAddress();
	afx_msg void OnEnChangeGpuEdit();
	afx_msg void OnBnClickedSaveSettingButton();

	virtual void OnInitialUpdate();
	void LoadData_Setting();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnChangeLogoNameEdit();
	afx_msg void OnEnChangeEditEquipment();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	afx_msg void OnDeltaposSpinPanoManKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoManMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoWomanKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoWomanMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoChildKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoChildMa(NMHDR* pNMHDR, LRESULT* pResult);

	afx_msg void OnEnChangeEditPanoManKv();
	afx_msg void OnEnChangeEditPanoManMa();
	afx_msg void OnEnChangeEditPanoWomanKv();
	afx_msg void OnEnChangeEditPanoWomanMa();
	afx_msg void OnEnChangeEditPanoChildKv();
	afx_msg void OnEnChangeEditPanoChildMa();
	afx_msg void OnEnChangeEditPanoTeenKv();
	afx_msg void OnEnChangeEditPanoTeenMa();


private:
	CToolTipCtrl m_Setting_Tips;
	
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnStnClickedStaticAutoReturn();
	
	afx_msg void OnEnChangeEditCephManKv();
	afx_msg void OnDeltaposSpinPanoTeenKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinPanoTeenMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEnChangeEditCephManMa();
	afx_msg void OnEnChangeEditCephWomanKv();
	afx_msg void OnEnChangeEditCephWomanMa();
	afx_msg void OnEnChangeEditCephChildKv();
	afx_msg void OnEnChangeEditCephChildMa();
	afx_msg void OnEnChangeEditCephTeenKv();
	afx_msg void OnEnChangeEditCephTeenMa();
	afx_msg void OnEnChangeEditCephCarpusKv();
	afx_msg void OnEnChangeEditCephCarpusMa();
	afx_msg void OnEnChangeEditCtManKv();
	afx_msg void OnEnChangeEditCtManMa();
	afx_msg void OnEnChangeEditCtWomanKv();
	afx_msg void OnEnChangeEditCtWomanMa();
	afx_msg void OnEnChangeEditCtChildKv();
	afx_msg void OnEnChangeEditCtChildMa();
	afx_msg void OnEnChangeEditCtTeenKv();
	afx_msg void OnEnChangeEditCtTeenMa();
	afx_msg void OnEnChangeEditCtLowKv();
	afx_msg void OnEnChangeEditCtLowMa();
	afx_msg void OnEnChangeEditCtUltraLowKv();
	afx_msg void OnEnChangeEditCtUltraLowMa();
	afx_msg void OnDeltaposSpinCephManKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephManMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephWomanKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephWomanMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephChildKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephChildMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephTeenKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephTeenMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephCarpusKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCephCarpusMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtManKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtManMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtWomanKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtWomanMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtChildKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtChildMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtTeenKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtTeenMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtLowKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtLowMa(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtUltraLowKv(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpinCtUltraLowMa(NMHDR* pNMHDR, LRESULT* pResult);
};


