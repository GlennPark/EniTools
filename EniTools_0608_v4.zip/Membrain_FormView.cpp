﻿// Membrain_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Membrain_FormView.h"


// CMembrain_FormView

IMPLEMENT_DYNCREATE(CMembrain_FormView, CFormView)

CMembrain_FormView::CMembrain_FormView()
	: CFormView(IDD_MEMBRAIN_DIALOG)
{

}

CMembrain_FormView::~CMembrain_FormView()
{
}

void CMembrain_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMembrain_FormView, CFormView)
	

	ON_STN_CLICKED(IDC_STATIC_CEPH_DEFAULT_MODE, &CMembrain_FormView::OnStnClickedStaticCephDefaultMode)
END_MESSAGE_MAP()


// CMembrain_FormView 진단

#ifdef _DEBUG
void CMembrain_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CMembrain_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CMembrain_FormView 메시지 처리기


void CMembrain_FormView::OnStnClickedStaticCephDefaultMode()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
