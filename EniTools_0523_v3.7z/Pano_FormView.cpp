﻿// Pano_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Pano_FormView.h"


// CPano_FormView

IMPLEMENT_DYNCREATE(CPano_FormView, CFormView)

CPano_FormView::CPano_FormView()
	: CFormView(IDD_PANO_DIALOG)
{

}

CPano_FormView::~CPano_FormView()
{
}

void CPano_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPano_FormView, CFormView)
END_MESSAGE_MAP()


// CPano_FormView 진단

#ifdef _DEBUG
void CPano_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPano_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPano_FormView 메시지 처리기
