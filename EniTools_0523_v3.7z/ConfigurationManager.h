#pragma once


class ConfigurationManager
{
private:
	static ConfigurationManager* m_instance;
	CString m_strPath;

private:
	explicit ConfigurationManager();
	~ConfigurationManager();

public:
	static ConfigurationManager* getInstance();

	void SetIniPath(CString path);

	// add get / set
	void SetData(const CString section, const CString key, const CString data);
	CString GetData(const CString section, const CString key);

	void SetLanguage(const CString data);
	CString GetLanguage();

	void SetLogoMode(const CString data);
	CString GetLogoMode();

	void SetLogoName(const CString data);
	CString GetLogoName();

	void SetAutoReturn(const CString data);
	CString GetAutoReturn();

	void SetEthernetSpeedCheck(const CString data);
	CString GetEthernetSpeedCheck();

	void SetLogoDebugMode(const CString data);
	CString GetLogoDebugMode();

	void SetEquipment(const CString data);
	CString GetEquipment();

	void SetEthernetRestart(const CString data);
	CString GetEthernetRestart();

	void SetPanoResultCutting(const CString data);
	CString GetPanoResultCutting();

	void SetPanoManKv(const CString data);
	CString GetPanoManKv();
	
	void SetPanoManMa(const CString data);
	CString GetPanoManMa();

	void SetPanoWomanKv(const CString data);
	CString GetPanoWomanKv();

	void SetPanoWomanMa(const CString data);
	CString GetPanoWomanMa();
	
	void SetPanoChildKv(const CString data);
	CString GetPanoChildKv();
	
	void SetPanoChildMa(const CString data);
	CString GetPanoChildMa();

};