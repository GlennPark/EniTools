﻿// Backup_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Backup_FormView.h"


// CBackup_FormView

IMPLEMENT_DYNCREATE(CBackup_FormView, CFormView)

CBackup_FormView::CBackup_FormView()
	: CFormView(IDD_BACKUP_DIALOG)
{

}

CBackup_FormView::~CBackup_FormView()
{
}

void CBackup_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBackup_FormView, CFormView)
END_MESSAGE_MAP()


// CBackup_FormView 진단

#ifdef _DEBUG
void CBackup_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CBackup_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CBackup_FormView 메시지 처리기
