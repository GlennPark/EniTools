﻿// Calibration_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Calibration_FormView.h"


// CCalibration_FormView

IMPLEMENT_DYNCREATE(CCalibration_FormView, CFormView)

CCalibration_FormView::CCalibration_FormView()
	: CFormView(IDD_CALIBRATION_DIALOG)
{

}

CCalibration_FormView::~CCalibration_FormView()
{
}

void CCalibration_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCalibration_FormView, CFormView)
END_MESSAGE_MAP()


// CCalibration_FormView 진단

#ifdef _DEBUG
void CCalibration_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCalibration_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCalibration_FormView 메시지 처리기
