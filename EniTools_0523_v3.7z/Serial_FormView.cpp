﻿// Serial_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Serial_FormView.h"


// CSerial_FormView

IMPLEMENT_DYNCREATE(CSerial_FormView, CFormView)

CSerial_FormView::CSerial_FormView()
	: CFormView(IDD_SERIAL_DIALOG)
{

}

CSerial_FormView::~CSerial_FormView()
{
}

void CSerial_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSerial_FormView, CFormView)
END_MESSAGE_MAP()


// CSerial_FormView 진단

#ifdef _DEBUG
void CSerial_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSerial_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSerial_FormView 메시지 처리기
