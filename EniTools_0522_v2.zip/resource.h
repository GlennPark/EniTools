﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// EniTools.rc에서 사용되고 있습니다.
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ENITOOLS_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_SETTING_DIALOG              130
#define IDD_CT_DIALOG                   133
#define IDD_PANO_DIALOG                 135
#define IDD_CEPH_DIALOG                 137
#define IDD_PATIENT_DIALOG              139
#define IDB_SETTING_ICON                142
#define IDD_SERIAL_DIALOG               143
#define IDD_CALIBRATION_DIALOG          145
#define IDD_EXPOSE_DIALOG               147
#define IDD_BACKUP_DIALOG               149
#define IDD_MEMBRAIN_DIALOG             151
#define IDD_DIALOG1                     153
#define IDD_FOV_DIALOG                  153
#define IDD_AGING_DIALOG                155
#define IDD_DIALOG2                     157
#define IDD_RECON_DIALOG                157
#define IDI_ICON_SETTING                159
#define IDC_SECTION_LIST                1000
#define IDC_SAVE_BUTTON                 1001
#define IDC_LOAD_BUTTON                 1002
#define IDC_EDIT1                       1005
#define IDC_BUTTON3                     1007
#define IDC_COMBO1                      1011
#define IDC_COMBO_LANGUAGE              1011
#define IDC_EDIT2                       1012
#define IDC_GPU_EDIT                    1012
#define IDC_CHECK3                      1013
#define IDC_CHECK_LOGO_MODE             1013
#define IDC_EDIT4                       1016
#define IDC_LOGO_NAME_EDIT              1016
#define IDC_STATIC_DIALOG_VIEWER        1017
#define IDC_STATIC_PICTURE_CONTROL      1018
#define IDC_CHECK1                      1019
#define IDC_CHECK_AUTO_RETURN           1019
#define IDC_IPADDRESS1                  1020
#define IDC_CHECK2                      1021
#define IDC_CHECK_ETHERNET_SPEED_CHECK  1021
#define IDC_CHECK4                      1022
#define IDC_CHECK_LOGO_DEBUG_MODE       1022
#define IDC_CHECK5                      1023
#define IDC_CHECK_ETHERNET_RESTART      1023
#define IDC_BUTTON1                     1024
#define IDC_SPIN1                       1025
#define IDC_EDIT3                       1026
#define IDC_BUTTON2                     1027
#define IDC_COMBO_PANO_RESULT_CUTTING   1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
