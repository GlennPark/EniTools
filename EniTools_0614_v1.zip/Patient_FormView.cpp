﻿// Patient_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Patient_FormView.h"

#include "Warnning_Dialog.h"
// CPatient_FormView

IMPLEMENT_DYNCREATE(CPatient_FormView, CFormView)

CPatient_FormView::CPatient_FormView()
	: CFormView(IDD_PATIENT_DIALOG)
{

}

CPatient_FormView::~CPatient_FormView()
{
}

void CPatient_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPatient_FormView, CFormView)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CPatient_FormView 진단

#ifdef _DEBUG
void CPatient_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPatient_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPatient_FormView 메시지 처리기


void CPatient_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
}
