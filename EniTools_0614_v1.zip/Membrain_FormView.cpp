﻿// Membrain_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Membrain_FormView.h"
#include "ConfigurationManager.h"

#include "Warnning_Dialog.h"
// CMembrain_FormView

IMPLEMENT_DYNCREATE(CMembrain_FormView, CFormView)

CMembrain_FormView::CMembrain_FormView()
	: CFormView(IDD_MEMBRAIN_DIALOG)
{

}

CMembrain_FormView::~CMembrain_FormView()
{
}

void CMembrain_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMembrain_FormView, CFormView)
	

	ON_STN_CLICKED(IDC_STATIC_CEPH_DEFAULT_MODE, &CMembrain_FormView::OnStnClickedStaticCephDefaultMode)
	ON_BN_CLICKED(IDC_RADIO_FULL_ARCH, &CMembrain_FormView::OnBnClickedRadioFullArch)
	ON_BN_CLICKED(IDC_RADIO_OCCUSION, &CMembrain_FormView::OnBnClickedRadioOccusion)
	ON_BN_CLICKED(IDC_RADIO_SINUS, &CMembrain_FormView::OnBnClickedRadioSinus)
	ON_BN_CLICKED(IDC_RADIO_FULL_LATERAL, &CMembrain_FormView::OnBnClickedRadioFullLateral)
	ON_BN_CLICKED(IDC_RADIO_LATERAL, &CMembrain_FormView::OnBnClickedRadioLateral)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_MEMBRAIN, &CMembrain_FormView::OnBnClickedButtonSaveMembrain)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CMembrain_FormView 진단

#ifdef _DEBUG
void CMembrain_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CMembrain_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CMembrain_FormView 메시지 처리기


void CMembrain_FormView::LoadData_Membrain()
{
	CString FOV_default_position = ConfigurationManager::getInstance()->GetFOVDefaultPosition();
	CString Ceph_default_mode = ConfigurationManager::getInstance()->GetCephDefaultMode();

	if (FOV_default_position == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FULL_ARCH))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_OCCUSION))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_SINUS))->SetCheck(FALSE);
		OnBnClickedRadioFullArch();
	}
	else if (FOV_default_position == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FULL_ARCH))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_OCCUSION))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_SINUS))->SetCheck(FALSE);
		OnBnClickedRadioOccusion();
	}
	else if (FOV_default_position == _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FULL_ARCH))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_OCCUSION))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_SINUS))->SetCheck(TRUE);
		OnBnClickedRadioSinus();
	}

	if (Ceph_default_mode == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FULL_LATERAL))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_LATERAL))->SetCheck(FALSE);
	}
	else if (Ceph_default_mode == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FULL_LATERAL))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_LATERAL))->SetCheck(TRUE);
	}
}

void CMembrain_FormView::ChangeImage(int nItem, int nImage)
{
	// 대화상자에 생성된 Picture 컨트롤의 주소를 얻는다. ( Picture 컨트롤도 CStatic 컨트롤이다. )
	CStatic* p_lamp_image = (CStatic*)GetDlgItem(nItem);

	// 리소스에 있는 비트맵 이미지를 읽기 위해서 CBitmap 클래스 객체를 선언한다.
	CBitmap lamp_image;
	// 리소스에서 IDB_BITMAP2 이미지를 읽는다.
	lamp_image.LoadBitmap(nImage);

	// Picture 컨트롤에 새로 읽어들인 이미지를 설정하고 이전에 사용하던 이미지 핸들을
	// p_old_ bitmap 변수에 저장한다.
	HBITMAP h_old_bitmap = p_lamp_image->SetBitmap(lamp_image);

	// Picture 컨트롤이 이전에 사용하던 이미지가 있었다면 제거한다.
	if (h_old_bitmap != NULL) ::DeleteObject(h_old_bitmap);

	// Picture 컨트롤에 이미지를 설정하기 위해서 생성했던 이미지는 Picture 컨트롤이 사용하기
	// 때문에 lamp_image 객체가 종료되면서 삭제되지 않도록 연결을 해제한다.
	// 이 코드를 사용하지 않아도 되는 것처럼 보이지만 해당 Picture 컨트롤이 가려졌다가
	// 다시 보이게 되는 경우 그림이 그려지지 않는다. 따라서 꼭 사용해야 합니다.
	lamp_image.Detach();
}

void CMembrain_FormView::OnStnClickedStaticCephDefaultMode()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CMembrain_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.

	((CButton*)GetDlgItem(IDC_RADIO_FULL_ARCH))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_RADIO_FULL_LATERAL))->SetCheck(TRUE);
}


void CMembrain_FormView::OnBnClickedRadioFullArch()
{
	ChangeImage(IDC_STATIC_FULL_ARCH, IDB_BITMAP_FULL_ARCH_1);
	ChangeImage(IDC_STATIC_OCCUSION, IDB_BITMAP_OCCLUSION_0);
	ChangeImage(IDC_STATIC_SINUS, IDB_BITMAP_SINUS_0);
}

void CMembrain_FormView::OnBnClickedRadioOccusion()
{
	ChangeImage(IDC_STATIC_FULL_ARCH, IDB_BITMAP_FULL_ARCH_0);
	ChangeImage(IDC_STATIC_OCCUSION, IDB_BITMAP_OCCLUSION_1);
	ChangeImage(IDC_STATIC_SINUS, IDB_BITMAP_SINUS_0);
}

void CMembrain_FormView::OnBnClickedRadioSinus()
{
	ChangeImage(IDC_STATIC_FULL_ARCH, IDB_BITMAP_FULL_ARCH_0);
	ChangeImage(IDC_STATIC_OCCUSION, IDB_BITMAP_OCCLUSION_0);
	ChangeImage(IDC_STATIC_SINUS, IDB_BITMAP_SINUS_1);
}


void CMembrain_FormView::OnBnClickedRadioFullLateral()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	ChangeImage(IDC_STATIC_FULL_LATERAL, IDB_BITMAP_FULL_LATERAL_1);
	ChangeImage(IDC_STATIC_LATERAL, IDB_BITMAP_FULL_LATERAL_0);
}

void CMembrain_FormView::OnBnClickedRadioLateral()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	ChangeImage(IDC_STATIC_FULL_LATERAL, IDB_BITMAP_FULL_LATERAL_0);
	ChangeImage(IDC_STATIC_LATERAL, IDB_BITMAP_FULL_LATERAL_1);
}


void CMembrain_FormView::OnBnClickedButtonSaveMembrain()
{
	CString strFOV = _T("0");
	BOOL bCheck = false;
	bCheck = ((CButton*)GetDlgItem(IDC_RADIO_FULL_ARCH))->GetCheck();
	if (bCheck) strFOV = _T("0");

	bCheck = ((CButton*)GetDlgItem(IDC_RADIO_OCCUSION))->GetCheck();
	if (bCheck) strFOV = _T("1");

	bCheck = ((CButton*)GetDlgItem(IDC_RADIO_SINUS))->GetCheck();
	if (bCheck) strFOV = _T("2");


	CString strCeph = _T("0");
	bCheck = ((CButton*)GetDlgItem(IDC_RADIO_FULL_LATERAL))->GetCheck();
	if (bCheck) strCeph = _T("0");
		
	bCheck = ((CButton*)GetDlgItem(IDC_RADIO_LATERAL))->GetCheck();
	if (bCheck) strCeph = _T("1");

	ConfigurationManager::getInstance()->SetFOVDefaultPosition(strFOV);
	ConfigurationManager::getInstance()->SetCephDefaultMode(strCeph);

}



void CMembrain_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
}
