﻿// Backup_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "afxdialogex.h"
#include "Backup_FormView.h"


// CBackup_FormView 대화 상자

IMPLEMENT_DYNAMIC(CBackup_FormView, CDialogEx)

CBackup_FormView::CBackup_FormView(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_BACKUP_DIALOG, pParent)
{

}

CBackup_FormView::~CBackup_FormView()
{
}

void CBackup_FormView::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBackup_FormView, CDialogEx)
END_MESSAGE_MAP()


// CBackup_FormView 메시지 처리기
