﻿// Patient_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Patient_FormView.h"


// CPatient_FormView

IMPLEMENT_DYNCREATE(CPatient_FormView, CFormView)

CPatient_FormView::CPatient_FormView()
	: CFormView(IDD_PATIENT_DIALOG)
{

}

CPatient_FormView::~CPatient_FormView()
{
}

void CPatient_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPatient_FormView, CFormView)
END_MESSAGE_MAP()


// CPatient_FormView 진단

#ifdef _DEBUG
void CPatient_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPatient_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPatient_FormView 메시지 처리기
