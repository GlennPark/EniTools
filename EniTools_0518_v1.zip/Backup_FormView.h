﻿#pragma once
#include "afxdialogex.h"


// CBackup_FormView 대화 상자

class CBackup_FormView : public CDialogEx
{
	DECLARE_DYNAMIC(CBackup_FormView)

public:
	CBackup_FormView(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CBackup_FormView();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_BACKUP_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
};
