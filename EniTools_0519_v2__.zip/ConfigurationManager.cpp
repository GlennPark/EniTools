#include "pch.h"
#include "ConfigurationManager.h"

ConfigurationManager* ConfigurationManager::m_instance = nullptr;
ConfigurationManager::ConfigurationManager()
{}

ConfigurationManager::~ConfigurationManager()
{}

ConfigurationManager* ConfigurationManager::getInstance()
{
	if (m_instance == nullptr)
		m_instance = new ConfigurationManager();

	return m_instance;
}

void ConfigurationManager::SetIniPath(CString path)
{
	m_strPath = path;
}

void ConfigurationManager::SetData(const CString section, const CString key, const CString data)
{
	WritePrivateProfileString(section, key, data, m_strPath);
}

CString ConfigurationManager::GetData(const CString section, const CString key)
{
	CString rtnStr;
	TCHAR _data[256];
	GetPrivateProfileString(section, key, NULL, _data, sizeof(_data), m_strPath);

	rtnStr = CString(_data);
	return rtnStr;
}

void ConfigurationManager::SetLanguage(const CString data)
{
	SetData(_T("Setting"), _T("language"), data);
}

CString ConfigurationManager::GetLanguage()
{
	return GetData(_T("Setting"), _T("language"));
}

void ConfigurationManager::SetLogoMode(const CString data)
{
	SetData(_T("Setting"), _T("logo_mode"), data);
}

CString ConfigurationManager::GetLogoMode()
{
	return GetData(_T("Setting"), _T("logo_mode"));
}
