﻿// CT_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "CT_FormView.h"


// CCT_FormView

IMPLEMENT_DYNCREATE(CCT_FormView, CFormView)

CCT_FormView::CCT_FormView()
	: CFormView(IDD_CT_DIALOG)
{

}

CCT_FormView::~CCT_FormView()
{
}

void CCT_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCT_FormView, CFormView)
END_MESSAGE_MAP()


// CCT_FormView 진단

#ifdef _DEBUG
void CCT_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCT_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCT_FormView 메시지 처리기
