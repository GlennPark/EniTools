﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"


// CSetting_FormView

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
END_MESSAGE_MAP()


// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기
