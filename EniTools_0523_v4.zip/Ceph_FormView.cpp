﻿// Ceph_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Ceph_FormView.h"


// CCeph_FormView

IMPLEMENT_DYNCREATE(CCeph_FormView, CFormView)

CCeph_FormView::CCeph_FormView()
	: CFormView(IDD_CEPH_DIALOG)
{

}

CCeph_FormView::~CCeph_FormView()
{
}

void CCeph_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCeph_FormView, CFormView)
END_MESSAGE_MAP()


// CCeph_FormView 진단

#ifdef _DEBUG
void CCeph_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCeph_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCeph_FormView 메시지 처리기
