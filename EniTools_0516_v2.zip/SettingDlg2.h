﻿#pragma once



// SettingDlg2 폼 보기

class SettingDlg2 : public CFormView
{
	DECLARE_DYNCREATE(SettingDlg2)

public:
	SettingDlg2();         
	virtual ~SettingDlg2();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SETTING_DIALOG };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
};


