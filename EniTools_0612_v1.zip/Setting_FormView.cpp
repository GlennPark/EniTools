﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"
#include "ConfigurationManager.h"


#include <dxgi.h> 
#include <d3d11.h> 
#pragma comment (lib, "dxgi.lib")
#pragma comment (lib, "d3d11.lib")


#include <winsock2.h>  
#pragma comment(lib, "ws2_32.lib")  // Winsock 라이브러리 링크
// CSetting_FormView

#include <WS2tcpip.h>

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
	ON_EN_CHANGE(IDC_GPU_EDIT, &CSetting_FormView::OnEnChangeGpuEdit)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_SETTING, &CSetting_FormView::OnBnClickedSaveSettingButton)
	ON_EN_CHANGE(IDC_LOGO_NAME_EDIT, &CSetting_FormView::OnChangeLogoNameEdit)
	ON_BN_CLICKED(IDC_CHECK_ETHERNET_RESTART, &CSetting_FormView::OnBnClickedCheckEthernetRestart)
	ON_CBN_SELCHANGE(IDC_COMBO_LANGUAGE, &CSetting_FormView::OnCbnSelchangeComboLanguage)
	ON_NOTIFY(IPN_FIELDCHANGED, IDC_LOAD_BUTTON, &CSetting_FormView::OnIpnFieldchangedLoadButton)
	ON_EN_CHANGE(IDC_EDIT_EQUIPMENT, &CSetting_FormView::OnEnChangeEditEquipment)
	ON_WM_HSCROLL()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_MAN_KV, &CSetting_FormView::OnDeltaposSpinPanoManKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_MAN_KV, &CSetting_FormView::OnEnChangeEditPanoManKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_MAN_MA, &CSetting_FormView::OnEnChangeEditPanoManMa)
	ON_EN_CHANGE(IDC_EDIT_PANO_WOMAN_KV, &CSetting_FormView::OnEnChangeEditPanoWomanKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_WOMAN_MA, &CSetting_FormView::OnEnChangeEditPanoWomanMa)
	ON_EN_CHANGE(IDC_EDIT_PANO_CHILD_KV, &CSetting_FormView::OnEnChangeEditPanoChildKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_CHILD_MA, &CSetting_FormView::OnEnChangeEditPanoChildMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_MAN_MA, &CSetting_FormView::OnDeltaposSpinPanoManMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_WOMAN_KV, &CSetting_FormView::OnDeltaposSpinPanoWomanKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_WOMAN_MA, &CSetting_FormView::OnDeltaposSpinPanoWomanMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_CHILD_KV, &CSetting_FormView::OnDeltaposSpinPanoChildKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_CHILD_MA, &CSetting_FormView::OnDeltaposSpinPanoChildMa)
	ON_STN_CLICKED(IDC_STATIC_LOG_DEBUG_MODE, &CSetting_FormView::OnStnClickedStaticLogDebugMode)
END_MESSAGE_MAP()

// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기


// 현재 사용중인 GPU 정보를 불러온다
CString CSetting_FormView::GetGPUInfo()
{
	IDXGIFactory* pFactory;
	HRESULT hr = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)(&pFactory));

	IDXGIAdapter* pAdapter;
	CString gpuInfo;

	if (SUCCEEDED(hr))
	{
		for (UINT i = 0; pFactory->EnumAdapters(i, &pAdapter) != DXGI_ERROR_NOT_FOUND; ++i)
		{
			DXGI_ADAPTER_DESC adapterDesc;
			pAdapter->GetDesc(&adapterDesc);

			gpuInfo += adapterDesc.Description;
			gpuInfo += L"\n";

			pAdapter->Release();
		}

		pFactory->Release();
	}

	return gpuInfo;
}


// 사용중인 네트워크 주소를 IP Address Control 에 출력
CString CSetting_FormView::GetLocalIPAddress()
{
	CString strIPAddress;

	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) == 0)
	{
		char ch_addr[80];
		if (gethostname(ch_addr, sizeof(ch_addr)) == SOCKET_ERROR)
		{
			WSACleanup();
			return strIPAddress;
		}

		struct addrinfo hints;
		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family = AF_UNSPEC;

		// 네트워크 주소 없을때 Get
		struct addrinfo* result = NULL;
		if (getaddrinfo(ch_addr, NULL, &hints, &result) != 0)
		{
			WSACleanup();
			return strIPAddress;
		}

		for (struct addrinfo* ptr = result; ptr != NULL; ptr = ptr->ai_next)
		{
			switch (ptr->ai_family)
			{
			case AF_INET:
			{
				struct sockaddr_in* sockaddr_ipv4 = (struct sockaddr_in*)ptr->ai_addr;
				strIPAddress = CString(inet_ntop(AF_INET, &(sockaddr_ipv4->sin_addr), ch_addr, sizeof(ch_addr)));
				break;
			}
			default:
				break;
			}
		}

		freeaddrinfo(result);
		WSACleanup();
	}

	return strIPAddress;
}





void CSetting_FormView::OnEnChangeGpuEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnChangeLogoNameEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}



void CSetting_FormView::OnBnClickedSaveSettingButton()
{
	// test 

	
	//((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	// 
	// edit control, spin control
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetWindowText(_T("0"));
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetRange(0, 10);
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetPos(0);
	//
	//((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(_T("0"));


	// ini 파일에 콤보박스 값 쓰기
	CString strLang;
	CComboBox* lang_comboBox = ((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE));
	lang_comboBox->GetLBText(lang_comboBox->GetCurSel(), strLang);
	ConfigurationManager::getInstance()->SetLanguage(strLang);

	// save gpu text
	CString strGPU;
	GetDlgItemText(IDC_GPU_EDIT, strGPU);
	
	
	// logo_mode checkbox
	BOOL b_logoMode = ((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->GetCheck();
	CString strLogoMode;
	strLogoMode.Format(_T("%d"), b_logoMode);
	ConfigurationManager::getInstance()->SetLogoMode(strLogoMode);

	// save logo name text
	CString strLogoName;
	CEdit* logoname_edit = ((CEdit*)GetDlgItem(IDC_EDIT_LOGO_NAME));
	GetDlgItemText(IDC_EDIT_LOGO_NAME, strLogoName);
	ConfigurationManager::getInstance()->SetLogoName(strLogoName);

	// auto_return checkbox
	BOOL b_autoReturn = ((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->GetCheck();
	CString strAutoReturn;
	strAutoReturn.Format(_T("%d"), b_autoReturn);
	ConfigurationManager::getInstance()->SetAutoReturn(strAutoReturn);

	// log_debug_mode checkbox
	BOOL b_logDebugMode = ((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->GetCheck();
	CString strLogDebugMode;
	strLogDebugMode.Format(_T("%d"), b_logDebugMode);
	ConfigurationManager::getInstance()->SetLogDebugMode(strLogDebugMode);

	// ethernet_speed_check checkbox
	BOOL b_ethernetSpeedCheck = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->GetCheck();
	CString strEthernetSpeedCheck;
	strEthernetSpeedCheck.Format(_T("%d"), b_ethernetSpeedCheck);
	ConfigurationManager::getInstance()->SetEthernetSpeedCheck(strEthernetSpeedCheck);

	// ethernet_restart checkbox
	BOOL b_ethernetRestart = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->GetCheck();
	CString strEthernetRestart;
	strEthernetRestart.Format(_T("%d"), b_ethernetRestart);
	ConfigurationManager::getInstance()->SetEthernetRestart(strEthernetRestart);

	// save equipment text
	CString strEquipment;
	CEdit* equipment_edit = ((CEdit*)GetDlgItem(IDC_EDIT_EQUIPMENT));
	GetDlgItemText(IDC_EDIT_EQUIPMENT, strEquipment);
	ConfigurationManager::getInstance()->SetEquipment(strEquipment);

	// save pano man kv text
	CString strPanoManKv;
	CEdit* PanoManKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV));
	GetDlgItemText(IDC_EDIT_PANO_MAN_KV, strPanoManKv);
	ConfigurationManager::getInstance()->SetPanoManKv(strPanoManKv);

	// save pano man ma text
	CString strPanoManMa;
	CEdit* PanoManMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_MA));
	GetDlgItemText(IDC_EDIT_PANO_MAN_MA, strPanoManMa);
	ConfigurationManager::getInstance()->SetPanoManMa(strPanoManMa);

	// save pano woman kv text
	CString strPanoWomanKv;
	CEdit* PanoWomanKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_WOMAN_KV));
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, strPanoWomanKv);
	ConfigurationManager::getInstance()->SetPanoWomanKv(strPanoWomanKv);

	// save pano woman ma text
	CString strPanoWomanMa;
	CEdit* PanoWomanMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_WOMAN_MA));
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, strPanoWomanMa);
	ConfigurationManager::getInstance()->SetPanoWomanMa(strPanoWomanMa);

	// save pano child kv text
	CString strPanoChildKv;
	CEdit* PanoChildKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_CHILD_KV));
	GetDlgItemText(IDC_EDIT_PANO_CHILD_KV, strPanoChildKv);
	ConfigurationManager::getInstance()->SetPanoChildKv(strPanoChildKv);

	// save pano child ma text
	CString strPanoChildMa;
	CEdit* PanoChildMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_CHILD_MA));
	GetDlgItemText(IDC_EDIT_PANO_CHILD_MA, strPanoChildMa);
	ConfigurationManager::getInstance()->SetPanoChildMa(strPanoChildMa);



}


void CSetting_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetPos(0);

	m_Setting_Tips.Create(this, TTS_ALWAYSTIP | TTS_BALLOON);
	m_Setting_Tips.SetMaxTipWidth(500); 

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOGO_MODE), _T("로고 모드를 선택합니다. 출력 시 Check"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOGO_NAME), _T("로고 이름을 지정합니다. (치과 이름 사용 가능) 기본값 : Osstem T2"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LANGUAGE), _T("사용 언어를 선택해 주세요"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_GPU), _T("현재 사용 중인 GPU Processor"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_AUTO_RETURN), _T("촬영 완료 후 장비 초기화 입니다. 사용 시 Check")); 
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_ETHERNET_SPEED_CHECK), _T("이더넷 스피드를 IP Address 와 함께 실시간 출력합니다. 출력 시 Check"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_ETHERNET_RESTART), _T("이더넷 스피드를 IP Address 와 함께 실시간 출력합니다. 출력 시 Check"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOG_DEBUG_MODE), _T("로그 파일에 디버깅 정보를 입력합니다. 사용 시 Check"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_EQUIPMENT), _T("현재 사용 중인 장비 이름을 출력합니다. 기본값 : T2"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_RESULT_CUTTING), _T("기본값 : 파노라마 이미지를 원본 그대로 저장, Preset 1, 2, 3 선택"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_MAN_KV), _T("남성 파노라마 촬영 관전압 기본값 설정 0~100 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_MAN_MA), _T("남성 파노라마 촬영 관전류 기본값 설정 0~100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_WOMAN_KV), _T("여성 파노라마 촬영 관전압 기본값 설정 0~100 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_WOMAN_MA), _T("여성 파노라마 촬영 관전압 기본값 설정 0~100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_CHILD_KV), _T("아동 파노라마 촬영 관전압 기본값 설정 0~100 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_CHILD_MA), _T("아동 파노라마 촬영 관전압 기본값 설정 0~100 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_BUTTON_SAVE_SETTING), _T("현재까지 변경 내용을 [Setting Section] 에 저장합니다."));
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_LOGO_NAME_EDIT), _T("원하는 로고 입력"));
	
	
	m_Setting_Tips.Activate(TRUE);

	/*CRect rcStatic(100, 100, 150, 120);
	Static.Create("test", WS_CHILDWINDOW | SS_NOTIFY, rcStatic, this, 1000);
	static.ModifyStyle(0, SS_NOTIFY);*/

}


// 툴팁 설정을 위한 메소드
BOOL CSetting_FormView::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	case WM_MOUSEMOVE:
	{ 
		m_Setting_Tips.RelayEvent(pMsg);
	}
	//if (pMsg->message == WM_LBUTTONDOWN)
	//{
	//	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_LANGUAGE)->GetSafeHwnd())
	//		AfxMessageBox("마우스 왼쪽 클릭");
	//}

	return CFormView::PreTranslateMessage(pMsg);
}


void CSetting_FormView::LoadData_Setting()
{
	CString language = ConfigurationManager::getInstance()->GetLanguage();

	if (language == _T("Korean"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(0);
	else if (language == _T("English"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(1);
	else if (language == _T("Chinese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(2);
	else if (language == _T("Japaness"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(3);
	else if (language == _T("Russian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(4);
	else if (language == _T("German"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(5);
	else if (language == _T("French"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(6);
	else if (language == _T("Spanish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(7);
	else if (language == _T("Portuguese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(8);
	else if (language == _T("Italian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(9);
	else if (language == _T("Vietnamese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(10);
	else if (language == _T("Thai"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(11);
	else if (language == _T("Malay"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(12);
	else if (language == _T("Indonesian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(13);
	else if (language == _T("Bengali"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(14);
	else if (language == _T("Kazakh"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(15);
	else if (language == _T("Ukrainian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(16);
	else if (language == _T("Uzbek"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(17);
	else if (language == _T("Mongolian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(18);
	else if (language == _T("Arabic"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(19);
	else if (language == _T("Hebrew"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(20);
	else if (language == _T("Turkish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(21);
	
	// LogoName 항목 불러와서 표시
	CString strLogoName = ConfigurationManager::getInstance()->GetLogoName();
	SetDlgItemText(IDC_EDIT_LOGO_NAME, strLogoName);

	// Equipment 항목 불러와서 표시
	CString strEquipment = ConfigurationManager::getInstance()->GetEquipment();
	SetDlgItemText(IDC_EDIT_EQUIPMENT, strEquipment);


	// GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	//CString strIPAddress = GetLocalIPAddress();
	
	//LPCSTR pszConvertedAnsiString = CT2A(strIPAddress);

	//DWORD dwIP = inet_addr(pszConvertedAnsiString);
	//BYTE* pbIP = (BYTE*)&dwIP;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	

	 // GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	CString strIPAddress = GetLocalIPAddress();

	// CString에서 LPCWSTR로 변환
	//LPCWSTR pszConvertedWideString = CT2W(strIPAddress);
	LPCWSTR pszConvertedWideString = LPCWSTR(strIPAddress);
	IN_ADDR ipAddr;
	InetPton(AF_INET, pszConvertedWideString, &ipAddr);

	BYTE* pbIP = (BYTE*)&ipAddr.S_un.S_addr;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	int nFIndCount = strIPAddress.Find(_T("."));
	int nBuff[10];
	int nIndexCount = 0;
	while(1)
	{
		nFIndCount = strIPAddress.Find(_T("."));
		if (nFIndCount > -1)
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress.Left(nFIndCount));
			strIPAddress = strIPAddress.Mid(nFIndCount + 1, strIPAddress.GetLength());
		}
		else
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress);
			break;
		}
		nIndexCount++;
	}
	nIndexCount = 0;
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++]);


	// 4. IDC_GPU_EDIT 에디트 컨트롤에 값을 설정
	CString gpuInfo = this->GetGPUInfo();
	SetDlgItemText(IDC_GPU_EDIT, gpuInfo);
	
	
	CString logo_mode = ConfigurationManager::getInstance()->GetLogoMode();
	if (logo_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(FALSE);

	CString logo_name = ConfigurationManager::getInstance()->GetLogoName();

	CString auto_return = ConfigurationManager::getInstance()->GetAutoReturn();
	if (auto_return == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(FALSE);

	CString ethernet_speed_check = ConfigurationManager::getInstance()->GetEthernetSpeedCheck();
	if (ethernet_speed_check == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(FALSE);

	CString log_debug_mode = ConfigurationManager::getInstance()->GetLogDebugMode();
	if (log_debug_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->SetCheck(FALSE);

	CString ethernet_restart = ConfigurationManager::getInstance()->GetEthernetRestart();
	if (ethernet_restart == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(FALSE);

	CString pano_result_cutting = ConfigurationManager::getInstance()->GetPanoResultCutting();
	if (pano_result_cutting == _T("0"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(0);
	else if (pano_result_cutting == _T("1"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(1);
	else if (pano_result_cutting == _T("2"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(2);
	else if (pano_result_cutting == _T("3"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(3);


	//Slider Control 과 Edit Control 값 연동
	CString pano_man_kv = ConfigurationManager::getInstance()->GetPanoManKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetPos(_ttoi(pano_man_kv));
	SetDlgItemText(IDC_EDIT_PANO_MAN_KV, pano_man_kv);
	
	CString pano_man_ma = ConfigurationManager::getInstance()->GetPanoManMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_MAN_MA))->SetPos(_ttoi(pano_man_ma));
	SetDlgItemText(IDC_EDIT_PANO_MAN_MA, pano_man_ma);
	
	CString pano_woman_kv = ConfigurationManager::getInstance()->GetPanoWomanKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_WOMAN_KV))->SetPos(_ttoi(pano_woman_kv));
	SetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, pano_woman_kv);	

	CString pano_woman_ma = ConfigurationManager::getInstance()->GetPanoWomanMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_WOMAN_KV))->SetPos(_ttoi(pano_woman_ma));
	SetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, pano_woman_ma);

	CString pano_child_kv = ConfigurationManager::getInstance()->GetPanoChildKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_CHILD_KV))->SetPos(_ttoi(pano_child_kv));
	SetDlgItemText(IDC_EDIT_PANO_CHILD_KV, pano_child_kv);

	CString pano_child_ma = ConfigurationManager::getInstance()->GetPanoChildMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_CHILD_KV))->SetPos(_ttoi(pano_child_ma));
	SetDlgItemText(IDC_EDIT_PANO_CHILD_MA, pano_child_ma);

	
}



void CSetting_FormView::OnBnClickedCheckEthernetRestart()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnCbnSelchangeComboLanguage()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnIpnFieldchangedLoadButton(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMIPADDRESS pIPAddr = reinterpret_cast<LPNMIPADDRESS>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}



void CSetting_FormView::OnEnChangeEditEquipment()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

// Slider control 활용한 유형별 관전압, 관전류 기본값 및 범위 조절
void CSetting_FormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	if (IDC_SLIDER_PANO_MAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_MAN_KV, strPos);
	}

	else if (IDC_SLIDER_PANO_MAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_MAN_MA, strPos);
	}
	   
	else if (IDC_SLIDER_PANO_WOMAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, strPos);
	}

	else if (IDC_SLIDER_PANO_WOMAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, strPos);
	}

	else if (IDC_SLIDER_PANO_CHILD_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_CHILD_KV, strPos);
	}

	else if (IDC_SLIDER_PANO_CHILD_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_CHILD_MA, strPos);
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CSetting_FormView::OnEnChangeEditPanoManKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_MAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->SetPos(nValue);

	TRACE(str);
}


void CSetting_FormView::OnEnChangeEditPanoManMa()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_MAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->SetPos(nValue);

	TRACE(str);
}


void CSetting_FormView::OnEnChangeEditPanoWomanKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->SetPos(nValue);

	TRACE(str);
}


void CSetting_FormView::OnEnChangeEditPanoWomanMa()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->SetPos(nValue);

	TRACE(str);
}


void CSetting_FormView::OnEnChangeEditPanoChildKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_CHILD_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->SetPos(nValue);

	TRACE(str);
}


void CSetting_FormView::OnEnChangeEditPanoChildMa()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_CHILD_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->SetPos(nValue);

	TRACE(str);
}

void CSetting_FormView::OnDeltaposSpinPanoManKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_MAN_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->SetPos(nValue);

	}

	*pResult = 0;
}

void CSetting_FormView::OnDeltaposSpinPanoManMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
		// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_MAN_MA, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->SetPos(nValue);

	}
	*pResult = 0;
}


void CSetting_FormView::OnDeltaposSpinPanoWomanKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
		// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_WOMAN_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->SetPos(nValue);

	}
	*pResult = 0;
}


void CSetting_FormView::OnDeltaposSpinPanoWomanMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
		// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_WOMAN_MA, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->SetPos(nValue);

	}
	*pResult = 0;
}


void CSetting_FormView::OnDeltaposSpinPanoChildKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
		// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_CHILD_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->SetPos(nValue);

	}
	*pResult = 0;
}


void CSetting_FormView::OnDeltaposSpinPanoChildMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
		// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_CHILD_MA, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->SetPos(nValue);

	}
	*pResult = 0;
}


void CSetting_FormView::OnStnClickedStaticLogDebugMode()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
