﻿// CT_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "CT_FormView.h"
#include "ConfigurationManager.h"

// CCT_FormView

IMPLEMENT_DYNCREATE(CCT_FormView, CFormView)

CCT_FormView::CCT_FormView()
	: CFormView(IDD_CT_DIALOG)
{

}

CCT_FormView::~CCT_FormView()
{
}

void CCT_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCT_FormView, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_CT, &CCT_FormView::OnBnClickedButtonSaveCt)
	ON_EN_CHANGE(IDC_EDIT_KV, &CCT_FormView::OnEnChangeEditKv)
	ON_EN_CHANGE(IDC_EDIT_MA, &CCT_FormView::OnEnChangeEditMa)
	ON_WM_HSCROLL()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_KV, &CCT_FormView::OnDeltaposSpinKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_MA, &CCT_FormView::OnDeltaposSpinMa)
END_MESSAGE_MAP()


// CCT_FormView 진단

#ifdef _DEBUG
void CCT_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCT_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCT_FormView 메시지 처리기
void CCT_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetPos(0);




	m_CT_Tips.Create(this, TTS_ALWAYSTIP | TTS_BALLOON);
	m_CT_Tips.SetMaxTipWidth(500);
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_FRAME_NUMBER), _T("CT 촬영 시 Recon 에서 사용되는 프레임의 수"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_BINNING_MODE), _T("픽셀 비닝, 센서에 따라 모드 고정"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_KV), _T("CT 촬영 모드 선택 시 기본 관전압"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_MA), _T("CT 촬영 모드 선택 시 기본 관전류"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_TUBE_MODE), _T("CT 촬영 시 제너레이터 모드 선택"));

	m_CT_Tips.Activate(TRUE);

}


void CCT_FormView::LoadData_CT()
{
	CString strFrameNumber = ConfigurationManager::getInstance()->GetFrameNumber();
	SetDlgItemText(IDC_EDIT_FRAME_NUMBER, strFrameNumber);

	CString strBinningMode = ConfigurationManager::getInstance()->GetBinningMode();
	SetDlgItemText(IDC_CHECK_BINNING_MODE, strBinningMode);

	CString strKv = ConfigurationManager::getInstance()->GetKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_KV))->SetPos(_ttoi(strKv));
	SetDlgItemText(IDC_EDIT_KV, strKv);

	CString strMa = ConfigurationManager::getInstance()->GetMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_MA))->SetPos(_ttoi(strMa));
	SetDlgItemText(IDC_EDIT_MA, strMa);

	CString strTubeMode = ConfigurationManager::getInstance()->GetTubeMode();
	if (strTubeMode == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(FALSE);
		SetDlgItemText(IDC_RADIO_DEFAULT, strTubeMode);
	}
	else if (strTubeMode == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(FALSE);
		SetDlgItemText(IDC_RADIO_PERSON, strTubeMode);
	}
	else if (strTubeMode == _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(TRUE);
		SetDlgItemText(IDC_RADIO_CONTINUE, strTubeMode);
	}
	

	// Sensor 값에 따라 Varian & Sen1 항목 선택 적용

	CString strEmptyFrameValueVarian1 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_1, strEmptyFrameValueVarian1);

	CString strEmptyFrameValueVarian2 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_2, strEmptyFrameValueVarian2);

	CString strEmptyFrameValueVarian3 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian3();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_3, strEmptyFrameValueVarian3);

	CString strEmptyFrameValueSen11 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_1, strEmptyFrameValueSen11);

	CString strEmptyFrameValueSen12 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_2, strEmptyFrameValueSen12);

	CString strEmptyFrameValueSen13 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen13();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_3, strEmptyFrameValueSen13);

	CString strEmptyFrameValueVarian1r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_1_R, strEmptyFrameValueVarian1r);

	CString strEmptyFrameValueVarian2r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_2_R, strEmptyFrameValueVarian2r);

	CString strEmptyFrameValueSen11r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_1_R, strEmptyFrameValueSen11r);

	CString strEmptyFrameValueSen12r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_2_R, strEmptyFrameValueSen12r);

	CString strMAR = ConfigurationManager::getInstance()->GetMAR();
	if (strMAR == _T("on"))
		((CButton*)GetDlgItem(IDC_CHECK_MAR))->SetCheck(TRUE);
	else if (strMAR == _T("off"))
		((CButton*)GetDlgItem(IDC_CHECK_MAR))->SetCheck(FALSE);

	CString strVolumeWidth = ConfigurationManager::getInstance()->GetVolumeWidth();
	SetDlgItemText(IDC_EDIT_VOLUME_WIDTH, strVolumeWidth);

	CString strVolumeHeight = ConfigurationManager::getInstance()->GetVolumeHeight();
	SetDlgItemText(IDC_EDIT_VOLUME_HEIGHT, strVolumeHeight);

	CString strVolumePitch = ConfigurationManager::getInstance()->GetVolumePitch();
	SetDlgItemText(IDC_EDIT_VOLUME_PITCH, strVolumePitch);

	CString strVolumeOffset_x = ConfigurationManager::getInstance()->GetVolumeOffset_x();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_X, strVolumeOffset_x);

	CString strVolumeOffset_y = ConfigurationManager::getInstance()->GetVolumeOffset_y();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_Y, strVolumeOffset_y);

	CString strVolumeOffset_z = ConfigurationManager::getInstance()->GetVolumeOffset_z();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_Z, strVolumeOffset_z);

	CButton m_Radio_Continue;
//	CButton pButton = ConfigurationManager::getInstance()->GetTubeMode();


}


BOOL CCT_FormView::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	case WM_MOUSEMOVE:
	{ 
		m_CT_Tips.RelayEvent(pMsg);
	}
	//if (pMsg->message == WM_LBUTTONDOWN)
	//{
	//	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_LANGUAGE)->GetSafeHwnd())
	//		AfxMessageBox("마우스 왼쪽 클릭");
	//}

	return CFormView::PreTranslateMessage(pMsg);
}


void CCT_FormView::OnBnClickedButtonSaveCt()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	CString strEmptyFrameValueVarian1;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian1(strEmptyFrameValueVarian1);
	CString strEmptyFrameValueVarian2;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian2(strEmptyFrameValueVarian2);
	CString strEmptyFrameValueVarian3;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian3(strEmptyFrameValueVarian3);

	CString strEmptyFrameValueSen11;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen11(strEmptyFrameValueSen11);
	CString strEmptyFrameValueSen12;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen12(strEmptyFrameValueSen12);
	CString strEmptyFrameValueSen13;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen13(strEmptyFrameValueSen13);

	CString strEmptyFrameValueVarian1r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian1R(strEmptyFrameValueVarian1r);
	CString strEmptyFrameValueVarian2r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian2R(strEmptyFrameValueVarian2r);

	CString strEmptyFrameValueSen11r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen11R(strEmptyFrameValueSen11r);
	CString strEmptyFrameValueSen12r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen12R(strEmptyFrameValueSen12r);



}


void CCT_FormView::OnEnChangeEditKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString strKv = _T("");
	GetDlgItemText(IDC_EDIT_KV, strKv);
	int nValueKv;
	nValueKv = _ttoi(strKv);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV))->SetPos(nValueKv);

	TRACE(strKv);
}


void CCT_FormView::OnEnChangeEditMa()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->SetPos(nValue);

	TRACE(str);
}



void CCT_FormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
	if (IDC_SLIDER_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_KV, strPos);
	}

	else if (IDC_SLIDER_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_MA, strPos);
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CCT_FormView::OnDeltaposSpinKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV))->SetPos(nValue);

	}

	*pResult = 0;
}


void CCT_FormView::OnDeltaposSpinMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_MA, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->SetPos(nValue);

	}
	*pResult = 0;
}

