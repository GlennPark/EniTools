﻿#pragma once



// CFov_FormView 폼 보기

class CFov_FormView : public CFormView
{
	DECLARE_DYNCREATE(CFov_FormView)

protected:
	CFov_FormView();           // 동적 만들기에 사용되는 protected 생성자입니다.
	virtual ~CFov_FormView();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FOV_DIALOG };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
};


