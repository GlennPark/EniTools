#pragma once


class ConfigurationManager
{
private:
	static ConfigurationManager* m_instance;
	CString m_strPath;

private:
	explicit ConfigurationManager();
	~ConfigurationManager();

public:
	static ConfigurationManager* getInstance();

	void SetIniPath(CString path);

	// add get / set

	//Setting Section

	void SetData(const CString section, const CString key, const CString data);
	CString GetData(const CString section, const CString key);

	void SetLanguage(const CString data);
	CString GetLanguage();

	void SetLogoMode(const CString data);
	CString GetLogoMode();

	void SetLogoName(const CString data);
	CString GetLogoName();

	void SetAutoReturn(const CString data);
	CString GetAutoReturn();

	void SetEthernetSpeedCheck(const CString data);
	CString GetEthernetSpeedCheck();

	void SetLogDebugMode(const CString data);
	CString GetLogDebugMode();

	void SetEquipment(const CString data);
	CString GetEquipment();

	void SetEthernetRestart(const CString data);
	CString GetEthernetRestart();

	void SetPanoResultCutting(const CString data);
	CString GetPanoResultCutting();

	void SetPanoManKv(const CString data);
	CString GetPanoManKv();
	
	void SetPanoManMa(const CString data);
	CString GetPanoManMa();

	void SetPanoWomanKv(const CString data);
	CString GetPanoWomanKv();

	void SetPanoWomanMa(const CString data);
	CString GetPanoWomanMa();
	
	void SetPanoChildKv(const CString data);
	CString GetPanoChildKv();
	
	void SetPanoChildMa(const CString data);
	CString GetPanoChildMa();

	//CT Section

	void SetFrameNumber(const CString data);
	CString GetFrameNumber();

	void SetBinningMode(const CString data);
	CString GetBinningMode();

	void SetKv(const CString data);
	CString GetKv();

	void SetMa(const CString data);
	CString GetMa();

	void SetTubeMode(const CString data);
	CString GetTubeMode();

	void SetEmptyFrameValueVarian1(const CString data);
	CString GetEmptyFrameValueVarian1();

	void SetEmptyFrameValueVarian2(const CString data);
	CString GetEmptyFrameValueVarian2();

	void SetEmptyFrameValueVarian3(const CString data);
	CString GetEmptyFrameValueVarian3();

	void SetEmptyFrameValueSen11(const CString data);
	CString GetEmptyFrameValueSen11();

	void SetEmptyFrameValueSen12(const CString data);
	CString GetEmptyFrameValueSen12();

	void SetEmptyFrameValueSen13(const CString data);
	CString GetEmptyFrameValueSen13();

	void SetEmptyFrameValueVarian1R(const CString data);
	CString GetEmptyFrameValueVarian1R();

	void SetEmptyFrameValueVarian2R(const CString data);
	CString GetEmptyFrameValueVarian2R();

	void SetEmptyFrameValueSen11R(const CString data);
	CString GetEmptyFrameValueSen11R();

	void SetEmptyFrameValueSen12R(const CString data);
	CString GetEmptyFrameValueSen12R();

};