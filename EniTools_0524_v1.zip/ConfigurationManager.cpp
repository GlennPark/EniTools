#include "pch.h"
#include "ConfigurationManager.h"

ConfigurationManager* ConfigurationManager::m_instance = nullptr;
ConfigurationManager::ConfigurationManager()
{}

ConfigurationManager::~ConfigurationManager()
{}

ConfigurationManager* ConfigurationManager::getInstance()
{
	if (m_instance == nullptr)
		m_instance = new ConfigurationManager();

	return m_instance;
}

void ConfigurationManager::SetIniPath(CString path)
{
	m_strPath = path;
}

void ConfigurationManager::SetData(const CString section, const CString key, const CString data)
{
	WritePrivateProfileString(section, key, data, m_strPath);
}

CString ConfigurationManager::GetData(const CString section, const CString key)
{
	CString strData;
	TCHAR _data[256];
	// ���� ������ �߻� C6386
	// �������� : sizeof -1
	GetPrivateProfileString(section, key, NULL, _data, sizeof(_data-1), m_strPath);

	strData = CString(_data);
	return strData;
}

void ConfigurationManager::SetLanguage(const CString data)
{
	SetData(_T("Setting"), _T("language"), data);
}

CString ConfigurationManager::GetLanguage()
{
	return GetData(_T("Setting"), _T("language"));
}


void ConfigurationManager::SetLogoMode(const CString data)
{
	SetData(_T("Setting"), _T("logo_mode"), data);
}

CString ConfigurationManager::GetLogoMode()
{
	return GetData(_T("Setting"), _T("logo_mode"));
}

void ConfigurationManager::SetLogoName(const CString data)
{
	SetData(_T("Setting"), _T("logo_Name"), data);
}

CString ConfigurationManager::GetLogoName()
{
	return GetData(_T("Setting"), _T("logo_name"));
}

void ConfigurationManager::SetAutoReturn(const CString data)
{
	SetData(_T("Setting"), _T("auto_return"), data);
}

CString ConfigurationManager::GetAutoReturn()
{
	return GetData(_T("Setting"), _T("auto_return"));
}

void ConfigurationManager::SetEthernetSpeedCheck(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_speed_check"), data);
}

CString ConfigurationManager::GetEthernetSpeedCheck()
{
	return GetData(_T("Setting"), _T("ethernet_speed_check"));
}

void ConfigurationManager::SetLogoDebugMode(const CString data)
{
	SetData(_T("Setting"), _T("logo_debug_mode"), data);
}

CString ConfigurationManager::GetLogoDebugMode()
{
	return GetData(_T("Setting"), _T("logo_debug_mode"));
}

void ConfigurationManager::SetEquipment(const CString data)
{
	SetData(_T("Setting"), _T("equipment"), data);
}

CString ConfigurationManager::GetEquipment()
{
	return GetData(_T("Setting"), _T("equipment"));
}

void ConfigurationManager::SetEthernetRestart(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_restart"), data);
}

CString ConfigurationManager::GetEthernetRestart()
{
	return GetData(_T("Setting"), _T("ethernet_restart"));
}

void ConfigurationManager::SetPanoResultCutting(const CString data)
{
	SetData(_T("Setting"), _T("pano_result_cutting"), data);
}

CString ConfigurationManager::GetPanoResultCutting()
{
	return GetData(_T("Setting"), _T("pano_result_cutting"));
}

void ConfigurationManager::SetPanoManKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_kv"), data);
}

CString ConfigurationManager::GetPanoManKv()
{
	return GetData(_T("Setting"), _T("pano_man_kv"));
}

void ConfigurationManager::SetPanoManMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_ma"), data);
}

CString ConfigurationManager::GetPanoManMa()
{
	return GetData(_T("Setting"), _T("pano_man_ma"));
}

void ConfigurationManager::SetPanoWomanKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_kv"), data);
}

CString ConfigurationManager::GetPanoWomanKv()
{
	return GetData(_T("Setting"), _T("pano_woman_kv"));
}

void ConfigurationManager::SetPanoWomanMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_ma"), data);
}

CString ConfigurationManager::GetPanoWomanMa()
{
	return GetData(_T("Setting"), _T("pano_woman_ma"));
}

void ConfigurationManager::SetPanoChildKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_kv"), data);
}

CString ConfigurationManager::GetPanoChildKv()
{
	return GetData(_T("Setting"), _T("pano_child_kv"));
}

void ConfigurationManager::SetPanoChildMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_ma"), data);
}

CString ConfigurationManager::GetPanoChildMa()
{
	return GetData(_T("Setting"), _T("pano_child_ma"));
}

