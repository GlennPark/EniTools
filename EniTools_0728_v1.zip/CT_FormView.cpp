﻿// CT_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "CT_FormView.h"
#include "ConfigurationManager.h"

#include "Warnning_Dialog.h"

// CCT_FormView

IMPLEMENT_DYNCREATE(CCT_FormView, CFormView)

CCT_FormView::CCT_FormView()
	: CFormView(IDD_CT_DIALOG)
{

}

CCT_FormView::~CCT_FormView()
{
}

void CCT_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCT_FormView, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_CT, &CCT_FormView::OnBnClickedButtonSaveCt)
	ON_EN_CHANGE(IDC_EDIT_KV, &CCT_FormView::OnEnChangeEditKv)
	ON_EN_CHANGE(IDC_EDIT_MA, &CCT_FormView::OnEnChangeEditMa)
	ON_WM_HSCROLL()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_KV, &CCT_FormView::OnDeltaposSpinKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_MA, &CCT_FormView::OnDeltaposSpinMa)

	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CCT_FormView 진단

#ifdef _DEBUG
void CCT_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCT_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCT_FormView 메시지 처리기
void CCT_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetPos(0);

	
	




	// 항목별 도움말 정리
	m_CT_Tips.Create(this, TTS_ALWAYSTIP | TTS_BALLOON);
	m_CT_Tips.SetMaxTipWidth(500);
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_FRAME_NUMBER), _T("CT 촬영 시 Recon 에서 사용되는 프레임의 수"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_BINNING_MODE), _T("픽셀 비닝, 센서에 따라 모드 고정"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_KV), _T("CT 촬영 모드 선택 시 기본 관전압"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_MA), _T("CT 촬영 모드 선택 시 기본 관전류"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_TUBE_MODE), _T("CT 촬영 시 제너레이터 모드 선택"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_RADIO_PULSE), _T("비활성화된 항목입니다"));


	m_CT_Tips.Activate(TRUE);

}


void CCT_FormView::LoadData_CT()
{
	CString strFrameNumber = ConfigurationManager::getInstance()->GetFrameNumber();
	SetDlgItemText(IDC_EDIT_FRAME_NUMBER, strFrameNumber);

	CString strBinningMode = ConfigurationManager::getInstance()->GetBinningMode();
	if (strBinningMode == _T("0"))
	{
		SetDlgItemText(IDC_CHECK_BINNING_MODE, _T("비닝 모드를 사용중입니다."));
	}
	else if (strBinningMode == _T("1"))
	{
		SetDlgItemText(IDC_CHECK_BINNING_MODE, _T("비닝 모드를 사용하지 않습니다."));
	}
	//SetDlgItemText(IDC_CHECK_BINNING_MODE, strBinningMode);

	CString strKv = ConfigurationManager::getInstance()->GetKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_KV))->SetPos(_ttoi(strKv));
	SetDlgItemText(IDC_EDIT_KV, strKv);

	CString strMa = ConfigurationManager::getInstance()->GetMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_MA))->SetPos(_ttoi(strMa));
	SetDlgItemText(IDC_EDIT_MA, strMa);

	CString strTubeMode = ConfigurationManager::getInstance()->GetTubeMode();

	if (strTubeMode == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_PULSE))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUOUS))->SetCheck(FALSE);
	//	SetDlgItemText(IDC_RADIO_PERSON, strTubeMode);
	}
	else if (strTubeMode == _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_PULSE))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUOUS))->SetCheck(TRUE);
	//	SetDlgItemText(IDC_RADIO_CONTINUE, strTubeMode);
	}
	

	// Sensor 값에 따라 Varian & Sen1 항목 선택 적용

	CString strEmptyFrameValueVarian1 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_1, strEmptyFrameValueVarian1);

	CString strEmptyFrameValueVarian2 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_2, strEmptyFrameValueVarian2);

	CString strEmptyFrameValueVarian3 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian3();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_3, strEmptyFrameValueVarian3);

	CString strEmptyFrameValueSen11 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_1, strEmptyFrameValueSen11);

	CString strEmptyFrameValueSen12 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_2, strEmptyFrameValueSen12);

	CString strEmptyFrameValueSen13 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen13();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_3, strEmptyFrameValueSen13);

	CString strEmptyFrameValueVarian1r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_1_R, strEmptyFrameValueVarian1r);

	CString strEmptyFrameValueVarian2r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_VARIAN_2_R, strEmptyFrameValueVarian2r);

	CString strEmptyFrameValueSen11r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_1_R, strEmptyFrameValueSen11r);

	CString strEmptyFrameValueSen12r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12R();
	SetDlgItemText(IDC_EDIT_EMPTY_FRAME_VALUE_SEN1_2_R, strEmptyFrameValueSen12r);

	CString strMAR = ConfigurationManager::getInstance()->GetMAR();
	if (strMAR == _T("on"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_MAR))->SetCheck(TRUE);
	}
	else if (strMAR == _T("off"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_MAR))->SetCheck(FALSE);
	}

	CString strVolumeWidth = ConfigurationManager::getInstance()->GetVolumeWidth();
	SetDlgItemText(IDC_EDIT_VOLUME_WIDTH, strVolumeWidth);

	CString strVolumeHeight = ConfigurationManager::getInstance()->GetVolumeHeight();
	SetDlgItemText(IDC_EDIT_VOLUME_HEIGHT, strVolumeHeight);

	CString strVolumePitch = ConfigurationManager::getInstance()->GetVolumePitch();
	SetDlgItemText(IDC_EDIT_VOLUME_PITCH, strVolumePitch);

	CString strVolumeOffset_x = ConfigurationManager::getInstance()->GetVolumeOffset_x();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_X, strVolumeOffset_x);

	CString strVolumeOffset_y = ConfigurationManager::getInstance()->GetVolumeOffset_y();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_Y, strVolumeOffset_y);

	CString strVolumeOffset_z = ConfigurationManager::getInstance()->GetVolumeOffset_z();
	SetDlgItemText(IDC_EDIT_VOLUME_OFFSET_Z, strVolumeOffset_z);

	CString strPost = ConfigurationManager::getInstance()->GetPost();
	if (strPost == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_POST))->SetCheck(TRUE);
	}
	else if (strPost == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_POST))->SetCheck(FALSE);
	}

	CString strSensor = ConfigurationManager::getInstance()->GetSensor();
	
	if (strSensor = _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_VARIAN))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_SEN1))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_DRTECH))->SetCheck(FALSE);
	}
	else if (strSensor = _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_VARIAN))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_SEN1))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_DRTECH))->SetCheck(FALSE);
	}
	else if (strSensor = _T("3"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_VARIAN))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_SEN1))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_DRTECH))->SetCheck(TRUE);
	}

	CString strVmot = ConfigurationManager::getInstance()->GetVmot();
	SetDlgItemText(IDC_EDIT_VMOT, strVmot);

	CString strCTDataDrive = ConfigurationManager::getInstance()->GetCTDataDrive();
	SetDlgItemText(IDC_EDIT_CT_DATA_DRIVE, strCTDataDrive);

	CString strOne3dCheck = ConfigurationManager::getInstance()->GetOne3dCheck();
	if (strOne3dCheck == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_ONE3D))->SetCheck(TRUE);
	}
	else if (strOne3dCheck == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_ONE3D))->SetCheck(FALSE);
	}

	CString strExposureTime = ConfigurationManager::getInstance()->GetExposureTime();
	SetDlgItemText(IDC_EDIT_EXPOSURE_TIME, strExposureTime);

	CString strDAP = ConfigurationManager::getInstance()->GetDAP();
	SetDlgItemText(IDC_EDIT_DAP, strDAP);

	CString strFOVDefaultPosition = ConfigurationManager::getInstance()->GetFOVDefaultPosition();

	if (strSensor = _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FOV_FULLARCH))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_OCCLUSION))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_SINUS))->SetCheck(FALSE);
	}
	else if (strSensor = _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FOV_FULLARCH))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_OCCLUSION))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_SINUS))->SetCheck(FALSE);
	}
	else if (strSensor = _T("3"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_FOV_FULLARCH))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_OCCLUSION))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_FOV_SINUS))->SetCheck(TRUE);
	}

	CString strAutoDefectMode = ConfigurationManager::getInstance()->GetAutoDefectMode();
	if (strAutoDefectMode == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_DEFECT_MODE))->SetCheck(TRUE);
	}
	else if (strAutoDefectMode == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_DEFECT_MODE))->SetCheck(FALSE);
	}

	CString strDefaultMode = ConfigurationManager::getInstance()->GetDefaultMode();
	SetDlgItemText(IDC_COMBO_DEFAULT_MODE, strDefaultMode);

	if (strDefaultMode == _T("0"))
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(0);
	}
	else if (strDefaultMode == _T("1"))
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(1);
	}
	else if (strDefaultMode == _T("2"))
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(2);
	}
	
	CString strAirmap1x1Slope = ConfigurationManager::getInstance()->GetAirmap1x1Slope();
	SetDlgItemText(IDC_EDIT_AIRMAP_1X1_SLOPE, strAirmap1x1Slope);

	CString strAirmap1x1Add = ConfigurationManager::getInstance()->GetAirmap1x1Add();
	SetDlgItemText(IDC_EDIT_AIRMAP_1X1_ADD, strAirmap1x1Add);

	CString strAirmap2x2Slope = ConfigurationManager::getInstance()->GetAirmap2x2Slope();
	SetDlgItemText(IDC_EDIT_AIRMAP_2X2_SLOPE, strAirmap2x2Slope);

	CString strAirmap2x2Add = ConfigurationManager::getInstance()->GetAirmap2x2Add();
	SetDlgItemText(IDC_EDIT_AIRMAP_2X2_ADD, strAirmap2x2Add);

	CString strCTPostScriptVarex5x5 = ConfigurationManager::getInstance()->GetCTPostScriptVarex5x5();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_5X5, strCTPostScriptVarex5x5);
	CString strCTPostScriptVarex5x5High = ConfigurationManager::getInstance()->GetCTPostScriptVarex5x5High();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_5X5_HIGH, strCTPostScriptVarex5x5High);
	CString strCTPostScriptVarex5x5Low = ConfigurationManager::getInstance()->GetCTPostScriptVarex5x5Low();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_5X5_LOW, strCTPostScriptVarex5x5Low);
	CString strCTPostScriptVarex5x5UltraLow = ConfigurationManager::getInstance()->GetCTPostScriptVarex5x5UltraLow();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_5X5_ULTRA_LOW , strCTPostScriptVarex5x5UltraLow);

	CString strCTPostScriptVarex15x9 = ConfigurationManager::getInstance()->GetCTPostScriptVarex15x9();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_15X9, strCTPostScriptVarex15x9);
	CString strCTPostScriptVarex15x9High = ConfigurationManager::getInstance()->GetCTPostScriptVarex15x9High();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_15X9_HIGH, strCTPostScriptVarex15x9High);
	CString strCTPostScriptVarex15x9Low = ConfigurationManager::getInstance()->GetCTPostScriptVarex15x9Low();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_15X9_LOW, strCTPostScriptVarex15x9Low);
	CString strCTPostScriptVarex15x9UltraLow = ConfigurationManager::getInstance()->GetCTPostScriptVarex15x9UltraLow();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_VAREX_15X9_ULTRA_LOW, strCTPostScriptVarex15x9UltraLow);

	CString strCTPostScriptDrtech5x5 = ConfigurationManager::getInstance()->GetCTPostScriptDrtech5x5();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_5X5, strCTPostScriptDrtech5x5);
	CString strCTPostScriptDrtech5x5High = ConfigurationManager::getInstance()->GetCTPostScriptDrtech5x5High();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_5X5_HIGH, strCTPostScriptDrtech5x5High);
	CString strCTPostScriptDrtech5x5Low = ConfigurationManager::getInstance()->GetCTPostScriptDrtech5x5Low();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_5X5_LOW, strCTPostScriptDrtech5x5Low);
	CString strCTPostScriptDrtech5x5UltraLow = ConfigurationManager::getInstance()->GetCTPostScriptDrtech5x5UltraLow();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_5X5_ULTRA_LOW, strCTPostScriptDrtech5x5UltraLow);

	CString strCTPostScriptDrtech15x9 = ConfigurationManager::getInstance()->GetCTPostScriptDrtech15x9();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_15X9, strCTPostScriptDrtech15x9);
	CString strCTPostScriptDrtech15x9High = ConfigurationManager::getInstance()->GetCTPostScriptDrtech15x9High();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_15X9_HIGH, strCTPostScriptDrtech15x9High);
	CString strCTPostScriptDrtech15x9Low = ConfigurationManager::getInstance()->GetCTPostScriptDrtech15x9Low();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_15X9_LOW, strCTPostScriptDrtech15x9Low);
	CString strCTPostScriptDrtech15x9UltraLow = ConfigurationManager::getInstance()->GetCTPostScriptDrtech15x9UltraLow();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_DRTECH_15X9_ULTRA_LOW, strCTPostScriptDrtech15x9UltraLow);

	CString strCTPostScriptSen15x5 = ConfigurationManager::getInstance()->GetCTPostScriptSen15x5();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_SEN1_5X5, strCTPostScriptSen15x5);
	CString strCTPostScriptSen115x9 = ConfigurationManager::getInstance()->GetCTPostScriptSen115x9();
	SetDlgItemText(IDC_EDIT_CT_POST_SCRIPT_SEN1_15X9, strCTPostScriptSen115x9);


	// Write 값 (수정 불필요)
	CString strLastModeMemory = ConfigurationManager::getInstance()->GetLastModeMemory();
	SetDlgItemText(IDC_EDIT_LAST_MODE_MEMORY, strLastModeMemory);

	CString strDOSE = ConfigurationManager::getInstance()->GetDOSE();
	SetDlgItemText(IDC_EDIT_DOSE, strDOSE);

	CString strCTDI = ConfigurationManager::getInstance()->GetCTDI();
	SetDlgItemText(IDC_EDIT_CTDI, strCTDI);




	//CString strPost = ConfigurationManager::getInstance()->();


//	CButton pButton = ConfigurationManager::getInstance()->GetTubeMode();


}


BOOL CCT_FormView::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	case WM_MOUSEMOVE:
	{ 
		m_CT_Tips.RelayEvent(pMsg);
	}
	//if (pMsg->message == WM_LBUTTONDOWN)
	//{
	//	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_LANGUAGE)->GetSafeHwnd())
	//		AfxMessageBox("마우스 왼쪽 클릭");
	//}

	return CFormView::PreTranslateMessage(pMsg);
}


void CCT_FormView::OnBnClickedButtonSaveCt()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	CString strEmptyFrameValueVarian1;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian1(strEmptyFrameValueVarian1);
	CString strEmptyFrameValueVarian2;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian2(strEmptyFrameValueVarian2);
	CString strEmptyFrameValueVarian3;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian3(strEmptyFrameValueVarian3);

	CString strEmptyFrameValueSen11;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen11(strEmptyFrameValueSen11);
	CString strEmptyFrameValueSen12;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen12(strEmptyFrameValueSen12);
	CString strEmptyFrameValueSen13;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen13(strEmptyFrameValueSen13);

	CString strEmptyFrameValueVarian1r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian1R(strEmptyFrameValueVarian1r);
	CString strEmptyFrameValueVarian2r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueVarian2R(strEmptyFrameValueVarian2r);

	CString strEmptyFrameValueSen11r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen11R(strEmptyFrameValueSen11r);
	CString strEmptyFrameValueSen12r;
	ConfigurationManager::getInstance()->SetEmptyFrameValueSen12R(strEmptyFrameValueSen12r);



}


void CCT_FormView::OnEnChangeEditKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString strKv = _T("");
	GetDlgItemText(IDC_EDIT_KV, strKv);
	int nValueKv;
	nValueKv = _ttoi(strKv);
	CSliderCtrl* slider = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV));
	if (slider)
	{
		slider->SetPos(nValueKv);
	}
	
	TRACE(strKv);
}


void CCT_FormView::OnEnChangeEditMa()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString strMa = _T("");
	GetDlgItemText(IDC_EDIT_MA, strMa);
	int nValueMa;
	nValueMa = _ttoi(strMa);
	//((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->SetPos(nValueMa);
	CSliderCtrl* slider = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA));
	if (slider)
	{
		slider->SetPos(nValueMa);
	}

	TRACE(strMa);
}



void CCT_FormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
	if (IDC_SLIDER_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_KV, strPos);
	}

	else if (IDC_SLIDER_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_MA, strPos);
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CCT_FormView::OnDeltaposSpinKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_KV))->SetPos(nValue);

	}

	*pResult = 0;
}


void CCT_FormView::OnDeltaposSpinMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_MA, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_MA))->SetPos(nValue);

	}
	*pResult = 0;
}



void CCT_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
	
}
