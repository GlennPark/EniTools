﻿#pragma once
#include "afxdialogex.h"


// CWarnning_Dialog 대화 상자

class CWarnning_Dialog : public CDialogEx
{
	DECLARE_DYNAMIC(CWarnning_Dialog)

public:
	CWarnning_Dialog(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CWarnning_Dialog();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_WARNNING };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
};
