﻿// Warnning_Dialog.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "afxdialogex.h"
#include "Warnning_Dialog.h"


// CWarnning_Dialog 대화 상자

IMPLEMENT_DYNAMIC(CWarnning_Dialog, CDialogEx)

CWarnning_Dialog::CWarnning_Dialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_WARNNING, pParent)
{

}

CWarnning_Dialog::~CWarnning_Dialog()
{
}

void CWarnning_Dialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CWarnning_Dialog, CDialogEx)
END_MESSAGE_MAP()


// CWarnning_Dialog 메시지 처리기
