﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"
#include "ConfigurationManager.h"

#include "Warnning_Dialog.h"

#include <dxgi.h> 
#include <d3d11.h> 
#pragma comment (lib, "dxgi.lib")
#pragma comment (lib, "d3d11.lib")


#include <winsock2.h>  
#pragma comment(lib, "ws2_32.lib")  // Winsock 라이브러리 링크
// CSetting_FormView

#include <WS2tcpip.h>

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
	ON_EN_CHANGE(IDC_GPU_EDIT, &CSetting_FormView::OnEnChangeGpuEdit)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_SETTING, &CSetting_FormView::OnBnClickedSaveSettingButton)
	ON_EN_CHANGE(IDC_LOGO_NAME_EDIT, &CSetting_FormView::OnChangeLogoNameEdit)
	ON_EN_CHANGE(IDC_EDIT_EQUIPMENT, &CSetting_FormView::OnEnChangeEditEquipment)
	ON_WM_HSCROLL()
	ON_EN_CHANGE(IDC_EDIT_PANO_MAN_KV, &CSetting_FormView::OnEnChangeEditPanoManKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_MAN_MA, &CSetting_FormView::OnEnChangeEditPanoManMa)
	ON_EN_CHANGE(IDC_EDIT_PANO_WOMAN_KV, &CSetting_FormView::OnEnChangeEditPanoWomanKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_WOMAN_MA, &CSetting_FormView::OnEnChangeEditPanoWomanMa)
	ON_EN_CHANGE(IDC_EDIT_PANO_CHILD_KV, &CSetting_FormView::OnEnChangeEditPanoChildKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_CHILD_MA, &CSetting_FormView::OnEnChangeEditPanoChildMa)
	ON_EN_CHANGE(IDC_EDIT_PANO_TEEN_KV, &CSetting_FormView::OnEnChangeEditPanoTeenKv)
	ON_EN_CHANGE(IDC_EDIT_PANO_TEEN_MA, &CSetting_FormView::OnEnChangeEditPanoTeenMa)
	ON_EN_CHANGE(IDC_EDIT_CEPH_MAN_KV, &CSetting_FormView::OnEnChangeEditCephManKv)
	ON_EN_CHANGE(IDC_EDIT_CEPH_MAN_MA, &CSetting_FormView::OnEnChangeEditCephManMa)
	ON_EN_CHANGE(IDC_EDIT_CEPH_WOMAN_KV, &CSetting_FormView::OnEnChangeEditCephWomanKv)
	ON_EN_CHANGE(IDC_EDIT_CEPH_WOMAN_MA, &CSetting_FormView::OnEnChangeEditCephWomanMa)
	ON_EN_CHANGE(IDC_EDIT_CEPH_CHILD_KV, &CSetting_FormView::OnEnChangeEditCephChildKv)
	ON_EN_CHANGE(IDC_EDIT_CEPH_CHILD_MA, &CSetting_FormView::OnEnChangeEditCephChildMa)
	ON_EN_CHANGE(IDC_EDIT_CEPH_TEEN_KV, &CSetting_FormView::OnEnChangeEditCephTeenKv)
	ON_EN_CHANGE(IDC_EDIT_CEPH_TEEN_MA, &CSetting_FormView::OnEnChangeEditCephTeenMa)
	ON_EN_CHANGE(IDC_EDIT_CEPH_CARPUS_KV, &CSetting_FormView::OnEnChangeEditCephCarpusKv)
	ON_EN_CHANGE(IDC_EDIT_CEPH_CARPUS_MA, &CSetting_FormView::OnEnChangeEditCephCarpusMa)
	ON_EN_CHANGE(IDC_EDIT_CT_MAN_KV, &CSetting_FormView::OnEnChangeEditCtManKv)
	ON_EN_CHANGE(IDC_EDIT_CT_MAN_MA, &CSetting_FormView::OnEnChangeEditCtManMa)
	ON_EN_CHANGE(IDC_EDIT_CT_WOMAN_KV, &CSetting_FormView::OnEnChangeEditCtWomanKv)
	ON_EN_CHANGE(IDC_EDIT_CT_WOMAN_MA, &CSetting_FormView::OnEnChangeEditCtWomanMa)
	ON_EN_CHANGE(IDC_EDIT_CT_CHILD_KV, &CSetting_FormView::OnEnChangeEditCtChildKv)
	ON_EN_CHANGE(IDC_EDIT_CT_CHILD_MA, &CSetting_FormView::OnEnChangeEditCtChildMa)
	ON_EN_CHANGE(IDC_EDIT_CT_TEEN_KV, &CSetting_FormView::OnEnChangeEditCtTeenKv)
	ON_EN_CHANGE(IDC_EDIT_CT_TEEN_MA, &CSetting_FormView::OnEnChangeEditCtTeenMa)
	ON_EN_CHANGE(IDC_EDIT_CT_LOW_KV, &CSetting_FormView::OnEnChangeEditCtLowKv)
	ON_EN_CHANGE(IDC_EDIT_CT_LOW_MA, &CSetting_FormView::OnEnChangeEditCtLowMa)
	ON_EN_CHANGE(IDC_EDIT_CT_ULTRA_LOW_KV, &CSetting_FormView::OnEnChangeEditCtUltraLowKv)
	ON_EN_CHANGE(IDC_EDIT_CT_ULTRA_LOW_MA, &CSetting_FormView::OnEnChangeEditCtUltraLowMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_MAN_MA, &CSetting_FormView::OnDeltaposSpinPanoManMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_MAN_KV, &CSetting_FormView::OnDeltaposSpinPanoManKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_WOMAN_KV, &CSetting_FormView::OnDeltaposSpinPanoWomanKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_WOMAN_MA, &CSetting_FormView::OnDeltaposSpinPanoWomanMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_CHILD_KV, &CSetting_FormView::OnDeltaposSpinPanoChildKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_CHILD_MA, &CSetting_FormView::OnDeltaposSpinPanoChildMa)	
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_TEEN_KV, &CSetting_FormView::OnDeltaposSpinPanoTeenKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_PANO_TEEN_MA, &CSetting_FormView::OnDeltaposSpinPanoTeenMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_MAN_KV, &CSetting_FormView::OnDeltaposSpinCephManKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_MAN_MA, &CSetting_FormView::OnDeltaposSpinCephManMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_WOMAN_KV, &CSetting_FormView::OnDeltaposSpinCephWomanKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_WOMAN_MA, &CSetting_FormView::OnDeltaposSpinCephWomanMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_CHILD_KV, &CSetting_FormView::OnDeltaposSpinCephChildKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_CHILD_MA, &CSetting_FormView::OnDeltaposSpinCephChildMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_TEEN_KV, &CSetting_FormView::OnDeltaposSpinCephTeenKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_TEEN_MA, &CSetting_FormView::OnDeltaposSpinCephTeenMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_CARPUS_KV, &CSetting_FormView::OnDeltaposSpinCephCarpusKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CEPH_CARPUS_MA, &CSetting_FormView::OnDeltaposSpinCephCarpusMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_MAN_KV, &CSetting_FormView::OnDeltaposSpinCtManKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_MAN_MA, &CSetting_FormView::OnDeltaposSpinCtManMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_WOMAN_KV, &CSetting_FormView::OnDeltaposSpinCtWomanKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_WOMAN_MA, &CSetting_FormView::OnDeltaposSpinCtWomanMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_CHILD_KV, &CSetting_FormView::OnDeltaposSpinCtChildKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_CHILD_MA, &CSetting_FormView::OnDeltaposSpinCtChildMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_TEEN_KV, &CSetting_FormView::OnDeltaposSpinCtTeenKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_TEEN_MA, &CSetting_FormView::OnDeltaposSpinCtTeenMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_LOW_KV, &CSetting_FormView::OnDeltaposSpinCtLowKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_LOW_MA, &CSetting_FormView::OnDeltaposSpinCtLowMa)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_ULTRA_LOW_KV, &CSetting_FormView::OnDeltaposSpinCtUltraLowKv)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_CT_ULTRA_LOW_MA, &CSetting_FormView::OnDeltaposSpinCtUltraLowMa)

	ON_STN_CLICKED(IDC_STATIC_AUTO_RETURN, &CSetting_FormView::OnStnClickedStaticAutoReturn)

	


END_MESSAGE_MAP()

// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기


// 현재 사용중인 GPU 정보를 불러온다
CString CSetting_FormView::GetGPUInfo()
{
	IDXGIFactory* pFactory;
	HRESULT hr = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)(&pFactory));

	IDXGIAdapter* pAdapter;
	CString gpuInfo;

	if (SUCCEEDED(hr))
	{
		for (UINT i = 0; pFactory->EnumAdapters(i, &pAdapter) != DXGI_ERROR_NOT_FOUND; ++i)
		{
			DXGI_ADAPTER_DESC adapterDesc;
			pAdapter->GetDesc(&adapterDesc);

			gpuInfo += adapterDesc.Description;
			gpuInfo += L"\n";

			pAdapter->Release();
		}

		pFactory->Release();
	}

	return gpuInfo;
}


// 사용중인 네트워크 주소를 IP Address Control 에 출력
CString CSetting_FormView::GetLocalIPAddress()
{
	CString strIPAddress;

	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) == 0)
	{
		char ch_addr[80];
		if (gethostname(ch_addr, sizeof(ch_addr)) == SOCKET_ERROR)
		{
			WSACleanup();
			return strIPAddress;
		}

		struct addrinfo hints;
		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family = AF_UNSPEC;

		// 네트워크 주소 없을때 Get
		struct addrinfo* result = NULL;
		if (getaddrinfo(ch_addr, NULL, &hints, &result) != 0)
		{
			WSACleanup();
			return strIPAddress;
		}

		for (struct addrinfo* ptr = result; ptr != NULL; ptr = ptr->ai_next)
		{
			switch (ptr->ai_family)
			{
			case AF_INET:
			{
				struct sockaddr_in* sockaddr_ipv4 = (struct sockaddr_in*)ptr->ai_addr;
				strIPAddress = CString(inet_ntop(AF_INET, &(sockaddr_ipv4->sin_addr), ch_addr, sizeof(ch_addr)));
				break;
			}
			default:
				break;
			}
		}

		freeaddrinfo(result);
		WSACleanup();
	}

	return strIPAddress;
}





void CSetting_FormView::OnEnChangeGpuEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnChangeLogoNameEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}



void CSetting_FormView::OnBnClickedSaveSettingButton()
{
	// test 

	
	//((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	// 
	// edit control, spin control
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetWindowText(_T("0"));
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetRange(0, 10);
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetPos(0);
	//
	//((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(_T("0"));


	// ini 파일에 콤보박스 값 쓰기
	CString strLang;
	CComboBox* lang_comboBox = ((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE));
	lang_comboBox->GetLBText(lang_comboBox->GetCurSel(), strLang);
	ConfigurationManager::getInstance()->SetLanguage(strLang);

	// save gpu text
	CString strGPU;
	GetDlgItemText(IDC_GPU_EDIT, strGPU);
	
	
	// logo_mode checkbox
	BOOL b_logoMode = ((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->GetCheck();
	CString strLogoMode;
	strLogoMode.Format(_T("%d"), b_logoMode);
	ConfigurationManager::getInstance()->SetLogoMode(strLogoMode);

	// save logo name text
	CString strLogoName;
	CEdit* logoname_edit = ((CEdit*)GetDlgItem(IDC_EDIT_LOGO_NAME));
	GetDlgItemText(IDC_EDIT_LOGO_NAME, strLogoName);
	ConfigurationManager::getInstance()->SetLogoName(strLogoName);

	// auto_return checkbox
	BOOL b_autoReturn = ((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->GetCheck();
	CString strAutoReturn;
	strAutoReturn.Format(_T("%d"), b_autoReturn);
	ConfigurationManager::getInstance()->SetAutoReturn(strAutoReturn);

	// log_debug_mode checkbox
	BOOL b_logDebugMode = ((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->GetCheck();
	CString strLogDebugMode;
	strLogDebugMode.Format(_T("%d"), b_logDebugMode);
	ConfigurationManager::getInstance()->SetLogDebugMode(strLogDebugMode);

	// ethernet_speed_check checkbox
	BOOL b_ethernetSpeedCheck = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->GetCheck();
	CString strEthernetSpeedCheck;
	strEthernetSpeedCheck.Format(_T("%d"), b_ethernetSpeedCheck);
	ConfigurationManager::getInstance()->SetEthernetSpeedCheck(strEthernetSpeedCheck);

	// ethernet_restart checkbox
	BOOL b_ethernetRestart = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->GetCheck();
	CString strEthernetRestart;
	strEthernetRestart.Format(_T("%d"), b_ethernetRestart);
	ConfigurationManager::getInstance()->SetEthernetRestart(strEthernetRestart);

	// save equipment text
	CString strEquipment;
	CEdit* equipment_edit = ((CEdit*)GetDlgItem(IDC_EDIT_EQUIPMENT));
	GetDlgItemText(IDC_EDIT_EQUIPMENT, strEquipment);
	ConfigurationManager::getInstance()->SetEquipment(strEquipment);


	// save preset_teen checkbox
	BOOL b_presetTeen = ((CButton*)GetDlgItem(IDC_CHECK_PRESET_TEEN))->GetCheck();
	CString strPresetTeen;
	strPresetTeen.Format(_T("%d"), b_presetTeen);
	ConfigurationManager::getInstance()->SetPresetTeen(strPresetTeen);

	// save low_dose checkbox
	BOOL b_lowDose = ((CButton*)GetDlgItem(IDC_CHECK_LOW_DOSE))->GetCheck();
	CString strLowDose;
	strLowDose.Format(_T("%d"), b_lowDose);
	ConfigurationManager::getInstance()->SetPresetTeen(strPresetTeen);
	
	// save pano man kv text
	CString strPanoManKv;
	CEdit* PanoManKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV));
	GetDlgItemText(IDC_EDIT_PANO_MAN_KV, strPanoManKv);
	ConfigurationManager::getInstance()->SetPanoManKv(strPanoManKv);
	// save pano man ma text
	CString strPanoManMa;
	CEdit* PanoManMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_MA));
	GetDlgItemText(IDC_EDIT_PANO_MAN_MA, strPanoManMa);
	ConfigurationManager::getInstance()->SetPanoManMa(strPanoManMa);

	// save pano woman kv text
	CString strPanoWomanKv;
	CEdit* PanoWomanKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_WOMAN_KV));
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, strPanoWomanKv);
	ConfigurationManager::getInstance()->SetPanoWomanKv(strPanoWomanKv);
	// save pano woman ma text
	CString strPanoWomanMa;
	CEdit* PanoWomanMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_WOMAN_MA));
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, strPanoWomanMa);
	ConfigurationManager::getInstance()->SetPanoWomanMa(strPanoWomanMa);

	// save pano child kv text
	CString strPanoChildKv;
	CEdit* PanoChildKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_CHILD_KV));
	GetDlgItemText(IDC_EDIT_PANO_CHILD_KV, strPanoChildKv);
	ConfigurationManager::getInstance()->SetPanoChildKv(strPanoChildKv);
	// save pano child ma text
	CString strPanoChildMa;
	CEdit* PanoChildMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_CHILD_MA));
	GetDlgItemText(IDC_EDIT_PANO_CHILD_MA, strPanoChildMa);
	ConfigurationManager::getInstance()->SetPanoChildMa(strPanoChildMa);

	// save pano teen kv text
	CString strPanoTeenKv;
	CEdit* PanoTeenKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_TEEN_KV));
	GetDlgItemText(IDC_EDIT_PANO_TEEN_KV, strPanoTeenKv);
	ConfigurationManager::getInstance()->SetPanoTeenKv(strPanoTeenKv);
	// save pano teen ma text
	CString strPanoTeenMa;
	CEdit* PanoTeenMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_PANO_TEEN_MA));
	GetDlgItemText(IDC_EDIT_PANO_TEEN_MA, strPanoTeenMa);
	ConfigurationManager::getInstance()->SetPanoTeenMa(strPanoTeenMa);

	// save ceph man kv text
	CString strCephManKv;
	CEdit* CephManKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_MAN_KV));
	GetDlgItemText(IDC_EDIT_CEPH_MAN_KV, strCephManKv);
	ConfigurationManager::getInstance()->SetCephManKv(strCephManKv);
	// save ceph man ma text
	CString strCephManMa;
	CEdit* CephManMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_MAN_MA));
	GetDlgItemText(IDC_EDIT_CEPH_MAN_MA, strCephManMa);
	ConfigurationManager::getInstance()->SetCephManMa(strCephManMa);

	// save ceph woman kv text
	CString strCephWomanKv;
	CEdit* CephWomanKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_WOMAN_KV));
	GetDlgItemText(IDC_EDIT_CEPH_WOMAN_KV, strCephWomanKv);
	ConfigurationManager::getInstance()->SetCephWomanKv(strCephWomanKv);
	// save ceph woman ma text
	CString strCephWomanMa;
	CEdit* CephWomanMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_WOMAN_MA));
	GetDlgItemText(IDC_EDIT_CEPH_WOMAN_MA, strCephWomanMa);
	ConfigurationManager::getInstance()->SetCephWomanMa(strCephWomanMa);

	// save ceph child kv text
	CString strCephChildKv;
	CEdit* CephChildKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_CHILD_KV));
	GetDlgItemText(IDC_EDIT_CEPH_CHILD_KV, strCephChildKv);
	ConfigurationManager::getInstance()->SetCephChildKv(strCephChildKv);
	// save ceph child ma text
	CString strCephChildMa;
	CEdit* CephChildMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_CHILD_MA));
	GetDlgItemText(IDC_EDIT_CEPH_CHILD_MA, strCephChildMa);
	ConfigurationManager::getInstance()->SetCephChildMa(strCephChildMa);

	// save ceph teen kv text
	CString strCephTeenKv;
	CEdit* CephTeenKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_TEEN_KV));
	GetDlgItemText(IDC_EDIT_CEPH_TEEN_KV, strCephTeenKv);
	ConfigurationManager::getInstance()->SetCephTeenKv(strCephTeenKv);
	// save ceph teen ma text
	CString strCephTeenMa;
	CEdit* CephTeenMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_TEEN_MA));
	GetDlgItemText(IDC_EDIT_CEPH_TEEN_MA, strCephTeenMa);
	ConfigurationManager::getInstance()->SetCephTeenMa(strCephTeenMa);

	// save ceph carpus kv text
	CString strCephCarpusKv;
	CEdit* CephCarpusKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_CARPUS_KV));
	GetDlgItemText(IDC_EDIT_CEPH_CARPUS_KV, strCephCarpusKv);
	ConfigurationManager::getInstance()->SetCephCarpusKv(strCephCarpusKv);
	// save ceph carpus ma text
	CString strCephCarpusMa;
	CEdit* CephCarpusMa_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CEPH_CARPUS_MA));
	GetDlgItemText(IDC_EDIT_CEPH_CARPUS_MA, strCephCarpusMa);
	ConfigurationManager::getInstance()->SetCephCarpusMa(strCephCarpusMa);

	// save ct man kv text
	CString strCTManKv;
	CEdit* CephCTManKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_MAN_KV));
	GetDlgItemText(IDC_EDIT_CT_MAN_KV, strCTManKv);
	ConfigurationManager::getInstance()->SetCTManKv(strCTManKv);
	// save ct man ma text
	CString strCTManMa;
	CEdit* CephCTMan_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_MAN_MA));
	GetDlgItemText(IDC_EDIT_CT_MAN_MA, strCTManMa);
	ConfigurationManager::getInstance()->SetCTManMa(strCTManMa);

	// save ct woman kv text
	CString strCTWomanKv;
	CEdit* CephCTWomanKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_WOMAN_KV));
	GetDlgItemText(IDC_EDIT_CT_WOMAN_KV, strCTWomanKv);
	ConfigurationManager::getInstance()->SetCTWomanKv(strCTWomanKv);
	// save ct woman ma text
	CString strCTWomanMa;
	CEdit* CephCTWoman_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_WOMAN_MA));
	GetDlgItemText(IDC_EDIT_CT_WOMAN_MA, strCTWomanMa);
	ConfigurationManager::getInstance()->SetCTWomanMa(strCTWomanMa);

	// save ct child kv text
	CString strCTChildKv;
	CEdit* CephCTChildKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_CHILD_KV));
	GetDlgItemText(IDC_EDIT_CT_CHILD_KV, strCTChildKv);
	ConfigurationManager::getInstance()->SetCTChildKv(strCTChildKv);
	// save ct child ma text
	CString strCTChildMa;
	CEdit* CephCTChild_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_CHILD_MA));
	GetDlgItemText(IDC_EDIT_CT_CHILD_MA, strCTChildMa);
	ConfigurationManager::getInstance()->SetCTChildMa(strCTChildMa);

	// save ct teen kv text
	CString strCTTeenKv;
	CEdit* CephCTTeenKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_TEEN_KV));
	GetDlgItemText(IDC_EDIT_CT_TEEN_KV, strCTTeenKv);
	ConfigurationManager::getInstance()->SetCTTeenKv(strCTTeenKv);
	// save ct teen ma text
	CString strCTTeenMa;
	CEdit* CephCTTeen_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_TEEN_MA));
	GetDlgItemText(IDC_EDIT_CT_TEEN_MA, strCTTeenMa);
	ConfigurationManager::getInstance()->SetCTTeenMa(strCTTeenMa);

	// save ct low kv text
	CString strCTLowKv;
	CEdit* CephCTLowKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_LOW_KV));
	GetDlgItemText(IDC_EDIT_CT_LOW_KV, strCTLowKv);
	ConfigurationManager::getInstance()->SetCTLowKv(strCTLowKv);
	// save ct low ma text
	CString strCTLowMa;
	CEdit* CephCTLow_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_LOW_MA));
	GetDlgItemText(IDC_EDIT_CT_LOW_MA, strCTLowMa);
	ConfigurationManager::getInstance()->SetCTLowMa(strCTLowMa);

	// save ct ultra low kv text
	CString strCTUltraLowKv;
	CEdit* CephCTUltraLowKv_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_KV));
	GetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_KV, strCTUltraLowKv);
	ConfigurationManager::getInstance()->SetCTUltraLowKv(strCTUltraLowKv);
	// save ct ultra low ma text
	CString strCTUltraLowMa;
	CEdit* CephCTUltraLow_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_MA));
	GetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_MA, strCTUltraLowMa);
	ConfigurationManager::getInstance()->SetCTUltraLowMa(strCTUltraLowMa);

	// save dap calibration
	CString strDAPCalibration;
	CEdit* DAPCalibration_edit = ((CEdit*)GetDlgItem(IDC_EDIT_DAP_CALIBRATION));
	GetDlgItemText(IDC_EDIT_DAP_CALIBRATION, strDAPCalibration);
	ConfigurationManager::getInstance()->SetDAPCalibration(strDAPCalibration);

	//save ctdi calibration
	CString strCTDICalibration;
	CEdit* CTDICalibration_edit = ((CEdit*)GetDlgItem(IDC_EDIT_CTDI_CALIBRATION));
	GetDlgItemText(IDC_EDIT_CTDI_CALIBRATION, strCTDICalibration);
	ConfigurationManager::getInstance()->SetCTDICalibration(strCTDICalibration);

	//save dose calibration
	CString strDoseCalibration;
	CEdit* DoseCalibration_edit = ((CEdit*)GetDlgItem(IDC_EDIT_DOSE_CALIBRATION));
	GetDlgItemText(IDC_EDIT_DOSE_CALIBRATION, strDoseCalibration);
	ConfigurationManager::getInstance()->SetDoseCalibration(strDoseCalibration);

	//Pacs 에서 받아오는 값, 수정 불가
	CString strXrayOffMode;
	BOOL b_xrayOffMode = ((CButton*)GetDlgItem(IDC_CHECK_XRAY_OFF_MODE))->GetCheck();
	strXrayOffMode.Format(_T("%d"), b_xrayOffMode);
	ConfigurationManager::getInstance()->SetXrayOffMode (strXrayOffMode);
	
	CString strPacsSend;
	BOOL b_pacsSend = ((CButton*)GetDlgItem(IDC_CHECK_PACS_SEND))->GetCheck();
	strPacsSend.Format(_T("%d"), b_pacsSend);
	ConfigurationManager::getInstance()->SetPacsSend(strPacsSend);


}


void CSetting_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.

	//Pano
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetRange(50, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_MAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetRange(50, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_WOMAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetRange(50, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_CHILD_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_MA))->SetRange(50, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_PANO_TEEN_MA))->SetPos(0);

	//Ceph
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_MA))->SetRange(50, 110);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_MAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_MA))->SetRange(50, 110);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_WOMAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_MA))->SetRange(50, 110);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CHILD_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_MA))->SetRange(50, 110);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_TEEN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_KV))->SetRange(60, 90);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_MA))->SetRange(50, 110);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CEPH_CARPUS_MA))->SetPos(0);

	//CT
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_MAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_WOMAN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_CHILD_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_TEEN_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_LOW_MA))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_KV))->SetRange(60, 95);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_KV))->SetPos(0);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_MA))->SetRange(50, 80);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_CT_ULTRA_LOW_MA))->SetPos(0);


	// 항목별 도움말 정리
	m_Setting_Tips.Create(this, TTS_ALWAYSTIP | TTS_BALLOON);
	m_Setting_Tips.SetMaxTipWidth(500); 

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LANGUAGE), _T("언어 종류 선택 : 문자열 입력"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_COMBO_LANGUAGE), _T("현재 지원 언어 : Korean, English"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_GPU), _T("현재 모니터와 연결된 GPU 디바이스 정보"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_GPU), _T("수정 불가능한 값"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOGO_MODE), _T("로고 R 마크 출력"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_LOGO_MODE), _T("CHECK : R / UNCHECK : 세로로 Customize 출력"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOGO_NAME), _T("로고 이름 Customize, 기본값 : Osstem T2"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_LOGO_NAME), _T("대체할 치과 로고 이름 입력"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_AUTO_RETURN), _T("촬영 완료 후 장비 초기화 사용")); 
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_AUTO_RETURN), _T("CHECK : 사용 / UNCHECK : 사용하지 않음")); 
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_ETHERNET_SPEED_CHECK), _T("네트워크 속도를 실시간 표시"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_ETHERNET_RESTART), _T("네트워크 재시작 실행 "));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_ETHERNET_RESTART), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOG_DEBUG_MODE), _T("Info, Serial 과 함께 Debug 정보를 입력"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE), _T("CHECK : 입력 / UNCHECK : 입력하지 않음"));
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_EQUIPMENT), _T("현재 사용 중인 장비 이름을 출력합니다. 기본값 : T2"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_EQUIPMENT), _T("수정 불가능한 값"));

	//m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_RESULT_CUTTING), _T("기본값 : 파노라마 이미지를 원본 그대로 저장, Preset 1, 2, 3 선택"));
	

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PRESET_TEEN), _T("4가지 프리셋 중 청소년 모드"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_PRESET_TEEN), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_LOW_DOSE), _T("T2 Plus 저선량 모드"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_LOW_DOSE), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_MAN_KV), _T("Pano Large 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_MAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_MAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_MAN_MA), _T("Pano Large 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_MAN_MA), _T("50 ~ 100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_MAN_MA), _T("50 ~ 100 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_WOMAN_KV), _T("Pano Medium 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_WOMAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_WOMAN_MA), _T("Pano Medium 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA), _T("50 ~ 100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_WOMAN_MA), _T("50 ~ 100 Ma"));
	
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_CHILD_KV), _T("Pano Child 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_CHILD_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_CHILD_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_CHILD_MA), _T("Pano Child 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_CHILD_MA), _T("50 ~ 100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_CHILD_MA), _T("50 ~ 100 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_TEEN_KV), _T("Pano Small 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_TEEN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_TEEN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PANO_TEEN_MA), _T("Pano Small 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_PANO_TEEN_MA), _T("50 ~ 100 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_PANO_TEEN_MA), _T("50 ~ 100 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_MAN_KV), _T("Ceph Large 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_MAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_MAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_MAN_MA), _T("Ceph Large 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_MAN_MA), _T("50 ~ 110 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_MAN_MA), _T("50 ~ 110 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_WOMAN_KV), _T("Ceph Medium 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_WOMAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_WOMAN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_WOMAN_MA), _T("Ceph Medium 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_WOMAN_MA), _T("50 ~ 110 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_WOMAN_MA), _T("50 ~ 110 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_CHILD_KV), _T("Ceph Child 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_CHILD_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_CHILD_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_CHILD_MA), _T("Ceph Child 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_CHILD_MA), _T("50 ~ 110 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_CHILD_MA), _T("50 ~ 110 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_TEEN_KV), _T("Ceph Small 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_TEEN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_TEEN_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_TEEN_MA), _T("Ceph Small 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_TEEN_MA), _T("50 ~ 110 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_TEEN_MA), _T("50 ~ 110 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_CARPUS_KV), _T("Ceph Carpus 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_CARPUS_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_CARPUS_KV), _T("60 ~ 90 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CEPH_CARPUS_MA), _T("Ceph Carpus 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CEPH_CARPUS_MA), _T("50 ~ 110 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CEPH_CARPUS_MA), _T("50 ~ 110 Ma"));


	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_MAN_KV), _T("CT Large 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_MAN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_MAN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_MAN_MA), _T("CT Large 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_MAN_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_MAN_MA), _T("50 ~ 80 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_WOMAN_KV), _T("CT Medium 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_WOMAN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_WOMAN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_WOMAN_MA), _T("CT Medium 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_WOMAN_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_WOMAN_MA), _T("50 ~ 80 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_CHILD_KV), _T("CT Child 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_CHILD_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_CHILD_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_CHILD_MA), _T("CT Child 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_CHILD_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_CHILD_MA), _T("50 ~ 80 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_TEEN_KV), _T("CT Small 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_TEEN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_TEEN_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_TEEN_MA), _T("CT Small 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_TEEN_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_TEEN_MA), _T("50 ~ 80 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_LOW_KV), _T("CT Low 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_LOW_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_LOW_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_LOW_MA), _T("CT Low 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_LOW_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_LOW_MA), _T("50 ~ 80 Ma"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_ULTRA_LOW_KV), _T("CT Ultra Low 촬영 관전압"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_KV), _T("60 ~ 95 Kv"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CT_ULTRA_LOW_MA), _T("CT Ultra Low 촬영 관전류"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_MA), _T("50 ~ 80 Ma"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_MA), _T("50 ~ 80 Ma"));


	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_DAP_CALIBRATION), _T("Dose Area Product : DAP Calibration 값을 보정하는 계수"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_DAP_CALIBRATION), _T("제한 없음"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_CTDI_CALIBRATION), _T("Computed Tomography Dose Index : CTDI Calibration 값을 보정하는 계수"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_CTDI_CALIBRATION), _T("제한 없음"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_DOSE_CALIBRATION), _T("DOSE Calibration 값을 보정하는 계수"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_EDIT_DOSE_CALIBRATION), _T("제한 없음"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_XRAY_OFF_MODE), _T("Xray 비조사 모드 사용"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_XRAY_OFF_MODE), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_STATIC_PACS_SEND), _T("Pacs 서버로 내보내기 활성화"));
	m_Setting_Tips.AddTool(GetDlgItem(IDC_CHECK_PACS_SEND), _T("CHECK : 사용 / UNCHECK : 사용하지 않음"));

	m_Setting_Tips.AddTool(GetDlgItem(IDC_BUTTON_SAVE_SETTING), _T("현재까지 변경 내용을 [Setting Section] 에 저장합니다."));
	
	m_Setting_Tips.Activate(TRUE);

	/*CRect rcStatic(100, 100, 150, 120);
	Static.Create("test", WS_CHILDWINDOW | SS_NOTIFY, rcStatic, this, 1000);
	static.ModifyStyle(0, SS_NOTIFY);*/

}


// 툴팁 설정을 위한 메소드
BOOL CSetting_FormView::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	case WM_MOUSEMOVE:
	{ 
		m_Setting_Tips.RelayEvent(pMsg);

		CWarnning_Dialog dlg;
		//dlg.DoModal();
	}

	//if (pMsg->message == WM_LBUTTONDOWN)
	//{
	//	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_LANGUAGE)->GetSafeHwnd())
	//		AfxMessageBox("마우스 왼쪽 클릭");
	//}

	//if (pMsg->message == WM_MENUSELECT)
	//{
	//	CString str = _T("");
	//	GetDlgItemText(IDC_EDIT_CEPH_MAN_KV, str);
	//	int nValue;
	//	nValue = _ttoi(str);
	//	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_MAN_KV))->SetPos(nValue);

	//	TRACE(str);
	//}
	//else if (pMsg->message == WM_MENUSELECT)
	//{
	//	CString str = _T("");
	//	GetDlgItemText(IDC_EDIT_CEPH_MAN_MA, str);
	//	int nValue;
	//	nValue = _ttoi(str);
	//	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_MAN_MA))->SetPos(nValue);

	//	TRACE(str);
	//}
	//else if (pMsg->message == WM_MENUSELECT)
	//{
	//	CString str = _T("");
	//	GetDlgItemText(IDC_EDIT_CEPH_WOMAN_KV, str);
	//	int nValue;
	//	nValue = _ttoi(str);
	//	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_WOMAN_KV))->SetPos(nValue);

	//	TRACE(str);
	//}
	//else if (pMsg->message == WM_MENUSELECT)
	//{
	//	CString str = _T("");
	//	GetDlgItemText(IDC_EDIT_PANO_TEEN_KV, str);
	//	int nValue;
	//	nValue = _ttoi(str);
	//	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_TEEN_KV))->SetPos(nValue);

	//	TRACE(str);
	//}
	//else if (pMsg->message == WM_MENUSELECT)
	//{
	//	CString str = _T("");
	//	GetDlgItemText(IDC_EDIT_PANO_TEEN_MA, str);
	//	int nValue;
	//	nValue = _ttoi(str);
	//	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_TEEN_MA))->SetPos(nValue);

	//	TRACE(str);
	//}



	return CFormView::PreTranslateMessage(pMsg);
}


void CSetting_FormView::LoadData_Setting()
{
	CString language = ConfigurationManager::getInstance()->GetLanguage();

	if (language == _T("Korean"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(0);
	else if (language == _T("English"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(1);
	else if (language == _T("Chinese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(2);
	else if (language == _T("Japaness"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(3);
	else if (language == _T("Russian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(4);
	else if (language == _T("German"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(5);
	else if (language == _T("French"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(6);
	else if (language == _T("Spanish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(7);
	else if (language == _T("Portuguese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(8);
	else if (language == _T("Italian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(9);
	else if (language == _T("Vietnamese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(10);
	else if (language == _T("Thai"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(11);
	else if (language == _T("Malay"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(12);
	else if (language == _T("Indonesian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(13);
	else if (language == _T("Bengali"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(14);
	else if (language == _T("Kazakh"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(15);
	else if (language == _T("Ukrainian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(16);
	else if (language == _T("Uzbek"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(17);
	else if (language == _T("Mongolian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(18);
	else if (language == _T("Arabic"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(19);
	else if (language == _T("Hebrew"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(20);
	else if (language == _T("Turkish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(21);
	
	// LogoName 항목 불러와서 표시
	CString strLogoName = ConfigurationManager::getInstance()->GetLogoName();
	SetDlgItemText(IDC_EDIT_LOGO_NAME, strLogoName);

	// Equipment 항목 불러와서 표시
	CString strEquipment = ConfigurationManager::getInstance()->GetEquipment();
	SetDlgItemText(IDC_EDIT_EQUIPMENT, strEquipment);


	// GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	//CString strIPAddress = GetLocalIPAddress();
	
	//LPCSTR pszConvertedAnsiString = CT2A(strIPAddress);

	//DWORD dwIP = inet_addr(pszConvertedAnsiString);
	//BYTE* pbIP = (BYTE*)&dwIP;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	

	 // GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	CString strIPAddress = GetLocalIPAddress();

	// CString에서 LPCWSTR로 변환
	//LPCWSTR pszConvertedWideString = CT2W(strIPAddress);
	LPCWSTR pszConvertedWideString = LPCWSTR(strIPAddress);
	IN_ADDR ipAddr;
	InetPton(AF_INET, pszConvertedWideString, &ipAddr);

	BYTE* pbIP = (BYTE*)&ipAddr.S_un.S_addr;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	int nFIndCount = strIPAddress.Find(_T("."));
	int nBuff[10];
	int nIndexCount = 0;
	while(1)
	{
		nFIndCount = strIPAddress.Find(_T("."));
		if (nFIndCount > -1)
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress.Left(nFIndCount));
			strIPAddress = strIPAddress.Mid(nFIndCount + 1, strIPAddress.GetLength());
		}
		else
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress);
			break;
		}
		nIndexCount++;
	}
	nIndexCount = 0;
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++]);


	// 4. IDC_GPU_EDIT 에디트 컨트롤에 값을 설정
	CString gpuInfo = this->GetGPUInfo();
	SetDlgItemText(IDC_GPU_EDIT, gpuInfo);
	
	
	CString logo_mode = ConfigurationManager::getInstance()->GetLogoMode();
	if (logo_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(FALSE);

	CString logo_name = ConfigurationManager::getInstance()->GetLogoName();

	CString auto_return = ConfigurationManager::getInstance()->GetAutoReturn();
	if (auto_return == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(FALSE);

	CString ethernet_speed_check = ConfigurationManager::getInstance()->GetEthernetSpeedCheck();
	if (ethernet_speed_check == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(FALSE);

	CString ethernet_restart = ConfigurationManager::getInstance()->GetEthernetRestart();
	if (ethernet_restart == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(FALSE);

	CString log_debug_mode = ConfigurationManager::getInstance()->GetLogDebugMode();
	if (log_debug_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOG_DEBUG_MODE))->SetCheck(FALSE);

	CString equipment = ConfigurationManager::getInstance()->GetEquipment();
	SetDlgItemText(IDC_EDIT_LOGO_NAME, equipment);


	CString preset_teen = ConfigurationManager::getInstance()->GetPresetTeen();
	if (log_debug_mode == _T("1"))
		((CButton*)GetDlgItem(IDC_CHECK_PRESET_TEEN))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_PRESET_TEEN))->SetCheck(FALSE);

	CString low_dose = ConfigurationManager::getInstance()->GetLowDose();
	if (low_dose == _T("1"))
		((CButton*)GetDlgItem(IDC_CHECK_LOW_DOSE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOW_DOSE))->SetCheck(FALSE);


	CString modality_ct = ConfigurationManager::getInstance()->GetModalityCT();
	SetDlgItemText(IDC_EDIT_MODALITY_CT, modality_ct);

	CString modality_pano = ConfigurationManager::getInstance()->GetModalityPano();
	SetDlgItemText(IDC_EDIT_MODALITY_PANO, modality_pano);

	CString modality_ceph = ConfigurationManager::getInstance()->GetModalityCeph();
	SetDlgItemText(IDC_EDIT_MODALITY_CEPH, modality_ceph);

	CString dap_calibration = ConfigurationManager::getInstance()->GetDAPCalibration();
	SetDlgItemText(IDC_EDIT_DAP_CALIBRATION, dap_calibration);

	CString ctdi_calibration = ConfigurationManager::getInstance()->GetCTDICalibration();
	SetDlgItemText(IDC_EDIT_CTDI_CALIBRATION, ctdi_calibration);

	CString dose_calibration = ConfigurationManager::getInstance()->GetDoseCalibration();
	SetDlgItemText(IDC_EDIT_DOSE_CALIBRATION, dose_calibration);
	
	
	//CString pano_result_cutting = ConfigurationManager::getInstance()->GetPanoResultCutting();
	//if (pano_result_cutting == _T("0"))
	//	((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(0);
	//else if (pano_result_cutting == _T("1"))
	//	((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(1);
	//else if (pano_result_cutting == _T("2"))
	//	((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(2);
	//else if (pano_result_cutting == _T("3"))
	//	((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(3);


	//Slider Control 과 Edit Control 값 연동
	CString pano_man_kv = ConfigurationManager::getInstance()->GetPanoManKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetPos(_ttoi(pano_man_kv));
	SetDlgItemText(IDC_EDIT_PANO_MAN_KV, pano_man_kv);
	CString pano_man_ma = ConfigurationManager::getInstance()->GetPanoManMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_MAN_MA))->SetPos(_ttoi(pano_man_ma));
	SetDlgItemText(IDC_EDIT_PANO_MAN_MA, pano_man_ma);
	
	CString pano_woman_kv = ConfigurationManager::getInstance()->GetPanoWomanKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_WOMAN_KV))->SetPos(_ttoi(pano_woman_kv));
	SetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, pano_woman_kv);	
	CString pano_woman_ma = ConfigurationManager::getInstance()->GetPanoWomanMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_WOMAN_MA))->SetPos(_ttoi(pano_woman_ma));
	SetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, pano_woman_ma);

	CString pano_child_kv = ConfigurationManager::getInstance()->GetPanoChildKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_CHILD_KV))->SetPos(_ttoi(pano_child_kv));
	SetDlgItemText(IDC_EDIT_PANO_CHILD_KV, pano_child_kv);
	CString pano_child_ma = ConfigurationManager::getInstance()->GetPanoChildMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_CHILD_MA))->SetPos(_ttoi(pano_child_ma));
	SetDlgItemText(IDC_EDIT_PANO_CHILD_MA, pano_child_ma);

	CString pano_teen_kv = ConfigurationManager::getInstance()->GetPanoTeenKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_TEEN_KV))->SetPos(_ttoi(pano_teen_kv));
	SetDlgItemText(IDC_EDIT_PANO_TEEN_KV, pano_teen_kv);
	CString pano_teen_ma = ConfigurationManager::getInstance()->GetPanoTeenMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_PANO_TEEN_MA))->SetPos(_ttoi(pano_teen_ma));
	SetDlgItemText(IDC_EDIT_PANO_TEEN_MA, pano_teen_ma);

	CString ceph_man_kv = ConfigurationManager::getInstance()->GetCephManKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_MAN_KV))->SetPos(_ttoi(ceph_man_kv));
	SetDlgItemText(IDC_EDIT_CEPH_MAN_KV, ceph_man_kv);
	CString ceph_man_ma = ConfigurationManager::getInstance()->GetCephManMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_MAN_MA))->SetPos(_ttoi(ceph_man_ma));
	SetDlgItemText(IDC_EDIT_CEPH_MAN_MA, ceph_man_ma);

	CString ceph_woman_kv = ConfigurationManager::getInstance()->GetCephWomanKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_WOMAN_KV))->SetPos(_ttoi(ceph_woman_kv));
	SetDlgItemText(IDC_EDIT_CEPH_WOMAN_KV, ceph_woman_kv);
	CString ceph_woman_ma = ConfigurationManager::getInstance()->GetCephWomanMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_WOMAN_MA))->SetPos(_ttoi(ceph_woman_ma));
	SetDlgItemText(IDC_EDIT_CEPH_WOMAN_MA, ceph_woman_ma);

	CString ceph_child_kv = ConfigurationManager::getInstance()->GetCephChildKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_CHILD_KV))->SetPos(_ttoi(ceph_child_kv));
	SetDlgItemText(IDC_EDIT_CEPH_CHILD_KV, ceph_child_kv);
	CString ceph_child_ma = ConfigurationManager::getInstance()->GetCephChildMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_CHILD_MA))->SetPos(_ttoi(ceph_child_ma));
	SetDlgItemText(IDC_EDIT_CEPH_CHILD_MA, ceph_child_ma);

	CString ceph_teen_kv = ConfigurationManager::getInstance()->GetCephTeenKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_TEEN_KV))->SetPos(_ttoi(ceph_teen_kv));
	SetDlgItemText(IDC_EDIT_CEPH_TEEN_KV, ceph_teen_kv);
	CString ceph_teen_ma = ConfigurationManager::getInstance()->GetCephTeenMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_TEEN_MA))->SetPos(_ttoi(ceph_teen_ma));
	SetDlgItemText(IDC_EDIT_CEPH_TEEN_MA, ceph_teen_ma);

	CString ceph_carpus_kv = ConfigurationManager::getInstance()->GetCephCarpusKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_CARPUS_KV))->SetPos(_ttoi(ceph_carpus_kv));
	SetDlgItemText(IDC_EDIT_CEPH_CARPUS_KV, ceph_carpus_kv);
	CString ceph_carpus_ma = ConfigurationManager::getInstance()->GetCephCarpusMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CEPH_CARPUS_MA))->SetPos(_ttoi(ceph_carpus_ma));
	SetDlgItemText(IDC_EDIT_CEPH_CARPUS_MA, ceph_carpus_ma);

	CString ct_man_kv = ConfigurationManager::getInstance()->GetCTManKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_MAN_KV))->SetPos(_ttoi(ct_man_kv));
	SetDlgItemText(IDC_EDIT_CT_MAN_KV, ct_man_kv);
	CString ct_man_ma = ConfigurationManager::getInstance()->GetCTManMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_MAN_MA))->SetPos(_ttoi(ct_man_ma));
	SetDlgItemText(IDC_EDIT_CT_MAN_MA, ct_man_ma);

	CString ct_woman_kv = ConfigurationManager::getInstance()->GetCTWomanKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_WOMAN_KV))->SetPos(_ttoi(ct_woman_kv));
	SetDlgItemText(IDC_EDIT_CT_WOMAN_KV, ct_woman_kv);
	CString ct_woman_ma = ConfigurationManager::getInstance()->GetCTWomanMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_WOMAN_KV))->SetPos(_ttoi(ct_woman_ma));
	SetDlgItemText(IDC_EDIT_CT_WOMAN_MA, ct_woman_ma);

	CString ct_child_kv = ConfigurationManager::getInstance()->GetCTChildKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_CHILD_KV))->SetPos(_ttoi(ct_child_kv));
	SetDlgItemText(IDC_EDIT_CT_CHILD_KV, ct_child_kv);
	CString ct_child_ma = ConfigurationManager::getInstance()->GetCTChildMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_CHILD_MA))->SetPos(_ttoi(ct_child_ma));
	SetDlgItemText(IDC_EDIT_CT_CHILD_MA, ct_child_ma);

	CString ct_teen_kv = ConfigurationManager::getInstance()->GetCTTeenKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_TEEN_KV))->SetPos(_ttoi(ct_teen_kv));
	SetDlgItemText(IDC_EDIT_CT_TEEN_KV, ct_teen_kv);
	CString ct_teen_ma = ConfigurationManager::getInstance()->GetCTTeenMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_TEEN_MA))->SetPos(_ttoi(ct_teen_ma));
	SetDlgItemText(IDC_EDIT_CT_TEEN_MA, ct_teen_ma);
	

	CString ct_low_kv = ConfigurationManager::getInstance()->GetCTLowKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_LOW_KV))->SetPos(_ttoi(ct_low_kv));
	SetDlgItemText(IDC_EDIT_CT_LOW_KV, ct_low_kv);
	CString ct_low_ma = ConfigurationManager::getInstance()->GetCTLowMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_LOW_MA))->SetPos(_ttoi(ct_low_ma));
	SetDlgItemText(IDC_EDIT_CT_LOW_MA, ct_low_ma);


	CString ct_ultra_low_kv = ConfigurationManager::getInstance()->GetCTUltraLowKv();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_KV))->SetPos(_ttoi(ct_ultra_low_kv));
	SetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_KV, ct_ultra_low_kv);
	CString ct_ultra_low_ma = ConfigurationManager::getInstance()->GetCTUltraLowMa();
	((CSliderCtrl*)GetDlgItem(IDC_EDIT_CT_ULTRA_LOW_MA))->SetPos(_ttoi(ct_ultra_low_ma));
	SetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_MA, ct_ultra_low_ma);

	CString xrayoffmode = ConfigurationManager::getInstance()->GetXrayOffMode();
	if (xrayoffmode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_XRAY_OFF_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_XRAY_OFF_MODE))->SetCheck(FALSE);

	CString pacsSend = ConfigurationManager::getInstance()->GetPacsSend();
	if (pacsSend == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_PACS_SEND))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_PACS_SEND))->SetCheck(FALSE);
}


void CSetting_FormView::OnEnChangeEditEquipment()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

// Slider control 활용한 유형별 관전압, 관전류 기본값 및 범위 조절
void CSetting_FormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	if (IDC_SLIDER_PANO_MAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_MAN_KV, strPos);
	}
	else if (IDC_SLIDER_PANO_MAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_MAN_MA, strPos);
	}  
	else if (IDC_SLIDER_PANO_WOMAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, strPos);
	}
	else if (IDC_SLIDER_PANO_WOMAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, strPos);
	}
	else if (IDC_SLIDER_PANO_CHILD_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_CHILD_KV, strPos);
	}
	else if (IDC_SLIDER_PANO_CHILD_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_CHILD_MA, strPos);
	}
	else if (IDC_SLIDER_PANO_TEEN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_TEEN_KV, strPos);
	}
	else if (IDC_SLIDER_PANO_TEEN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_PANO_TEEN_MA, strPos);
	}
	else if (IDC_SLIDER_CEPH_MAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_MAN_KV, strPos);
	}
	else if (IDC_SLIDER_CEPH_MAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_MAN_MA, strPos);
	}
	else if (IDC_SLIDER_CEPH_WOMAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_WOMAN_KV, strPos);
	}
	else if (IDC_SLIDER_CEPH_WOMAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_WOMAN_MA, strPos);
	}
	else if (IDC_SLIDER_CEPH_CHILD_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_CHILD_KV, strPos);
	}
	else if (IDC_SLIDER_CEPH_CHILD_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_CHILD_MA, strPos);
	}
	else if (IDC_SLIDER_CEPH_TEEN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_TEEN_KV, strPos);
	}
	else if (IDC_SLIDER_CEPH_TEEN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_TEEN_MA, strPos);
	}
	else if
		(IDC_SLIDER_CEPH_CARPUS_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_CARPUS_KV, strPos);
	}
	else if (IDC_SLIDER_CEPH_CARPUS_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CEPH_CARPUS_MA, strPos);
	}
	else if (IDC_SLIDER_CT_MAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_MAN_KV, strPos);
	}
	else if (IDC_SLIDER_CT_MAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_MAN_MA, strPos);
	}
	else if (IDC_SLIDER_CT_WOMAN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_WOMAN_KV, strPos);
	}
	else if (IDC_SLIDER_CT_WOMAN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_WOMAN_MA, strPos);
	}
	else if (IDC_SLIDER_CT_CHILD_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_CHILD_KV, strPos);
	}
	else if (IDC_SLIDER_CT_CHILD_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_CHILD_MA, strPos);
	}
	else if (IDC_SLIDER_CT_TEEN_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_TEEN_KV, strPos);
	}
	else if (IDC_SLIDER_CT_TEEN_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_TEEN_MA, strPos);
	}
	else if (IDC_SLIDER_CT_LOW_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_LOW_KV, strPos);
	}
	else if (IDC_SLIDER_CT_LOW_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_LOW_MA, strPos);
	}
	else if (IDC_SLIDER_CT_ULTRA_LOW_KV == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_KV))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_KV, strPos);
	}
	else if (IDC_SLIDER_CT_ULTRA_LOW_MA == pScrollBar->GetDlgCtrlID())
	{
		int nPos = ((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_MA))->GetPos();
		CString strPos;
		strPos.Format(_T("%d"), nPos);
		SetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_MA, strPos);
	}

	// 추가 슬라이더 설정, 동작방식은 동일

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

// Pano Ceph CT Edit Control 조작 메소드
void CSetting_FormView::OnEnChangeEditPanoManKv()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_MAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoManMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_MAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoWomanKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoWomanMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_WOMAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoChildKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_CHILD_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoChildMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_CHILD_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditPanoTeenKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_TEEN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_KV))->SetPos(nValue);

	TRACE(str);

}
void CSetting_FormView::OnEnChangeEditPanoTeenMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_PANO_TEEN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephManKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_MAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephManMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_MAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephWomanKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_WOMAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephWomanMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_WOMAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephChildKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_CHILD_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephChildMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_CHILD_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephTeenKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_TEEN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephTeenMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_TEEN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephCarpusKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_CARPUS_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCephCarpusMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CEPH_CARPUS_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtManKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_MAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtManMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_MAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtWomanKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_WOMAN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtWomanMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_WOMAN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtChildKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_CHILD_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtChildMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_CHILD_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtTeenKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_TEEN_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtTeenMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_TEEN_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtLowKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_LOW_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtLowMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_LOW_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_MA))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtUltraLowKv()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_KV, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_KV))->SetPos(nValue);

	TRACE(str);
}
void CSetting_FormView::OnEnChangeEditCtUltraLowMa()
{
	CString str = _T("");
	GetDlgItemText(IDC_EDIT_CT_ULTRA_LOW_MA, str);
	int nValue;
	nValue = _ttoi(str);
	((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_MA))->SetPos(nValue);

	TRACE(str);
}


// Pano Ceph CT Spin Control 조작 메소드
void CSetting_FormView::OnDeltaposSpinPanoManKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_MAN_KV, str);
		//((CEdit*)GetDlgItem(IDC_EDIT_PANO_MAN_KV))->SetWindowText(str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_KV))->SetPos(nValue);

	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoManMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_MAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_MAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoWomanKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_WOMAN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoWomanMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_WOMAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_WOMAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoChildKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_CHILD_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoChildMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_CHILD_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_CHILD_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoTeenKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_TEEN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinPanoTeenMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 100)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_TEEN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_PANO_TEEN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephManKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_PANO_TEEN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephManMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 110)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_MAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_MAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephWomanKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_WOMAN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephWomanMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 110)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_WOMAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_WOMAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephChildKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_CHILD_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephChildMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 110)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_CHILD_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CHILD_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephTeenKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_TEEN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephTeenMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 110)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_TEEN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_TEEN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephCarpusKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 90)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_CARPUS_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCephCarpusMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 110)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CEPH_CARPUS_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CEPH_CARPUS_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtManKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_MAN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtManMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 500 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_MAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_MAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtWomanKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_WOMAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtWomanMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_WOMAN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_WOMAN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtChildKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_CHILD_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtChildMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_CHILD_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_CHILD_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtTeenKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_TEEN_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtTeenMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_TEEN_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_TEEN_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtLowKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_LOW_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtLowMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_LOW_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_LOW_MA))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtUltraLowKv(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 60 && nValue <= 95)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_ULTRA_LOW_KV, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_KV))->SetPos(nValue);
	}
	*pResult = 0;
}
void CSetting_FormView::OnDeltaposSpinCtUltraLowMa(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 50 && nValue <= 80)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		SetDlgItemText(IDC_SLIDER_CT_ULTRA_LOW_MA, str);
		((CSliderCtrl*)GetDlgItem(IDC_SLIDER_CT_ULTRA_LOW_MA))->SetPos(nValue);
	}
	*pResult = 0;
}



void CSetting_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
	
}

// 지정된 영역 이외에도 작동
void CSetting_FormView::OnStnClickedStaticAutoReturn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	
	CWarnning_Dialog dlg;

	dlg.DoModal();

}




