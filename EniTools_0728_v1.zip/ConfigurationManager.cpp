#include "pch.h"
#include "ConfigurationManager.h"

ConfigurationManager* ConfigurationManager::m_instance = nullptr;
ConfigurationManager::ConfigurationManager()
{}

ConfigurationManager::~ConfigurationManager()
{}

ConfigurationManager* ConfigurationManager::getInstance()
{
	if (m_instance == nullptr)
		m_instance = new ConfigurationManager();

	return m_instance;
}

void ConfigurationManager::SetIniPath(CString path)
{
	m_strPath = path;
}

void ConfigurationManager::SetData(const CString section, const CString key, const CString data)
{
	WritePrivateProfileString(section, key, data, m_strPath);
}

CString ConfigurationManager::GetData(const CString section, const CString key)
{
	CString strData;
	TCHAR _data[256];
	// ���� ������ �߻� C6386
	// �������� : sizeof -1
	GetPrivateProfileString(section, key, NULL, _data, sizeof(_data-1), m_strPath);

	strData = CString(_data);
	return strData;
}



// Setting Section

void ConfigurationManager::SetLanguage(const CString data)
{
	SetData(_T("Setting"), _T("language"), data);
}
CString ConfigurationManager::GetLanguage()
{
	return GetData(_T("Setting"), _T("language"));
}

void ConfigurationManager::SetLogoMode(const CString data)
{
	SetData(_T("Setting"), _T("logo_mode"), data);
}
CString ConfigurationManager::GetLogoMode()
{
	return GetData(_T("Setting"), _T("logo_mode"));
}

void ConfigurationManager::SetLogoName(const CString data)
{
	SetData(_T("Setting"), _T("logo_Name"), data);
}
CString ConfigurationManager::GetLogoName()
{
	return GetData(_T("Setting"), _T("logo_name"));
}

void ConfigurationManager::SetAutoReturn(const CString data)
{
	SetData(_T("Setting"), _T("auto_return"), data);
}
CString ConfigurationManager::GetAutoReturn()
{
	return GetData(_T("Setting"), _T("auto_return"));
}

void ConfigurationManager::SetEthernetSpeedCheck(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_speed_check"), data);
}
CString ConfigurationManager::GetEthernetSpeedCheck()
{
	return GetData(_T("Setting"), _T("ethernet_speed_check"));
}

void ConfigurationManager::SetLogDebugMode(const CString data)
{
	SetData(_T("Setting"), _T("log_debug_mode"), data);
}
CString ConfigurationManager::GetLogDebugMode()
{
	return GetData(_T("Setting"), _T("log_debug_mode"));
}

void ConfigurationManager::SetEquipment(const CString data)
{
	SetData(_T("Setting"), _T("equipment"), data);
}
CString ConfigurationManager::GetEquipment()
{
	return GetData(_T("Setting"), _T("equipment"));
}

void ConfigurationManager::SetEthernetRestart(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_restart"), data);
}
CString ConfigurationManager::GetEthernetRestart()
{
	return GetData(_T("Setting"), _T("ethernet_restart"));
}

void ConfigurationManager::SetPresetTeen(const CString data)
{
	SetData(_T("Setting"), _T("preset_teen"), data);

}
CString ConfigurationManager::GetPresetTeen()
{
	return GetData(_T("Setting"), _T("preset_teen"));

}

//modality get ������ٰ�

CString ConfigurationManager::GetModalityCT()
{
	return GetData(_T("Setting"), _T("modality_ct"));
}

CString ConfigurationManager::GetModalityPano()
{
	return GetData(_T("Setting"), _T("modality_pano"));
}

CString ConfigurationManager::GetModalityCeph()
{
	return GetData(_T("Setting"), _T("modality_ceph"));
}





void ConfigurationManager::SetLowDose(const CString data)
{
	SetData(_T("Setting"), _T("low_dose"), data);

}
CString ConfigurationManager::GetLowDose()
{
	return GetData(_T("Setting"), _T("low_dose"));

}

// ������ �׸�
void ConfigurationManager::SetPanoResultCutting(const CString data)
{
	SetData(_T("Setting"), _T("pano_result_cutting"), data);
}
CString ConfigurationManager::GetPanoResultCutting()
{
	return GetData(_T("Setting"), _T("pano_result_cutting"));
}
// -----------

void ConfigurationManager::SetPanoManKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_kv"), data);
}
CString ConfigurationManager::GetPanoManKv()
{
	return GetData(_T("Setting"), _T("pano_man_kv"));
}

void ConfigurationManager::SetPanoManMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_ma"), data);
}
CString ConfigurationManager::GetPanoManMa()
{
	return GetData(_T("Setting"), _T("pano_man_ma"));
}

void ConfigurationManager::SetPanoWomanKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_kv"), data);
}
CString ConfigurationManager::GetPanoWomanKv()
{
	return GetData(_T("Setting"), _T("pano_woman_kv"));
}

void ConfigurationManager::SetPanoWomanMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_ma"), data);
}
CString ConfigurationManager::GetPanoWomanMa()
{
	return GetData(_T("Setting"), _T("pano_woman_ma"));
}

void ConfigurationManager::SetPanoChildKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_kv"), data);
}
CString ConfigurationManager::GetPanoChildKv()
{
	return GetData(_T("Setting"), _T("pano_child_kv"));
}

void ConfigurationManager::SetPanoChildMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_ma"), data);
}
CString ConfigurationManager::GetPanoChildMa()
{
	return GetData(_T("Setting"), _T("pano_child_ma"));
}

void ConfigurationManager::SetPanoTeenKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_teen_kv"), data);
}
CString ConfigurationManager::GetPanoTeenKv()
{
	return GetData(_T("Setting"), _T("pano_teen_kv"));
}

void ConfigurationManager::SetPanoTeenMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_teen_ma"), data);
}
CString ConfigurationManager::GetPanoTeenMa()
{
	return GetData(_T("Setting"), _T("pano_teen_ma"));
}

void ConfigurationManager::SetCephManKv(const CString data)
{
	SetData(_T("Setting"), _T("ceph_man_kv"), data);
}
CString ConfigurationManager::GetCephManKv()
{
	return GetData(_T("Setting"), _T("ceph_man_kv"));
}

void ConfigurationManager::SetCephManMa(const CString data)
{
	SetData(_T("Setting"), _T("ceph_man_ma"), data);
}
CString ConfigurationManager::GetCephManMa()
{
	return GetData(_T("Setting"), _T("ceph_man_ma"));
}

void ConfigurationManager::SetCephWomanKv(const CString data)
{
	SetData(_T("Setting"), _T("ceph_woman_kv"), data);
}
CString ConfigurationManager::GetCephWomanKv()
{
	return GetData(_T("Setting"), _T("ceph_woman_kv"));
}

void ConfigurationManager::SetCephWomanMa(const CString data)
{
	SetData(_T("Setting"), _T("ceph_woman_ma"), data);
}
CString ConfigurationManager::GetCephWomanMa()
{
	return GetData(_T("Setting"), _T("ceph_woman_ma"));
}

void ConfigurationManager::SetCephChildKv(const CString data)
{
	SetData(_T("Setting"), _T("ceph_child_kv"), data);
}
CString ConfigurationManager::GetCephChildKv()
{
	return GetData(_T("Setting"), _T("ceph_child_kv"));
}

void ConfigurationManager::SetCephChildMa(const CString data)
{
	SetData(_T("Setting"), _T("ceph_child_ma"), data);
}
CString ConfigurationManager::GetCephChildMa()
{
	return GetData(_T("Setting"), _T("ceph_child_ma"));
}

void ConfigurationManager::SetCephTeenKv(const CString data)
{
	SetData(_T("Setting"), _T("ceph_teen_kv"), data);
}
CString ConfigurationManager::GetCephTeenKv()
{
	return GetData(_T("Setting"), _T("ceph_teen_kv"));
}

void ConfigurationManager::SetCephTeenMa(const CString data)
{
	SetData(_T("Setting"), _T("ceph_teen_ma"), data);
}
CString ConfigurationManager::GetCephTeenMa()
{
	return GetData(_T("Setting"), _T("ceph_teen_ma"));
}

void ConfigurationManager::SetCephCarpusKv(const CString data)
{
	SetData(_T("Setting"), _T("ceph_carpus_kv"), data);
}
CString ConfigurationManager::GetCephCarpusKv()
{
	return GetData(_T("Setting"), _T("ceph_carpus_kv"));
}

void ConfigurationManager::SetCephCarpusMa(const CString data)
{
	SetData(_T("Setting"), _T("ceph_carpus_ma"), data);
}
CString ConfigurationManager::GetCephCarpusMa()
{
	return GetData(_T("Setting"), _T("ceph_carpus_ma"));
}

void ConfigurationManager::SetCTManKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_man_kv"), data);
}
CString ConfigurationManager::GetCTManKv()
{
	return GetData(_T("Setting"), _T("ct_man_kv"));
}

void ConfigurationManager::SetCTManMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_man_ma"), data);
}
CString ConfigurationManager::GetCTManMa()
{
	return GetData(_T("Setting"), _T("ct_man_ma"));
}

void ConfigurationManager::SetCTWomanKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_woman_kv"), data);
}
CString ConfigurationManager::GetCTWomanKv()
{
	return GetData(_T("Setting"), _T("ct_woman_kv"));
}

void ConfigurationManager::SetCTWomanMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_woman_ma"), data);
}
CString ConfigurationManager::GetCTWomanMa()
{
	return GetData(_T("Setting"), _T("ct_woman_ma"));
}

void ConfigurationManager::SetCTChildKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_child_kv"), data);
}
CString ConfigurationManager::GetCTChildKv()
{
	return GetData(_T("Setting"), _T("ct_child_kv"));
}

void ConfigurationManager::SetCTChildMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_child_ma"), data);
}
CString ConfigurationManager::GetCTChildMa()
{
	return GetData(_T("Setting"), _T("ct_child_ma"));
}

void ConfigurationManager::SetCTTeenKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_teen_kv"), data);
}
CString ConfigurationManager::GetCTTeenKv()
{
	return GetData(_T("Setting"), _T("ct_teen_kv"));
}

void ConfigurationManager::SetCTTeenMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_teem_ma"), data);
}
CString ConfigurationManager::GetCTTeenMa()
{
	return GetData(_T("Setting"), _T("ct_teen_ma"));
}

void ConfigurationManager::SetCTLowKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_low_kv"), data);
}
CString ConfigurationManager::GetCTLowKv()
{
	return GetData(_T("Setting"), _T("ct_low_kv"));
}

void ConfigurationManager::SetCTLowMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_low_ma"), data);
}
CString ConfigurationManager::GetCTLowMa()
{
	return GetData(_T("Setting"), _T("ct_low_ma"));
}

void ConfigurationManager::SetCTUltraLowKv(const CString data)
{
	SetData(_T("Setting"), _T("ct_ultra_low_kv"), data);
}
CString ConfigurationManager::GetCTUltraLowKv()
{
	return GetData(_T("Setting"), _T("ct_ultra_low_kv"));
}

void ConfigurationManager::SetCTUltraLowMa(const CString data)
{
	SetData(_T("Setting"), _T("ct_ultra_low_ma"), data);
}
CString ConfigurationManager::GetCTUltraLowMa()
{
	return GetData(_T("Setting"), _T("ct_ultra_low_ma"));
}

void ConfigurationManager::SetDAPCalibration(const CString data)
{
	SetData(_T("Setting"), _T("dapCalibration"), data);
}
CString ConfigurationManager::GetDAPCalibration()
{
	return GetData(_T("Setting"), _T("dapCalibration"));
}

void ConfigurationManager::SetCTDICalibration(const CString data)
{
	SetData(_T("Setting"), _T("ctdiCalibration"), data);
}
CString ConfigurationManager::GetCTDICalibration()
{
	return GetData(_T("Setting"), _T("ctdiCalibration"));
}

void ConfigurationManager::SetDoseCalibration(const CString data)
{
	SetData(_T("Setting"), _T("doseCalibration"), data);
}
CString ConfigurationManager::GetDoseCalibration()
{
	return GetData(_T("Setting"), _T("doseCalibration"));
}

void ConfigurationManager::SetXrayOffMode(const CString data)
{
	SetData(_T("Setting"), _T("XrayOffMode"), data);
}
CString ConfigurationManager::GetXrayOffMode()
{
	return GetData(_T("Setting"), _T("XrayOffMode"));
}

void ConfigurationManager::SetPacsSend(const CString data)
{
	SetData(_T("Setting"), _T("PacsSend"), data);
}
CString ConfigurationManager::GetPacsSend()
{
	return GetData(_T("Setting"), _T("PacsSend"));
}



// CT Section 

void ConfigurationManager::SetFrameNumber(const CString data)
{
	SetData(_T("CT"), _T("frame_number"), data);
}

CString ConfigurationManager::GetFrameNumber()
{
	return GetData(_T("CT"), _T("frame_number"));
}

void ConfigurationManager::SetBinningMode(const CString data)
{
	SetData(_T("CT"), _T("binning_mode"), data);
}

CString ConfigurationManager::GetBinningMode()
{
	return GetData(_T("CT"), _T("binning_mode"));
}

void ConfigurationManager::SetKv(const CString data)
{
	SetData(_T("CT"), _T("kv"), data);
}

CString ConfigurationManager::GetKv()
{
	return GetData(_T("CT"), _T("kv"));
}

void ConfigurationManager::SetMa(const CString data)
{
	SetData(_T("CT"), _T("ma"), data);
}

CString ConfigurationManager::GetMa()
{
	return GetData(_T("CT"), _T("ma"));
}

void ConfigurationManager::SetTubeMode(const CString data)
{
	SetData(_T("CT"), _T("tube_mode"), data);
}

CString ConfigurationManager::GetTubeMode()
{
	return GetData(_T("CT"), _T("tube_mode"));
}

void ConfigurationManager::SetEmptyFrameValueVarian1(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_1"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian1()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_1"));
}

void ConfigurationManager::SetEmptyFrameValueVarian2(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_2"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian2()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_2"));
}

void ConfigurationManager::SetEmptyFrameValueVarian3(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian3()
{
	return GetData(_T("CT"), _T("tube_mode"));
}

void ConfigurationManager::SetEmptyFrameValueSen11(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_1"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen11()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_1"));
}

void ConfigurationManager::SetEmptyFrameValueSen12(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_2"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen12()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_2"));
}

void ConfigurationManager::SetEmptyFrameValueSen13(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_3"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen13()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_3"));
}

void ConfigurationManager::SetEmptyFrameValueVarian1R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_1_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian1R()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_1_r"));
}

void ConfigurationManager::SetEmptyFrameValueVarian2R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_2_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian2R()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_2_r"));
}

void ConfigurationManager::SetEmptyFrameValueSen11R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_1_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen11R()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_1_r"));
}

void ConfigurationManager::SetEmptyFrameValueSen12R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_2_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen12R()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_2_r"));
}

void ConfigurationManager::SetMAR(const CString data)
{
	SetData(_T("CT"), _T("mar"), data);
}

CString ConfigurationManager::GetMAR()
{
	return GetData(_T("CT"), _T("mar"));
}

void ConfigurationManager::SetVolumeWidth(const CString data)
{
	SetData(_T("CT"), _T("volume_width"), data);
}
CString ConfigurationManager::GetVolumeWidth()
{
	return GetData(_T("CT"), _T("volume_width"));
}

void ConfigurationManager::SetVolumeHeight(const CString data)
{
	SetData(_T("CT"), _T("volume_height"), data);
}
CString ConfigurationManager::GetVolumeHeight()
{
	return GetData(_T("CT"), _T("volume_height"));
}

void ConfigurationManager::SetVolumePitch(const CString data)
{
	SetData(_T("CT"), _T("volume_pitch"), data);
}
CString ConfigurationManager::GetVolumePitch()
{
	return GetData(_T("CT"), _T("volume_pitch"));
}

void ConfigurationManager::SetVolumeOffset_x(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_x"), data);
}
CString ConfigurationManager::GetVolumeOffset_x()
{
	return GetData(_T("CT"), _T("volume_offset_x"));
}

void ConfigurationManager::SetVolumeOffset_y(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_y"), data);
}
CString ConfigurationManager::GetVolumeOffset_y()
{
	return GetData(_T("CT"), _T("volume_offset_y"));
}

void ConfigurationManager::SetVolumeOffset_z(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_z"), data);
}
CString ConfigurationManager::GetVolumeOffset_z()
{
	return GetData(_T("CT"), _T("volume_offset_z"));
}

void ConfigurationManager::SetPost(const CString data)
{
	SetData(_T("CT"), _T("post"), data);
}
CString ConfigurationManager::GetPost()
{
	return GetData(_T("CT"), _T("post"));
}

void ConfigurationManager::SetSensor(const CString data)
{
	SetData(_T("CT"), _T("sensor"), data);
}
CString ConfigurationManager::GetSensor()
{
	return GetData(_T("CT"), _T("sensor"));
}

void ConfigurationManager::SetVmot(const CString data)
{
	SetData(_T("CT"), _T("vmot"), data);
}
CString ConfigurationManager::GetVmot()
{
	return GetData(_T("CT"), _T("vmot"));
}

void ConfigurationManager::SetCTDataDrive(const CString data)
{
	SetData(_T("CT"), _T("ct_data_drive"), data);
}
CString ConfigurationManager::GetCTDataDrive()
{
	return GetData(_T("CT"), _T("ct_data_drive"));
}

void ConfigurationManager::SetOne3dCheck(const CString data)
{
	SetData(_T("CT"), _T("one3d_check"), data);
}
CString ConfigurationManager::GetOne3dCheck()
{
	return GetData(_T("CT"), _T("one3d_check"));
}



void ConfigurationManager::SetExposureTime(const CString data)
{
	SetData(_T("CT"), _T("exposure_time"), data);
}
CString ConfigurationManager::GetExposureTime()
{
	return GetData(_T("CT"), _T("exposure_time"));
}

void ConfigurationManager::SetDAP(const CString data)
{
	SetData(_T("CT"), _T("dap"), data);
}
CString ConfigurationManager::GetDAP()
{
	return GetData(_T("CT"), _T("dap"));
}

void ConfigurationManager::SetFovDefaultPosition(const CString data)
{
	SetData(_T("CT"), _T("FOV_default_position"), data);
}
CString ConfigurationManager::GetDefaultPosition()
{
	return GetData(_T("CT"), _T("FOV_default_position"));
}

void ConfigurationManager::SetAutoDefectMode(const CString data)
{
	SetData(_T("CT"), _T("auto_defect_mode"), data);
}
CString ConfigurationManager::GetAutoDefectMode()
{
	return GetData(_T("CT"), _T("auto_defect_mode"));
}

void ConfigurationManager::SetDefaultMode(const CString data)
{
	SetData(_T("CT"), _T("default_mode"), data);
}
CString ConfigurationManager::GetDefaultMode()
{
	return GetData(_T("CT"), _T("default_mode"));
}

void ConfigurationManager::SetAirmap1x1Slope(const CString data)
{
	SetData(_T("CT"), _T("Airmap_1x1_Slope"), data);
}
CString ConfigurationManager::GetAirmap1x1Slope()
{
	return GetData(_T("CT"), _T("Airmap_1x1_Slope"));
}

void ConfigurationManager::SetAirmap1x1Add(const CString data)
{
	SetData(_T("CT"), _T("Airmap_1x1_Add"), data);
}
CString ConfigurationManager::GetAirmap1x1Add()
{
	return GetData(_T("CT"), _T("Airmap_1x1_Add"));
}

void ConfigurationManager::SetAirmap2x2Slope(const CString data)
{
	SetData(_T("CT"), _T("Airmap_2x2_Slope"), data);
}
CString ConfigurationManager::GetAirmap2x2Slope()
{
	return GetData(_T("CT"), _T("Airmap_2x2_Slope"));
}

void ConfigurationManager::SetAirmap2x2Add(const CString data)
{
	SetData(_T("CT"), _T("Airmap_2x2_Add"), data);
}
CString ConfigurationManager::GetAirmap2x2Add()
{
	return GetData(_T("CT"), _T("Airmap_2x2_Add"));
}

void ConfigurationManager::SetCTPostScriptVarex5x5(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_5x5"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex5x5()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_5x5"));
}

void ConfigurationManager::SetCTPostScriptVarex5x5High(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_5x5_high"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex5x5High()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_5x5_high"));
}

void ConfigurationManager::SetCTPostScriptVarex5x5Low(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_5x5_low"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex5x5Low()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_5x5_low"));
}

void ConfigurationManager::SetCTPostScriptVarex5x5UltraLow(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_5x5_ultra_low"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex5x5UltraLow()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_5x5_ultra_low"));

}

void ConfigurationManager::SetCTPostScriptVarex15x9(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_15x9"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex15x9()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_15x9"));
}

void ConfigurationManager::SetCTPostScriptVarex15x9High(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_15x9_high"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex15x9High()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_15x9_high"));
}
void ConfigurationManager::SetCTPostScriptVarex15x9Low(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_15x9_low"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex15x9Low()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_15x9_low"));
}

void ConfigurationManager::SetCTPostScriptVarex15x9UltraLow(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_varex_15x9_ultra_low"), data);
}
CString ConfigurationManager::GetCTPostScriptVarex15x9UltraLow()
{
	return GetData(_T("CT"), _T("ct_post_script_varex_15x9_ultra_low"));
}

void ConfigurationManager::SetCTPostScriptDrtech5x5(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_5x5"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech5x5()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_5x5"));
}

void ConfigurationManager::SetCTPostScriptDrtech5x5High(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_5x5_high"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech5x5High()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_5x5_high"));
}

void ConfigurationManager::SetCTPostScriptDrtech5x5Low(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_5x5_low"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech5x5Low()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_5x5_low"));
}

void ConfigurationManager::SetCTPostScriptDrtech5x5UltraLow(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_5x5_ultra_low"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech5x5UltraLow()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_5x5_ultra_low"));
}

void ConfigurationManager::SetCTPostScriptDrtech15x9(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_15x9"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech15x9()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_15x9"));
}
void ConfigurationManager::SetCTPostScriptDrtech15x9High(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_15x9_high"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech15x9High()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_15x9_high"));
}

void ConfigurationManager::SetCTPostScriptDrtech15x9Low(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_15x9_low"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech15x9Low()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_15x9_low"));
}

void ConfigurationManager::SetCTPostScriptDrtech15x9UltraLow(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_drtech_15x9_ultra_low"), data);
}
CString ConfigurationManager::GetCTPostScriptDrtech15x9UltraLow()
{
	return GetData(_T("CT"), _T("ct_post_script_drtech_15x9_ultra_low"));

}

void ConfigurationManager::SetCTPostScriptSen15x5(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_sen1_5x5"), data);
}
CString ConfigurationManager::GetCTPostScriptSen15x5()
{
	return GetData(_T("CT"), _T("ct_post_script_sen1_5x5"));
}

void ConfigurationManager::SetCTPostScriptSen115x9(const CString data)
{
	SetData(_T("CT"), _T("ct_post_script_sen1_15x9"), data);
}
CString ConfigurationManager::GetCTPostScriptSen115x9()
{
	return GetData(_T("CT"), _T("ct_post_script_sen1_15x9"));
}

void ConfigurationManager::SetLastModeMemory(const CString data)
{
	SetData(_T("CT"), _T("lastModeMemory"), data);
}
CString ConfigurationManager::GetLastModeMemory()
{
	return GetData(_T("CT"), _T("lastModeMemory"));
}

void ConfigurationManager::SetDOSE(const CString data)
{
	SetData(_T("CT"), _T("dose"), data);
}
CString ConfigurationManager::GetDOSE()
{
	return GetData(_T("CT"), _T("dose"));
}

void ConfigurationManager::SetCTDI(const CString data)
{
	SetData(_T("CT"), _T("ctdi"), data);
}
CString ConfigurationManager::GetCTDI()
{
	return GetData(_T("CT"), _T("ctdi"));
}

// Pano Section








// Membrain Section

void ConfigurationManager::SetFOVDefaultPosition(const CString data)
{
	SetData(_T("Membrain"), _T("FOV_default_position"), data);
}
CString ConfigurationManager::GetFOVDefaultPosition()
{
	return GetData(_T("Membrain"), _T("FOV_default_position"));
}

void ConfigurationManager::SetCephDefaultMode(const CString data)
{
	SetData(_T("Membrain"), _T("Ceph_default_mode"), data);
}
CString ConfigurationManager::GetCephDefaultMode()
{
	return GetData(_T("Membrain"), _T("Ceph_default_mode"));
}

