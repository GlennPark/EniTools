﻿// Pano_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Pano_FormView.h"

#include "Warnning_Dialog.h"
// CPano_FormView

IMPLEMENT_DYNCREATE(CPano_FormView, CFormView)

CPano_FormView::CPano_FormView()
	: CFormView(IDD_PANO_DIALOG)
{

}

CPano_FormView::~CPano_FormView()
{
}

void CPano_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPano_FormView, CFormView)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CPano_FormView 진단

#ifdef _DEBUG
void CPano_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPano_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPano_FormView 메시지 처리기


void CPano_FormView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CFormView::OnLButtonDown(nFlags, point);
	CWarnning_Dialog dlg;

	dlg.DoModal();
}
