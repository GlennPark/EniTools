﻿
// EniToolsDlg.h: 헤더 파일
//

#pragma once

#include "resource.h" // main symbols
#include <afxwin.h>

#include "ConfigurationManager.h"

#include "Setting_FormView.h"
#include "CT_FormView.h"
#include "Pano_FormView.h"
#include "Ceph_FormView.h"
#include "Patient_FormView.h"
#include "Serial_FormView.h"
#include "Calibration_FormView.h"
#include "Expose_FormView.h"
#include "Backup_FormView.h"
#include "Fov_FormView.h"
#include "Membrain_FormView.h"
#include "Aging_FormView.h"
#include "Recon_FormView.h"
#include "Search_FormView.h"


// CEniToolsDlg 대화 상자
class CEniToolsDlg : public CDialogEx
{
// 생성입니다.
public:
	CEniToolsDlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ENITOOLS_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClickedLoadButton();
	void LoadIniFile(CString& filePath);
	void SaveIniFile(CString& filePath);

	afx_msg void OnNMDblclkSectionList(NMHDR* pNMHDR, LRESULT* pResult);  // new line
	afx_msg void OnClickedSaveButton();

	void SearchParameters();

private:
	CImageList m_imgList;		// list control

	CSetting_FormView *m_setting_FormView;
	CCT_FormView *m_ct_FormView;
	CPano_FormView *m_pano_FormView;
	CCeph_FormView* m_ceph_FormView;
	CPatient_FormView* m_patient_FormView;
	CSerial_FormView* m_serial_FormView;
	CCalibration_FormView* m_calibration_FormView;
	CExpose_FormView* m_expose_FormView;
	CBackup_FormView* m_backup_FormView;
	CFov_FormView* m_fov_FormView;
	CMembrain_FormView* m_membrain_FormView;
	CAging_FormView* m_aging_FormView;
	CRecon_FormView* m_recon_FormView;
	CSearch_FormView* m_search_FormView;

	void create_Setting_FormView();
	void create_CT_FormView();
	void create_Pano_FormView();
	void create_Ceph_FormView();
	void create_Patient_FormView();
	void create_Serial_FormView();
	void create_Calibration_FormView();
	void create_Expose_FormView();
	void create_Backup_FormView();
	void create_Fov_FormView();
	void create_Membrain_FormView();
	void create_Aging_FormView();
	void create_Recon_FormView();
	void create_Search_FormView();



public:
	afx_msg void OnStnClickedStaticDialogViewer();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedButtonSearch();
	afx_msg void OnBnClickedButtonReturnMain();
};
