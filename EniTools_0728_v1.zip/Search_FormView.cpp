﻿// Search_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Search_FormView.h"


// CSearch_FormView

IMPLEMENT_DYNCREATE(CSearch_FormView, CFormView)

CSearch_FormView::CSearch_FormView()
	: CFormView(IDD_SEARCH_FORMVIEW)
{

}

CSearch_FormView::~CSearch_FormView()
{
}

void CSearch_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSearch_FormView, CFormView)
END_MESSAGE_MAP()


// CSearch_FormView 진단

#ifdef _DEBUG
void CSearch_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSearch_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSearch_FormView 메시지 처리기
