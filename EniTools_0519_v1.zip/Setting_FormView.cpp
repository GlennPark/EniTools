﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"


// CSetting_FormView

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
	ON_EN_CHANGE(IDC_GPU_EDIT, &CSetting_FormView::OnEnChangeGpuEdit)
END_MESSAGE_MAP()


// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기


void CSetting_FormView::OnEnChangeGpuEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
