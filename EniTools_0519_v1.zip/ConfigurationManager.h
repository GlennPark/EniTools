#pragma once


class ConfigurationManager
{
private:
	static ConfigurationManager* m_instance;
	CString m_strPath;

private:
	explicit ConfigurationManager();
	~ConfigurationManager();

public:
	static ConfigurationManager* getInstance();

	void SetIniPath(CString path);

	// add get / set
	void SetData(const CString section, const CString key, const CString data);
	CString GetData(const CString section, const CString key);

	void SetLanguage(const CString data);
	CString GetLanguage();
};