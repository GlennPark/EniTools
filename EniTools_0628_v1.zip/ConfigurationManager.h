#pragma once


class ConfigurationManager
{
private:
	static ConfigurationManager* m_instance;
	CString m_strPath;

private:
	explicit ConfigurationManager();
	~ConfigurationManager();

public:
	static ConfigurationManager* getInstance();

	void SetIniPath(CString path);

	// add get / set

	//Setting Section

	void SetData(const CString section, const CString key, const CString data);
	CString GetData(const CString section, const CString key);

	void SetLanguage(const CString data);
	CString GetLanguage();

	void SetLogoMode(const CString data);
	CString GetLogoMode();

	void SetLogoName(const CString data);
	CString GetLogoName();

	void SetAutoReturn(const CString data);
	CString GetAutoReturn();

	void SetEthernetSpeedCheck(const CString data);
	CString GetEthernetSpeedCheck();

	void SetLogDebugMode(const CString data);
	CString GetLogDebugMode();

	void SetEquipment(const CString data);
	CString GetEquipment();

	void SetEthernetRestart(const CString data);
	CString GetEthernetRestart();

	void SetPresetTeen(const CString data);
	CString GetPresetTeen();

	void SetLowDose(const CString data);
	CString GetLowDose();

	CString GetModalityCT();
	
	CString GetModalityPano();

	CString GetModalityCeph();

	//������ �׸�
	void SetPanoResultCutting(const CString data);
	CString GetPanoResultCutting();
	//-----------

	void SetPanoManKv(const CString data);
	CString GetPanoManKv();
	
	void SetPanoManMa(const CString data);
	CString GetPanoManMa();

	void SetPanoWomanKv(const CString data);
	CString GetPanoWomanKv();

	void SetPanoWomanMa(const CString data);
	CString GetPanoWomanMa();
	
	void SetPanoChildKv(const CString data);
	CString GetPanoChildKv();
	
	void SetPanoChildMa(const CString data);
	CString GetPanoChildMa();

	void SetPanoTeenKv(const CString data);
	CString GetPanoTeenKv();

	void SetPanoTeenMa(const CString data);
	CString GetPanoTeenMa();

	void SetCephManKv(const CString data);
	CString GetCephManKv();

	void SetCephManMa(const CString data);
	CString GetCephManMa();

	void SetCephWomanKv(const CString data);
	CString GetCephWomanKv();

	void SetCephWomanMa(const CString data);
	CString GetCephWomanMa();

	void SetCephChildKv(const CString data);
	CString GetCephChildKv();

	void SetCephChildMa(const CString data);
	CString GetCephChildMa();

	void SetCephTeenKv(const CString data);
	CString GetCephTeenKv();

	void SetCephTeenMa(const CString data);
	CString GetCephTeenMa();

	void SetCephCarpusKv(const CString data);
	CString GetCephCarpusKv();

	void SetCephCarpusMa(const CString data);
	CString GetCephCarpusMa();

	void SetCTManKv(const CString data);
	CString GetCTManKv();

	void SetCTManMa(const CString data);
	CString GetCTManMa();

	void SetCTWomanKv(const CString data);
	CString GetCTWomanKv();

	void SetCTWomanMa(const CString data);
	CString GetCTWomanMa();

	void SetCTChildKv(const CString data);
	CString GetCTChildKv();

	void SetCTChildMa(const CString data);
	CString GetCTChildMa();

	void SetCTTeenKv(const CString data);
	CString GetCTTeenKv();

	void SetCTTeenMa(const CString data);
	CString GetCTTeenMa();

	void SetCTLowKv(const CString data);
	CString GetCTLowKv();

	void SetCTLowMa(const CString data);
	CString GetCTLowMa();

	void SetCTUltraLowKv(const CString data);
	CString GetCTUltraLowKv();

	void SetCTUltraLowMa(const CString data);
	CString GetCTUltraLowMa();

	void SetDAPCalibration(const CString data);
	CString GetDAPCalibration();

	void SetCTDICalibration(const CString data);
	CString GetCTDICalibration();

	void SetDoseCalibration(const CString data);
	CString GetDoseCalibration();

	void SetXrayOffMode(const CString data);
	CString GetXrayOffMode();

	void SetPacsSend(const CString data);
	CString GetPacsSend();
































	//CT Section

	void SetFrameNumber(const CString data);
	CString GetFrameNumber();

	void SetBinningMode(const CString data);
	CString GetBinningMode();

	void SetKv(const CString data);
	CString GetKv();

	void SetMa(const CString data);
	CString GetMa();

	void SetTubeMode(const CString data);
	CString GetTubeMode();

	void SetEmptyFrameValueVarian1(const CString data);
	CString GetEmptyFrameValueVarian1();

	void SetEmptyFrameValueVarian2(const CString data);
	CString GetEmptyFrameValueVarian2();

	void SetEmptyFrameValueVarian3(const CString data);
	CString GetEmptyFrameValueVarian3();

	void SetEmptyFrameValueSen11(const CString data);
	CString GetEmptyFrameValueSen11();

	void SetEmptyFrameValueSen12(const CString data);
	CString GetEmptyFrameValueSen12();

	void SetEmptyFrameValueSen13(const CString data);
	CString GetEmptyFrameValueSen13();

	void SetEmptyFrameValueVarian1R(const CString data);
	CString GetEmptyFrameValueVarian1R();

	void SetEmptyFrameValueVarian2R(const CString data);
	CString GetEmptyFrameValueVarian2R();

	void SetEmptyFrameValueSen11R(const CString data);
	CString GetEmptyFrameValueSen11R();

	void SetEmptyFrameValueSen12R(const CString data);
	CString GetEmptyFrameValueSen12R();

	void SetMAR(const CString data);
	CString GetMAR();

	void SetVolumeWidth(const CString data);
	CString GetVolumeWidth();

	void SetVolumeHeight(const CString data);
	CString GetVolumeHeight();
	
	void SetVolumePitch(const CString data);
	CString GetVolumePitch();
	
	void SetVolumeOffset_x(const CString data);
	CString GetVolumeOffset_x();
	
	void SetVolumeOffset_y(const CString data);
	CString GetVolumeOffset_y();
	
	void SetVolumeOffset_z(const CString data);
	CString GetVolumeOffset_z();




	// Membrain Section

	void SetFOVDefaultPosition(const CString data);
	CString GetFOVDefaultPosition();

	void SetCephDefaultMode(const CString data);
	CString GetCephDefaultMode();
};