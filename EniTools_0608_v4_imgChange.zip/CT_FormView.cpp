﻿// CT_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "CT_FormView.h"
#include "ConfigurationManager.h"

// CCT_FormView

IMPLEMENT_DYNCREATE(CCT_FormView, CFormView)

CCT_FormView::CCT_FormView()
	: CFormView(IDD_CT_DIALOG)
{

}

CCT_FormView::~CCT_FormView()
{
}

void CCT_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CCT_FormView, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_CT, &CCT_FormView::OnBnClickedButtonSaveCt)
END_MESSAGE_MAP()


// CCT_FormView 진단

#ifdef _DEBUG
void CCT_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCT_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCT_FormView 메시지 처리기
void CCT_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_KV))->SetPos(0);

	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetWindowText(_T("0"));
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetRange(0, 100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_MA))->SetPos(0);




	m_CT_Tips.Create(this, TTS_ALWAYSTIP | TTS_BALLOON);
	m_CT_Tips.SetMaxTipWidth(500);
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_FRAME_NUMBER), _T("CT 촬영 시 Recon 에서 사용되는 프레임의 수"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_BINNING_MODE), _T("픽셀 비닝, 센서에 따라 모드 고정"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_KV), _T("CT 촬영 모드 선택 시 기본 관전압"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_MA), _T("CT 촬영 모드 선택 시 기본 관전류"));
	m_CT_Tips.AddTool(GetDlgItem(IDC_STATIC_TUBE_MODE), _T("CT 촬영 시 제너레이터 모드 선택"));

	m_CT_Tips.Activate(TRUE);

}

void CCT_FormView::LoadData_CT()
{
	CString strFrameNumber = ConfigurationManager::getInstance()->GetFrameNumber();
	SetDlgItemText(IDC_EDIT_FRAME_NUMBER, strFrameNumber);

	CString strBinningMode = ConfigurationManager::getInstance()->GetBinningMode();
	SetDlgItemText(IDC_CHECK_BINNING_MODE, strBinningMode);

	CString strKv = ConfigurationManager::getInstance()->GetKv();
	SetDlgItemText(IDC_EDIT_KV, strKv);

	CString strMa = ConfigurationManager::getInstance()->GetMa();
	SetDlgItemText(IDC_EDIT_KV, strMa);

	CString strTubeMode = ConfigurationManager::getInstance()->GetTubeMode();
	
	
	if (strTubeMode == _T("0"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(FALSE);
		SetDlgItemText(IDC_RADIO_DEFAULT, strTubeMode);
	}
	else if (strTubeMode == _T("1"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(FALSE);
		SetDlgItemText(IDC_RADIO_PERSON, strTubeMode);
	}
	else if (strTubeMode == _T("2"))
	{
		((CButton*)GetDlgItem(IDC_RADIO_DEFAULT))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_PERSON))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_CONTINUE))->SetCheck(TRUE);
		SetDlgItemText(IDC_RADIO_CONTINUE, strTubeMode);
	}
	

	// Sensor 값에 따라 Varian & Sen1 항목 선택 적용

	CString strEmptyFrameValueVarian1 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1();
	CString strEmptyFrameValueVarian2 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2();
	CString strEmptyFrameValueVarian3 = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian3();

	CString strEmptyFrameValueSen11 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11();
	CString strEmptyFrameValueSen12 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12();
	CString strEmptyFrameValueSen13 = ConfigurationManager::getInstance()->GetEmptyFrameValueSen13();

	CString strEmptyFrameValueVarian1r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian1R();
	CString strEmptyFrameValueVarian2r = ConfigurationManager::getInstance()->GetEmptyFrameValueVarian2R();

	CString strEmptyFrameValueSen11r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen11R();
	CString strEmptyFrameValueSen12r = ConfigurationManager::getInstance()->GetEmptyFrameValueSen12R();
	
	CButton m_Radio_Continue;
//	CButton pButton = ConfigurationManager::getInstance()->GetTubeMode();


}


BOOL CCT_FormView::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	case WM_MOUSEMOVE:
	{ 
		m_CT_Tips.RelayEvent(pMsg);
	}
	//if (pMsg->message == WM_LBUTTONDOWN)
	//{
	//	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_LANGUAGE)->GetSafeHwnd())
	//		AfxMessageBox("마우스 왼쪽 클릭");
	//}

	return CFormView::PreTranslateMessage(pMsg);
}


void CCT_FormView::OnBnClickedButtonSaveCt()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.


}
