#include "pch.h"
#include "ConfigurationManager.h"

ConfigurationManager* ConfigurationManager::m_instance = nullptr;
ConfigurationManager::ConfigurationManager()
{}

ConfigurationManager::~ConfigurationManager()
{}

ConfigurationManager* ConfigurationManager::getInstance()
{
	if (m_instance == nullptr)
		m_instance = new ConfigurationManager();

	return m_instance;
}

void ConfigurationManager::SetIniPath(CString path)
{
	m_strPath = path;
}

void ConfigurationManager::SetData(const CString section, const CString key, const CString data)
{
	WritePrivateProfileString(section, key, data, m_strPath);
}

CString ConfigurationManager::GetData(const CString section, const CString key)
{
	CString strData;
	TCHAR _data[256];
	// ���� ������ �߻� C6386
	// �������� : sizeof -1
	GetPrivateProfileString(section, key, NULL, _data, sizeof(_data-1), m_strPath);

	strData = CString(_data);
	return strData;
}


// Setting Section

void ConfigurationManager::SetLanguage(const CString data)
{
	SetData(_T("Setting"), _T("language"), data);
}

CString ConfigurationManager::GetLanguage()
{
	return GetData(_T("Setting"), _T("language"));
}


void ConfigurationManager::SetLogoMode(const CString data)
{
	SetData(_T("Setting"), _T("logo_mode"), data);
}

CString ConfigurationManager::GetLogoMode()
{
	return GetData(_T("Setting"), _T("logo_mode"));
}

void ConfigurationManager::SetLogoName(const CString data)
{
	SetData(_T("Setting"), _T("logo_Name"), data);
}

CString ConfigurationManager::GetLogoName()
{
	return GetData(_T("Setting"), _T("logo_name"));
}

void ConfigurationManager::SetAutoReturn(const CString data)
{
	SetData(_T("Setting"), _T("auto_return"), data);
}

CString ConfigurationManager::GetAutoReturn()
{
	return GetData(_T("Setting"), _T("auto_return"));
}

void ConfigurationManager::SetEthernetSpeedCheck(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_speed_check"), data);
}

CString ConfigurationManager::GetEthernetSpeedCheck()
{
	return GetData(_T("Setting"), _T("ethernet_speed_check"));
}

void ConfigurationManager::SetLogDebugMode(const CString data)
{
	SetData(_T("Setting"), _T("log_debug_mode"), data);
}

CString ConfigurationManager::GetLogDebugMode()
{
	return GetData(_T("Setting"), _T("log_debug_mode"));
}

void ConfigurationManager::SetEquipment(const CString data)
{
	SetData(_T("Setting"), _T("equipment"), data);
}

CString ConfigurationManager::GetEquipment()
{
	return GetData(_T("Setting"), _T("equipment"));
}

void ConfigurationManager::SetEthernetRestart(const CString data)
{
	SetData(_T("Setting"), _T("ethernet_restart"), data);
}

CString ConfigurationManager::GetEthernetRestart()
{
	return GetData(_T("Setting"), _T("ethernet_restart"));
}

void ConfigurationManager::SetPanoResultCutting(const CString data)
{
	SetData(_T("Setting"), _T("pano_result_cutting"), data);
}

CString ConfigurationManager::GetPanoResultCutting()
{
	return GetData(_T("Setting"), _T("pano_result_cutting"));
}

void ConfigurationManager::SetPanoManKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_kv"), data);
}

CString ConfigurationManager::GetPanoManKv()
{
	return GetData(_T("Setting"), _T("pano_man_kv"));
}

void ConfigurationManager::SetPanoManMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_man_ma"), data);
}

CString ConfigurationManager::GetPanoManMa()
{
	return GetData(_T("Setting"), _T("pano_man_ma"));
}

void ConfigurationManager::SetPanoWomanKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_kv"), data);
}

CString ConfigurationManager::GetPanoWomanKv()
{
	return GetData(_T("Setting"), _T("pano_woman_kv"));
}

void ConfigurationManager::SetPanoWomanMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_woman_ma"), data);
}

CString ConfigurationManager::GetPanoWomanMa()
{
	return GetData(_T("Setting"), _T("pano_woman_ma"));
}

void ConfigurationManager::SetPanoChildKv(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_kv"), data);
}

CString ConfigurationManager::GetPanoChildKv()
{
	return GetData(_T("Setting"), _T("pano_child_kv"));
}

void ConfigurationManager::SetPanoChildMa(const CString data)
{
	SetData(_T("Setting"), _T("pano_child_ma"), data);
}

CString ConfigurationManager::GetPanoChildMa()
{
	return GetData(_T("Setting"), _T("pano_child_ma"));
}

// CT Section 

void ConfigurationManager::SetFrameNumber(const CString data)
{
	SetData(_T("CT"), _T("frame_number"), data);
}

CString ConfigurationManager::GetFrameNumber()
{
	return GetData(_T("CT"), _T("frame_number"));
}

void ConfigurationManager::SetBinningMode(const CString data)
{
	SetData(_T("CT"), _T("binning_mode"), data);
}

CString ConfigurationManager::GetBinningMode()
{
	return GetData(_T("CT"), _T("binning_mode"));
}

void ConfigurationManager::SetKv(const CString data)
{
	SetData(_T("CT"), _T("kv"), data);
}

CString ConfigurationManager::GetKv()
{
	return GetData(_T("CT"), _T("kv"));
}

void ConfigurationManager::SetMa(const CString data)
{
	SetData(_T("CT"), _T("ma"), data);
}

CString ConfigurationManager::GetMa()
{
	return GetData(_T("CT"), _T("ma"));
}

void ConfigurationManager::SetTubeMode(const CString data)
{
	SetData(_T("CT"), _T("tube_mode"), data);
}

CString ConfigurationManager::GetTubeMode()
{
	return GetData(_T("CT"), _T("tube_mode"));
}

void ConfigurationManager::SetEmptyFrameValueVarian1(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_1"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian1()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_1"));
}

void ConfigurationManager::SetEmptyFrameValueVarian2(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_2"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian2()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_2"));
}

void ConfigurationManager::SetEmptyFrameValueVarian3(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian3()
{
	return GetData(_T("CT"), _T("tube_mode"));
}

void ConfigurationManager::SetEmptyFrameValueSen11(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_1"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen11()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_1"));
}

void ConfigurationManager::SetEmptyFrameValueSen12(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_2"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen12()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_2"));
}

void ConfigurationManager::SetEmptyFrameValueSen13(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_3"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen13()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_3"));
}

void ConfigurationManager::SetEmptyFrameValueVarian1R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_1_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian1R()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_1_r"));
}

void ConfigurationManager::SetEmptyFrameValueVarian2R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_varian_2_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueVarian2R()
{
	return GetData(_T("CT"), _T("empty_frame_value_varian_2_r"));
}

void ConfigurationManager::SetEmptyFrameValueSen11R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_1_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen11R()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_1_r"));
}

void ConfigurationManager::SetEmptyFrameValueSen12R(const CString data)
{
	SetData(_T("CT"), _T("empty_frame_value_sen1_2_r"), data);
}

CString ConfigurationManager::GetEmptyFrameValueSen12R()
{
	return GetData(_T("CT"), _T("empty_frame_value_sen1_2_r"));
}

void ConfigurationManager::SetMAR(const CString data)
{
	SetData(_T("CT"), _T("mar"), data);
}

CString ConfigurationManager::GetMAR()
{
	return GetData(_T("CT"), _T("mar"));
}

void ConfigurationManager::SetVolumeWidth(const CString data)
{
	SetData(_T("CT"), _T("volume_width"), data);
}
CString ConfigurationManager::GetVolumeWidth()
{
	return GetData(_T("CT"), _T("volume_width"));
}

void ConfigurationManager::SetVolumeHeight(const CString data)
{
	SetData(_T("CT"), _T("volume_height"), data);
}
CString ConfigurationManager::GetVolumeHeight()
{
	return GetData(_T("CT"), _T("volume_height"));
}

void ConfigurationManager::SetVolumePitch(const CString data)
{
	SetData(_T("CT"), _T("volume_pitch"), data);
}
CString ConfigurationManager::GetVolumePitch()
{
	return GetData(_T("CT"), _T("volume_pitch"));
}

void ConfigurationManager::SetVolumeOffset_x(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_x"), data);
}
CString ConfigurationManager::GetVolumeOffset_x()
{
	return GetData(_T("CT"), _T("volume_offset_x"));
}

void ConfigurationManager::SetVolumeOffset_y(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_y"), data);
}
CString ConfigurationManager::GetVolumeOffset_y()
{
	return GetData(_T("CT"), _T("volume_offset_y"));
}

void ConfigurationManager::SetVolumeOffset_z(const CString data)
{
	SetData(_T("CT"), _T("volume_offset_z"), data);
}
CString ConfigurationManager::GetVolumeOffset_z()
{
	return GetData(_T("CT"), _T("volume_offset_z"));
}



// Membrain Section

void ConfigurationManager::SetFOVDefaultPosition(const CString data)
{
	SetData(_T("Membrain"), _T("FOV_default_position"), data);
}

CString ConfigurationManager::GetFOVDefaultPosition()
{
	return GetData(_T("Membrain"), _T("FOV_default_position"));
}

void ConfigurationManager::SetCephDefaultMode(const CString data)
{
	SetData(_T("Membrain"), _T("Ceph_default_mode"), data);
}

CString ConfigurationManager::GetCephDefaultMode()
{
	return GetData(_T("Membrain"), _T("Ceph_default_mode"));
}

