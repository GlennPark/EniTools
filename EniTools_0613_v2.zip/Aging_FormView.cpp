﻿// Aging_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Aging_FormView.h"


// CAging_FormView

IMPLEMENT_DYNCREATE(CAging_FormView, CFormView)

CAging_FormView::CAging_FormView()
	: CFormView(IDD_AGING_DIALOG)
{

}

CAging_FormView::~CAging_FormView()
{
}

void CAging_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAging_FormView, CFormView)
END_MESSAGE_MAP()


// CAging_FormView 진단

#ifdef _DEBUG
void CAging_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CAging_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CAging_FormView 메시지 처리기
