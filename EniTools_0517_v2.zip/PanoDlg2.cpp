﻿// PanoDlg2.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "PanoDlg2.h"


// PanoDlg2

IMPLEMENT_DYNCREATE(PanoDlg2, CFormView)

PanoDlg2::PanoDlg2()
	: CFormView(IDD_PANO_DIALOG)
{

}

PanoDlg2::~PanoDlg2()
{
}

void PanoDlg2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(PanoDlg2, CFormView)
END_MESSAGE_MAP()


// PanoDlg2 진단

#ifdef _DEBUG
void PanoDlg2::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void PanoDlg2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// PanoDlg2 메시지 처리기
