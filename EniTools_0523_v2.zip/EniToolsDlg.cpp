﻿
// EniToolsDlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "EniTools.h"
#include "EniToolsDlg.h"
#include "afxdialogex.h"

#include <iostream>
#include <windows.h>
#pragma comment(lib,"user32.lib")



#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
public:
	
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	
END_MESSAGE_MAP()


// CEniToolsDlg 대화 상자



CEniToolsDlg::CEniToolsDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_ENITOOLS_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

}

void CEniToolsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CEniToolsDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_LOAD_BUTTON, &CEniToolsDlg::OnClickedLoadButton)
	ON_NOTIFY(NM_DBLCLK, IDC_SECTION_LIST, &CEniToolsDlg::OnNMDblclkSectionList)
	ON_BN_CLICKED(IDC_SAVE_BUTTON, &CEniToolsDlg::OnClickedSaveButton)
END_MESSAGE_MAP()


// CEniToolsDlg 메시지 처리기

BOOL CEniToolsDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 시스템 메뉴에 "정보..." 메뉴 항목을 추가합니다.
	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.	
	m_setting_FormView = NULL;
	m_pano_FormView = 0;
	m_ct_FormView = nullptr;

	CListCtrl* pList = (CListCtrl*)GetDlgItem(IDC_SECTION_LIST);

	//pList->SetImageList(&m_imgList, LVSIL_NORMAL);

	// Set the list control to use icons
	pList->SetView(LV_VIEW_ICON);

	// Load the icon (replace IDI_SETTING_ICON with the actual ID of your icon)
	HICON hIcon_Setting = AfxGetApp()->LoadIcon(IDB_SETTING_ICON);
	HICON hIcon_CT = AfxGetApp()->LoadIcon(IDB_CT_ICON);
	// Create an image list and add the icon to it
	//CImageList imageList;
	//imageList.Add(hIcon);
	m_imgList.Create(32, 32, ILC_COLOR32, 2, 0);		// 아이콘 이미지 리스트 초기화

	// 순서대로 아이콘 이미지를 rect 파일에 넣어서 추가
	m_imgList.Add(AfxGetApp()->LoadIconW(IDI_ICON_SETTING));		// 아이콘 이미지 추가
	m_imgList.Add(AfxGetApp()->LoadIconW(IDI_ICON_CT));

	// Set the image list for the list control
	pList->SetImageList(&m_imgList, LVSIL_NORMAL);

	LVITEM reconItem = { 12 };
	reconItem.mask = LVIF_TEXT | LVIF_IMAGE;
	reconItem.pszText = _T("[Recon]");
	reconItem.iImage = 12; // index of the icon in the image list
	pList->InsertItem(&reconItem);

	LVITEM agingItem = { 11 };
	agingItem.mask = LVIF_TEXT | LVIF_IMAGE;
	agingItem.pszText = _T("[Aging]");
	agingItem.iImage = 11; // index of the icon in the image list
	pList->InsertItem(&agingItem);

	LVITEM membrainItem = { 10 };
	membrainItem.mask = LVIF_TEXT | LVIF_IMAGE;
	membrainItem.pszText = _T("[Membrain]");
	membrainItem.iImage = 10; // index of the icon in the image list
	pList->InsertItem(&membrainItem);

	LVITEM fovItem = { 9 };
	fovItem.mask = LVIF_TEXT | LVIF_IMAGE;
	fovItem.pszText = _T("[Fov]");
	fovItem.iImage = 9; // index of the icon in the image list
	pList->InsertItem(&fovItem);

	LVITEM backupItem = { 8 };
	backupItem.mask = LVIF_TEXT | LVIF_IMAGE;
	backupItem.pszText = _T("[Backup]");
	backupItem.iImage = 8; // index of the icon in the image list
	pList->InsertItem(&backupItem);

	LVITEM exposeItem = { 7 };
	exposeItem.mask = LVIF_TEXT | LVIF_IMAGE;
	exposeItem.pszText = _T("[Expose]");
	exposeItem.iImage = 7; // index of the icon in the image list
	pList->InsertItem(&exposeItem);

	LVITEM calibrationItem = { 6 };
	calibrationItem.mask = LVIF_TEXT | LVIF_IMAGE;
	calibrationItem.pszText = _T("[Calibration]");
	calibrationItem.iImage = 6; // index of the icon in the image list
	pList->InsertItem(&calibrationItem);

	LVITEM serialItem = { 5 };
	serialItem.mask = LVIF_TEXT | LVIF_IMAGE;
	serialItem.pszText = _T("[Serial]");
	serialItem.iImage = 5; // index of the icon in the image list
	pList->InsertItem(&serialItem);

	LVITEM patientItem = { 4 };
	patientItem.mask = LVIF_TEXT | LVIF_IMAGE;
	patientItem.pszText = _T("[Patient]");
	patientItem.iImage = 4; // index of the icon in the image list
	pList->InsertItem(&patientItem);
	
	LVITEM cephItem = { 3 };
	cephItem.mask = LVIF_TEXT | LVIF_IMAGE;
	cephItem.pszText = _T("[Ceph]");
	cephItem.iImage = 3; // index of the icon in the image list
	pList->InsertItem(&cephItem);

	LVITEM panoItem = { 2 };
	panoItem.mask = LVIF_TEXT | LVIF_IMAGE;
	panoItem.pszText = _T("[Pano]");
	panoItem.iImage = 2; // index of the icon in the image list
	pList->InsertItem(&panoItem);

	LVITEM ctItem = { 1 };
	ctItem.mask = LVIF_TEXT | LVIF_IMAGE;
	ctItem.pszText = _T("[CT]");
	ctItem.iImage = 1; // index of the icon in the image list
	pList->InsertItem(&ctItem);

	// Add the [Setting] item
	LVITEM settingItem = { 0 };
	settingItem.mask = LVIF_TEXT | LVIF_IMAGE;
	settingItem.pszText = _T("[Setting]");
	settingItem.iImage = 0; // index of the icon in the image list
	pList->InsertItem(&settingItem);

	create_Setting_FormView();
	create_CT_FormView();
	create_Pano_FormView();
	create_Ceph_FormView();
	create_Patient_FormView();
	create_Serial_FormView();
	create_Calibration_FormView();
	create_Expose_FormView();
	create_Backup_FormView();
	create_Fov_FormView();
	create_Membrain_FormView();
	create_Aging_FormView();
	create_Recon_FormView();

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void CEniToolsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CEniToolsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		float x = (rect.Width() - cxIcon + 1) / 2.0;
		float y = (rect.Height() - cyIcon + 1) / 2.0;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CEniToolsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CEniToolsDlg::OnClickedLoadButton()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CFileDialog fileDlg(TRUE, _T("ini"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Ini files (*.ini)|*.ini||"));

	if (fileDlg.DoModal() == IDOK)
	{
		CString filePath = fileDlg.GetPathName();
		LoadIniFile(filePath);
	}

	m_setting_FormView->LoadData();
}

void CEniToolsDlg::LoadIniFile(CString& filePath)
{
	//TCHAR buffer[256];
	//GetPrivateProfileString(_T("SectionName"), _T("KeyName"), _T("DefaultValue"), buffer, sizeof(buffer), filePath);

	// set ini file path
	//ConfigurationManager::getInstance()->SetIniPath(_T("C:\work\src\_my__\mfc\test1\EniTools\parameters.ini"));
	ConfigurationManager::getInstance()->SetIniPath(filePath);		// set ini file path

//	CString language1 = ConfigurationManager::getInstance()->GetLanguage();		// 바로 기록된 언어 읽기		장점: 작관적임, 단점: 직관적인 Get,Set을 만들어줘야함

//	ConfigurationManager::getInstance()->SetLanguage(_T("English"));			// 바로 언어정보 쓰기			장점: 작관적임, 단점: 직관적인 Get,Set을 만들어줘야함

//	CString language2 = ConfigurationManager::getInstance()->GetLanguage();		// 바로 기록된 언어 읽기		장점: 작관적임, 단점: 직관적인 Get,Set을 만들어줘야함

//	ConfigurationManager::getInstance()->SetData(_T("Setting"), _T("language"), _T("English"));		// 섹션, 키, 값 을 다이렉트로 지정해서 쓰기		장점: 직관적Get,Set을 만들지않아 작업량이 적어짐 , 단점: 문자를 잘못써서 실수할수있음

//	CString language3 = ConfigurationManager::getInstance()->GetData(_T("Setting"), _T("language"));	// 섹션, 키, 값 을 다이렉트로 지정해서 읽기		장점: 직관적Get,Set을 만들지않아 작업량이 적어짐, 단점: 문자를 잘못써서 실수할수있음

//	ConfigurationManager::getInstance()->SetData(_T("Setting"), _T("language"), _T("Korean"));		// 섹션, 키, 값 을 다이렉트로 지정해서 쓰기		장점: 직관적Get,Set을 만들지않아 작업량이 적어짐 , 단점: 문자를 잘못써서 실수할수있음

//	TRACE(_T("language1: %s\n"), language1);
//	TRACE(_T("language2: %s\n"), language2);
//	TRACE(_T("language3: %s\n"), language3);
	//TRACE(_T("language3: %s\n"), language4);


	// 이제 buffer에는 읽어온 값이 있습니다.
	// 필요에 따라 이 값을 사용하십시오.
}

void CEniToolsDlg::SaveIniFile(CString& filePath)
{

}

void CEniToolsDlg::OnNMDblclkSectionList(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.


	// Check if the [Setting] item was double-clicked
	if (pNMItemActivate->iItem == 0)
	{
		m_setting_FormView->ShowWindow(SW_SHOW);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
		
		// Open the SettingDlg (replace CSettingDlg with your actual dialog class)
		//SettingDlg settingDlg;
		//settingDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 1)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_SHOW);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
		
		//CTDlg ctDlg;
		//ctDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 2)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_SHOW);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
		 
		
		//PanoDlg panoDlg;
		//panoDlg.DoModal();
	}

	else if (pNMItemActivate->iItem == 3)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_SHOW);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);

		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	CephDlg cephDlg;
	//	cephDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 4)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_SHOW);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	PatientDlg patientDlg;
	//	patientDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 5)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_SHOW);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	SerialDlg serialDlg;
	//	serialDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 6)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_SHOW);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	CalibrationDlg calibrationDlg;
	//	calibrationDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 7)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	ExposeDlg exposeDlg;
	//	exposeDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 8)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_SHOW);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	BackupDlg backupDlg;
	//	backupDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 9)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_SHOW);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	FovDlg fovDlg;
	//	fovDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 10)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_SHOW);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	MembrainDlg membrainDlg;
	//	membrainDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 11)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_SHOW);
		m_recon_FormView->ShowWindow(SW_HIDE);
	//	AgingDlg agingDlg;
	//	agingDlg.DoModal();
	}
	else if (pNMItemActivate->iItem == 12)
	{
		m_setting_FormView->ShowWindow(SW_HIDE);
		m_ct_FormView->ShowWindow(SW_HIDE);
		m_pano_FormView->ShowWindow(SW_HIDE);
		m_ceph_FormView->ShowWindow(SW_HIDE);
		m_patient_FormView->ShowWindow(SW_HIDE);
		m_serial_FormView->ShowWindow(SW_HIDE);
		m_calibration_FormView->ShowWindow(SW_HIDE);
		m_expose_FormView->ShowWindow(SW_HIDE);
		m_backup_FormView->ShowWindow(SW_HIDE);
		m_fov_FormView->ShowWindow(SW_HIDE);
		m_membrain_FormView->ShowWindow(SW_HIDE);
		m_aging_FormView->ShowWindow(SW_HIDE);
		m_recon_FormView->ShowWindow(SW_SHOW);
	//	ReconDlg reconDlg;
	//	reconDlg.DoModal();
	}

	*pResult = 0;
}

void CEniToolsDlg::create_Setting_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;
	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CSetting_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_SETTING_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_setting_FormView = (CSetting_FormView*)pView;	
}

void CEniToolsDlg::create_CT_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CCT_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_CT_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_ct_FormView = (CCT_FormView*)pView;
}

void CEniToolsDlg::create_Pano_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CPano_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_PANO_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_pano_FormView = (CPano_FormView*)pView;
}


void CEniToolsDlg::create_Ceph_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CCeph_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_CEPH_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_ceph_FormView = (CCeph_FormView*)pView;
}

void CEniToolsDlg::create_Patient_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CPatient_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_PATIENT_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_patient_FormView = (CPatient_FormView*)pView;
}

void CEniToolsDlg::create_Serial_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CSerial_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_SERIAL_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_serial_FormView = (CSerial_FormView*)pView;
}

void CEniToolsDlg::create_Calibration_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CCalibration_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_CALIBRATION_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_calibration_FormView = (CCalibration_FormView*)pView;
}

void CEniToolsDlg::create_Expose_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CExpose_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_EXPOSE_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_expose_FormView = (CExpose_FormView*)pView;
}

void CEniToolsDlg::create_Backup_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CBackup_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_BACKUP_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_backup_FormView = (CBackup_FormView*)pView;
}

void CEniToolsDlg::create_Fov_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CFov_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_FOV_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_fov_FormView = (CFov_FormView*)pView;
}

void CEniToolsDlg::create_Membrain_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CMembrain_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_MEMBRAIN_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_membrain_FormView = (CMembrain_FormView*)pView;
}

void CEniToolsDlg::create_Aging_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CAging_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_AGING_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_aging_FormView = (CAging_FormView*)pView;
}

void CEniToolsDlg::create_Recon_FormView()
{
	CRect pRect;
	//GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_DIALOG_VIEWER)->GetWindowRect(&pRect);
	ScreenToClient(&pRect);
	//rect.left += 300;

	CCreateContext pCreateContext;

	CView* pView = (CView*)RUNTIME_CLASS(CRecon_FormView)->CreateObject();
	ZeroMemory(&pCreateContext, sizeof(pCreateContext));
	pView->Create(nullptr, nullptr, WS_CHILD, pRect, this, IDD_RECON_DIALOG, &pCreateContext);
	pView->OnInitialUpdate();

	m_recon_FormView = (CRecon_FormView*)pView;
}


void CEniToolsDlg::OnClickedSaveButton()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
