﻿// Expose_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Expose_FormView.h"


// CExpose_FormView

IMPLEMENT_DYNCREATE(CExpose_FormView, CFormView)

CExpose_FormView::CExpose_FormView()
	: CFormView(IDD_EXPOSE_DIALOG)
{

}

CExpose_FormView::~CExpose_FormView()
{
}

void CExpose_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CExpose_FormView, CFormView)
END_MESSAGE_MAP()


// CExpose_FormView 진단

#ifdef _DEBUG
void CExpose_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CExpose_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CExpose_FormView 메시지 처리기
