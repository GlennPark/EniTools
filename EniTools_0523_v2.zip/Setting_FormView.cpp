﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"
#include "ConfigurationManager.h"


#include <dxgi.h> 
#include <d3d11.h> 
#pragma comment (lib, "dxgi.lib")
#pragma comment (lib, "d3d11.lib")


#include <winsock2.h>  
#pragma comment(lib, "ws2_32.lib")  // Winsock 라이브러리 링크
// CSetting_FormView

#include <WS2tcpip.h>

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
	ON_EN_CHANGE(IDC_GPU_EDIT, &CSetting_FormView::OnEnChangeGpuEdit)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_SETTING, &CSetting_FormView::OnBnClickedSaveSettingButton)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, &CSetting_FormView::OnDeltaposSpin1)
	ON_EN_CHANGE(IDC_LOGO_NAME_EDIT, &CSetting_FormView::OnChangeLogoNameEdit)
	ON_BN_CLICKED(IDC_CHECK_ETHERNET_RESTART, &CSetting_FormView::OnBnClickedCheckEthernetRestart)
	ON_CBN_SELCHANGE(IDC_COMBO_LANGUAGE, &CSetting_FormView::OnCbnSelchangeComboLanguage)
	ON_NOTIFY(IPN_FIELDCHANGED, IDC_LOAD_BUTTON, &CSetting_FormView::OnIpnFieldchangedLoadButton)
	ON_EN_CHANGE(IDC_EDIT1, &CSetting_FormView::OnEnChangeEdit1)
	ON_STN_CLICKED(IDC_STATIC_PANO_WOMAN_KV, &CSetting_FormView::OnStnClickedStaticPanoManKv2)
	ON_STN_CLICKED(IDC_STATIC_PANO_WOMAN_MA, &CSetting_FormView::OnStnClickedStaticPanoManMa2)
	ON_STN_CLICKED(IDC_STATIC_PANO_MAN_KV, &CSetting_FormView::OnStnClickedStaticPanoManKv3)
	ON_STN_CLICKED(IDC_STATIC_PANO_MAN_MA, &CSetting_FormView::OnStnClickedStaticPanoManMa3)
	ON_EN_CHANGE(IDC_EDIT_EQUIPMENT, &CSetting_FormView::OnEnChangeEditEquipment)
END_MESSAGE_MAP()


// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기


// 현재 사용중인 GPU 정보를 불러온다
CString CSetting_FormView::GetGPUInfo()
{
	IDXGIFactory* pFactory;
	HRESULT hr = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)(&pFactory));

	IDXGIAdapter* pAdapter;
	CString gpuInfo;

	if (SUCCEEDED(hr))
	{
		for (UINT i = 0; pFactory->EnumAdapters(i, &pAdapter) != DXGI_ERROR_NOT_FOUND; ++i)
		{
			DXGI_ADAPTER_DESC adapterDesc;
			pAdapter->GetDesc(&adapterDesc);

			gpuInfo += adapterDesc.Description;
			gpuInfo += L"\n";

			pAdapter->Release();
		}

		pFactory->Release();
	}

	return gpuInfo;
}

//CString CSetting_FormView::GetLocalIPAddress()
//{
//	CString strIPAddress;
//
//	WSADATA wsaData;
//	if (WSAStartup(MAKEWORD(2, 2), &wsaData) == 0)
//	{
//		char ac[80];
//		if (gethostname(ac, sizeof(ac)) == SOCKET_ERROR)
//		{
//			WSACleanup();
//			return strIPAddress;
//		}
//
//		struct hostent* phe = gethostbyname(ac);
//		if (phe == 0)
//		{
//			WSACleanup();
//			return strIPAddress;
//		}
//
//		for (int i = 0; phe->h_addr_list[i] != 0; ++i)
//		{
//			struct in_addr addr;
//			memcpy(&addr, phe->h_addr_list[i], sizeof(struct in_addr));
//			strIPAddress = CString(inet_ntoa(addr));
//			break;  // 첫 번째 주소만 가져옴
//		}
//
//		WSACleanup();
//	}
//
//	return strIPAddress;
// 
//}


// 사용중인 네트워크 주소를 IP Address Control 에 출력
CString CSetting_FormView::GetLocalIPAddress()
{
	CString strIPAddress;

	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) == 0)
	{
		char ch_addr[80];
		if (gethostname(ch_addr, sizeof(ch_addr)) == SOCKET_ERROR)
		{
			WSACleanup();
			return strIPAddress;
		}

		struct addrinfo hints;
		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family = AF_UNSPEC;

		// 네트워크 주소 없을때 Get
		struct addrinfo* result = NULL;
		if (getaddrinfo(ch_addr, NULL, &hints, &result) != 0)
		{
			WSACleanup();
			return strIPAddress;
		}

		for (struct addrinfo* ptr = result; ptr != NULL; ptr = ptr->ai_next)
		{
			switch (ptr->ai_family)
			{
			case AF_INET:
			{
				struct sockaddr_in* sockaddr_ipv4 = (struct sockaddr_in*)ptr->ai_addr;
				strIPAddress = CString(inet_ntop(AF_INET, &(sockaddr_ipv4->sin_addr), ch_addr, sizeof(ch_addr)));
				break;
			}
			default:
				break;
			}
		}

		freeaddrinfo(result);
		WSACleanup();
	}

	return strIPAddress;
}





void CSetting_FormView::OnEnChangeGpuEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnChangeLogoNameEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnBnClickedSaveSettingButton()
{
	// test 

	
	//((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	// 
	// edit control, spin control
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetWindowText(_T("0"));
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetRange(0, 10);
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetPos(0);
	//
	//((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(_T("0"));


	// ini 파일에 콤보박스 값 쓰기
	CString strLang;
	CComboBox* lang_comboBox = ((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE));
	lang_comboBox->GetLBText(lang_comboBox->GetCurSel(), strLang);
	ConfigurationManager::getInstance()->SetLanguage(strLang);

	// logo_mode checkbox
	BOOL b_logoMode = ((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->GetCheck();
	CString strLogoMode;
	strLogoMode.Format(_T("%d"), b_logoMode);
	ConfigurationManager::getInstance()->SetLogoMode(strLogoMode);

	
	CString strLogoName;
	//= ((CEdit*)GetDlgItem(IDC_LOGO_NAME_EDIT));
	ConfigurationManager::getInstance()->SetLogoName(strLogoName);

	// auto_return checkbox
	BOOL b_autoReturn = ((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->GetCheck();
	CString strAutoReturn;
	strAutoReturn.Format(_T("%d"), b_autoReturn);
	ConfigurationManager::getInstance()->SetAutoReturn(strAutoReturn);

	// log_debug_mode checkbox
	BOOL b_logDebugMode = ((CButton*)GetDlgItem(IDC_CHECK_LOGO_DEBUG_MODE))->GetCheck();
	CString strLogDebugMode;
	strLogDebugMode.Format(_T("%d"), b_logDebugMode);
	ConfigurationManager::getInstance()->SetAutoReturn(strLogDebugMode);

	// ethernet_speed_check checkbox
	BOOL b_ethernetSpeedCheck = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->GetCheck();
	CString strEthernetSpeedCheck;
	strEthernetSpeedCheck.Format(_T("%d"), b_ethernetSpeedCheck);
	ConfigurationManager::getInstance()->SetAutoReturn(strEthernetSpeedCheck);

	// ethernet_restart checkbox
	BOOL b_ethernetRestart = ((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->GetCheck();
	CString strEthernetRestart;
	strEthernetRestart.Format(_T("%d"), b_ethernetRestart);
	ConfigurationManager::getInstance()->SetAutoReturn(strEthernetRestart);


}


void CSetting_FormView::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 10)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(str);
	}

	*pResult = 0;
}


void CSetting_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
}

void CSetting_FormView::LoadData()
{
	CString language = ConfigurationManager::getInstance()->GetLanguage();

	if (language == _T("Korean"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(0);
	else if (language == _T("English"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(1);
	else if (language == _T("Chinese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(2);
	else if (language == _T("Japaness"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(3);
	else if (language == _T("Russian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(4);
	else if (language == _T("German"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(5);
	else if (language == _T("French"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(6);
	else if (language == _T("Spanish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(7);
	else if (language == _T("Portuguese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(8);
	else if (language == _T("Italian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(9);
	else if (language == _T("Vietnamese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(10);
	else if (language == _T("Thai"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(11);
	else if (language == _T("Malay"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(12);
	else if (language == _T("Indonesian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(13);
	else if (language == _T("Bengali"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(14);
	else if (language == _T("Kazakh"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(15);
	else if (language == _T("Ukrainian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(16);
	else if (language == _T("Uzbek"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(17);
	else if (language == _T("Mongolian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(18);
	else if (language == _T("Arabic"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(19);
	else if (language == _T("Hebrew"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(20);
	else if (language == _T("Turkish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(21);
	
	// LogoName 항목 불러와서 표시
	CString strLogoName = ConfigurationManager::getInstance()->GetLogoName();
	SetDlgItemText(IDC_EDIT_LOGO_NAME, strLogoName);

	// Equipment 항목 불러와서 표시
	CString strEquipment = ConfigurationManager::getInstance()->GetEquipment();
	SetDlgItemText(IDC_EDIT_EQUIPMENT, strEquipment);


	// GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	//CString strIPAddress = GetLocalIPAddress();
	
	//LPCSTR pszConvertedAnsiString = CT2A(strIPAddress);

	//DWORD dwIP = inet_addr(pszConvertedAnsiString);
	//BYTE* pbIP = (BYTE*)&dwIP;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	

	 // GetLocalIPAddress()를 이용하여 현재 시스템의 IP 주소 정보를 가져옴
	CString strIPAddress = GetLocalIPAddress();

	// CString에서 LPCWSTR로 변환
	//LPCWSTR pszConvertedWideString = CT2W(strIPAddress);
	LPCWSTR pszConvertedWideString = LPCWSTR(strIPAddress);
	IN_ADDR ipAddr;
	InetPton(AF_INET, pszConvertedWideString, &ipAddr);

	BYTE* pbIP = (BYTE*)&ipAddr.S_un.S_addr;

	// IDC_IPADDRESS1 IP 주소 컨트롤에 값을 설정
	((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(pbIP[0], pbIP[1], pbIP[2], pbIP[3]);
	int nFIndCount = strIPAddress.Find(_T("."));
	int nBuff[10];
	int nIndexCount = 0;
	while(1)
	{
		nFIndCount = strIPAddress.Find(_T("."));
		if (nFIndCount > -1)
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress.Left(nFIndCount));
			strIPAddress = strIPAddress.Mid(nFIndCount + 1, strIPAddress.GetLength());
		}
		else
		{
			nBuff[nIndexCount] = _ttoi(strIPAddress);
			break;
		}
		nIndexCount++;
	}
	nIndexCount = 0;
	//((CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS1))->SetAddress(nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++], nBuff[nIndexCount++]);


	// 4. IDC_GPU_EDIT 에디트 컨트롤에 값을 설정
	CString gpuInfo = this->GetGPUInfo();
	SetDlgItemText(IDC_GPU_EDIT, gpuInfo);
	
	
	CString logo_mode = ConfigurationManager::getInstance()->GetLogoMode();
	if (logo_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(FALSE);

	CString logo_name = ConfigurationManager::getInstance()->GetLogoName();

	CString auto_return = ConfigurationManager::getInstance()->GetAutoReturn();
	if (auto_return == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(FALSE);

	CString ethernet_speed_check = ConfigurationManager::getInstance()->GetEthernetSpeedCheck();
	if (ethernet_speed_check == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(FALSE);

	CString logo_debug_mode = ConfigurationManager::getInstance()->GetLogoDebugMode();
	if (logo_debug_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_DEBUG_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_DEBUG_MODE))->SetCheck(FALSE);

	CString ethernet_restart = ConfigurationManager::getInstance()->GetEthernetRestart();
	if (ethernet_restart == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(FALSE);

	CString pano_result_cutting = ConfigurationManager::getInstance()->GetPanoResultCutting();
	if (pano_result_cutting == _T("0"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(0);
	else if (pano_result_cutting == _T("1"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(1);
	else if (pano_result_cutting == _T("2"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(2);
	else if (pano_result_cutting == _T("3"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(3);

		

}



void CSetting_FormView::OnBnClickedCheckEthernetRestart()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnCbnSelchangeComboLanguage()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnIpnFieldchangedLoadButton(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMIPADDRESS pIPAddr = reinterpret_cast<LPNMIPADDRESS>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}


void CSetting_FormView::OnEnChangeEdit1()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnStnClickedStaticPanoManKv2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnStnClickedStaticPanoManMa2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnStnClickedStaticPanoManKv3()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnStnClickedStaticPanoManMa3()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnEnChangeEditEquipment()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
