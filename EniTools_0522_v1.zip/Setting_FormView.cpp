﻿// Setting_FormView.cpp: 구현 파일
//

#include "pch.h"
#include "EniTools.h"
#include "Setting_FormView.h"
#include "ConfigurationManager.h"


// CSetting_FormView

IMPLEMENT_DYNCREATE(CSetting_FormView, CFormView)

CSetting_FormView::CSetting_FormView()
	: CFormView(IDD_SETTING_DIALOG)
{

}

CSetting_FormView::~CSetting_FormView()
{
}

void CSetting_FormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetting_FormView, CFormView)
	ON_EN_CHANGE(IDC_GPU_EDIT, &CSetting_FormView::OnEnChangeGpuEdit)
	ON_BN_CLICKED(IDC_BUTTON1, &CSetting_FormView::OnBnClickedButton1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, &CSetting_FormView::OnDeltaposSpin1)
	ON_EN_CHANGE(IDC_LOGO_NAME_EDIT, &CSetting_FormView::OnChangeLogoNameEdit)
	ON_BN_CLICKED(IDC_CHECK_ETHERNET_RESTART, &CSetting_FormView::OnBnClickedCheckEthernetRestart)
	ON_CBN_SELCHANGE(IDC_COMBO_LANGUAGE, &CSetting_FormView::OnCbnSelchangeComboLanguage)
END_MESSAGE_MAP()


// CSetting_FormView 진단

#ifdef _DEBUG
void CSetting_FormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSetting_FormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CSetting_FormView 메시지 처리기


void CSetting_FormView::OnEnChangeGpuEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnChangeLogoNameEdit()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnBnClickedButton1()
{
	// test 

	
	//((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	// 
	// edit control, spin control
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetWindowText(_T("0"));
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetRange(0, 10);
	//((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1))->SetPos(0);
	//
	//((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(_T("0"));


	// ini 파일에 콤보박스 값 쓰기
	CString strLang;
	CComboBox* lang_comboBox = ((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE));
	lang_comboBox->GetLBText(lang_comboBox->GetCurSel(), strLang);
	ConfigurationManager::getInstance()->SetLanguage(strLang);

	// checkbox
	BOOL b_logoMode = ((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->GetCheck();
	CString strLogoMode;
	strLogoMode.Format(_T("%d"), b_logoMode);
	ConfigurationManager::getInstance()->SetLogoMode(strLogoMode);
}


void CSetting_FormView::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	// iPos -> 값, iDelta -> 증/감
	int nValue = pNMUpDown->iPos + pNMUpDown->iDelta;

	if (nValue >= 0 && nValue <= 10)
	{
		CString str;
		str.Format(_T("%d"), nValue);
		((CSpinButtonCtrl*)GetDlgItem(IDC_EDIT3))->SetWindowText(str);
	}

	*pResult = 0;
}


void CSetting_FormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
}

void CSetting_FormView::LoadData()
{
	CString language = ConfigurationManager::getInstance()->GetLanguage();

	if (language == _T("Korean"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(0);
	else if (language == _T("English"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(1);
	else if (language == _T("Chinese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(2);
	else if (language == _T("Japaness"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(3);
	else if (language == _T("Russian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(4);
	else if (language == _T("German"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(5);
	else if (language == _T("French"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(6);
	else if (language == _T("Spanish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(7);
	else if (language == _T("Portuguese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(8);
	else if (language == _T("Italian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(9);
	else if (language == _T("Vietnamese"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(10);
	else if (language == _T("Thai"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(11);
	else if (language == _T("Malay"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(12);
	else if (language == _T("Indonesian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(13);
	else if (language == _T("Bengali"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(14);
	else if (language == _T("Kazakh"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(15);
	else if (language == _T("Ukrainian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(16);
	else if (language == _T("Uzbek"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(17);
	else if (language == _T("Mongolian"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(18);
	else if (language == _T("Arabic"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(19);
	else if (language == _T("Hebrew"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(20);
	else if (language == _T("Turkish"))
		((CComboBox*)GetDlgItem(IDC_COMBO_LANGUAGE))->SetCurSel(21);




//	CString gpu = 
	
	
	CString logo_mode = ConfigurationManager::getInstance()->GetLogoMode();
	if (logo_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_MODE))->SetCheck(FALSE);

	CString logo_name = ConfigurationManager::getInstance()->GetLogoName();

	CString auto_return = ConfigurationManager::getInstance()->GetAutoReturn();
	if (auto_return == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_AUTO_RETURN))->SetCheck(FALSE);

	CString ethernet_speed_check = ConfigurationManager::getInstance()->GetEthernetSpeedCheck();
	if (ethernet_speed_check == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_SPEED_CHECK))->SetCheck(FALSE);

	CString logo_debug_mode = ConfigurationManager::getInstance()->GetLogoDebugMode();
	if (logo_debug_mode == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_DEBUG_MODE))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_LOGO_DEBUG_MODE))->SetCheck(FALSE);

	CString ethernet_restart = ConfigurationManager::getInstance()->GetEthernetRestart();
	if (ethernet_restart == _T("0"))
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK_ETHERNET_RESTART))->SetCheck(FALSE);

	CString pano_result_cutting = ConfigurationManager::getInstance()->GetPanoResultCutting();
	if (pano_result_cutting == _T("0"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(0);
	else if (pano_result_cutting == _T("1"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(1);
	else if (pano_result_cutting == _T("2"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(2);
	else if (pano_result_cutting == _T("3"))
		((CComboBox*)GetDlgItem(IDC_COMBO_PANO_RESULT_CUTTING))->SetCurSel(3);

		

}



void CSetting_FormView::OnBnClickedCheckEthernetRestart()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CSetting_FormView::OnCbnSelchangeComboLanguage()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
